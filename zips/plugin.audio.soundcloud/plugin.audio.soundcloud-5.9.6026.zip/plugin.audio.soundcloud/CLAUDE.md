# CLAUDE.md — kodi-addon-soundcloud

## Rôle
Fork FR de `plugin.audio.soundcloud`, lecture musique/podcasts SoundCloud.

## Stack
Python, API `InfoTagMusic` (Kodi 20+), service background façon EmbyCon
(`xbmc.service start=login`).

## Build / test
`../release-addon.sh` : py_compile, XML, check AST anti-shadowing (ajouté après un
bug `UnboundLocalError`).

## Déploiement
GitHub + Forgejo, distribué via `kodi-repo`, install Cormoran.

## Accès hors-repo
- `../kodi-repo`
- `../release-addon.sh`
- SSH Cormoran (logs debug)

## Pièges
- Branche `main` (migré depuis `master`).
- **Livraison = zip SOURCE uniquement, jamais le zip installable.**
- README jamais modifié par Claude ; `rsync --exclude='readme*.md'` systématique.
- Namespace Forgejo `/thib/` à normaliser (incohérence connue vs les autres repos
  sous `/theworms/`) — ne pas corriger sans validation explicite.

## Dépendances croisées
`kodi-repo`.
