import hashlib
import json
import re
import time
import requests
import urllib.parse
import xbmc

from resources.lib.models.playlist import Playlist
from resources.lib.models.track import Track
from resources.lib.models.selection import Selection
from resources.lib.models.user import User
from resources.lib.soundcloud.api_collection import ApiCollection
from resources.lib.soundcloud.api_interface import ApiInterface


class ApiV2(ApiInterface):
    """This class uses the unofficial API used by the SoundCloud website."""

    api_host = "https://api-v2.soundcloud.com"
    api_client_id_cache_duration = 1440  # 24 hours
    api_client_id_cache_key = "api-client-id"
    api_limit = 20
    api_limit_tracks = 50
    api_lang = "en"
    api_user_agent = "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:142.0) Gecko/20100101 Firefox/142.0"
    api_cache = {
        "discover": 120  # 2 hours
    }
    thumbnail_size = 500

    def __init__(self, settings, lang, cache):
        self.cache = cache
        self.settings = settings
        self.api_limit = int(self.settings.get("search.items.size"))
        # Response timeout (Settings > Expert > Network timeout).
        # Minimum 5 s; defaults to 15 s when the setting is missing.
        try:
            self.api_timeout = max(
                5, int(self.settings.get("network.timeout") or 15)
            )
        except (TypeError, ValueError):
            self.api_timeout = 15

        if self.settings.get("apiv2.locale") == self.settings.APIV2_LOCALE["auto"]:
            self.api_lang = lang

    @property
    def api_client_id(self):
        # It is possible to set a custom client ID in the settings.
        # Client IDs are short alphanumeric keys; an OAuth token
        # pasted here by mistake (tokens are much longer and contain
        # dashes) would be sent as the client_id on every anonymous
        # request and shown in the read-only client ID row - detect
        # it and fall through to the cache/extraction instead.
        client_id_settings = self.settings.get("apiv2.client_id")
        if client_id_settings:
            if re.fullmatch(r"[0-9A-Za-z]{8,64}", client_id_settings):
                xbmc.log("plugin.audio.soundcloud::ApiV2() Using custom client ID", xbmc.LOGDEBUG)
                return client_id_settings
            xbmc.log(
                "plugin.audio.soundcloud::ApiV2() ignoring custom client ID "
                "that looks like an OAuth token",
                xbmc.LOGWARNING,
            )

        # Check if there is a cached client ID
        client_id_cached = self.cache.get(
            self.api_client_id_cache_key,
            self.api_client_id_cache_duration
        )
        if client_id_cached:
            xbmc.log("plugin.audio.soundcloud::ApiV2() Using cached client ID", xbmc.LOGDEBUG)
            return client_id_cached

        # Extract client ID from website and cache it
        client_id = self.fetch_client_id()
        self.cache.add(self.api_client_id_cache_key, client_id)
        xbmc.log("plugin.audio.soundcloud::ApiV2() Using new client ID", xbmc.LOGDEBUG)

        return client_id

    def search(self, query, kind="tracks"):
        res = self._do_request("/search/" + kind, {"q": query, "limit": self.api_limit})
        return self._map_json_to_collection(res)

    def discover(self, selection_id=None):
        res = self._do_request("/mixed-selections", {}, self.api_cache["discover"])

        if selection_id and "collection" in res:
            res = self._find_id_in_selection(res["collection"], selection_id)

        return self._map_json_to_collection(res)

    def charts(self, filters):
        res = self._do_request("/charts", filters)
        if not res or "collection" not in res:
            # Unexpected response (error page, rate limit, ...) — return an
            # empty listing instead of raising KeyError.
            return self._map_json_to_collection({"collection": []})
        res = {"collection": [item["track"] for item in res["collection"]
                              if isinstance(item, dict) and "track" in item]}
        return self._map_json_to_collection(res)

    def call(self, url):
        url = urllib.parse.urlparse(url)
        res = self._do_request(url.path, urllib.parse.parse_qs(url.query))
        return self._map_json_to_collection(res)

    def get_me(self):
        """
        Returns the authenticated user's profile object (or None if the
        request fails — e.g. no token, expired token, network error).

        Cached for 24h so we don't hit /me on every menu navigation.
        """
        # If we've already detected an invalid token earlier this session,
        # short-circuit to avoid the double round-trip (auth fail + retry
        # which also fails because /me requires a user). The user must
        # update the token in settings to recover.
        current_token = self.settings.get_oauth_token()
        self._rearm_if_token_changed(current_token)
        if getattr(self, "_token_invalid", False):
            return None

        if not current_token:
            return None

        cache_key = "api-me-profile"
        cached = self.cache.get(cache_key, 1440)  # 24h
        if cached:
            try:
                return json.loads(cached)
            except ValueError:
                pass

        res = self._do_request("/me", {})
        # _do_request returns {"collection": []} on errors, so a real /me
        # response is recognisable by the presence of an "id" key.
        if isinstance(res, dict) and "id" in res:
            try:
                self.cache.add(cache_key, json.dumps(res))
            except Exception:
                pass
            return res
        return None

    def get_my_user_id(self):
        """Convenience wrapper — returns just the user id, or None."""
        me = self.get_me()
        if me:
            return me.get("id")
        return None

    def related_tracks(self, track_id, limit=10):
        """
        Tracks related to the given one (endless playback). The
        /tracks/{id}/related endpoint is not part of the officially
        stable surface we use elsewhere — callers must tolerate an
        empty result or an exception on any error (404, rate limit).
        """
        res = self._do_request(
            "/tracks/%s/related" % urllib.parse.quote(str(track_id)),
            {"limit": limit},
        )
        if not isinstance(res, dict):
            res = {}
        if "collection" not in res:
            res = {"collection": []}
        return self._map_json_to_collection(res)

    def play_history(self, limit=50):
        """
        Returns the authenticated user's recently played tracks
        (/me/play-history/tracks - the endpoint soundcloud.com reads
        for its "Listening history"; bare /me/play-history is only the
        write/clear endpoint and returns no history, which made both
        "Recently played" and "Mixed for you" silently fall back to the
        same trending list). The entries wrap the track in a "track"
        key WITHOUT a "kind" field of their own, so they are unwrapped
        here before the generic mapper sees them. Returns None when
        the request fails (not logged in, expired token, ...).
        """
        res = self._do_request("/me/play-history/tracks", {"limit": limit})
        if not isinstance(res, dict) or not isinstance(res.get("collection"), list):
            xbmc.log(
                "plugin.audio.soundcloud::ApiV2() play history unavailable "
                "(unexpected response)",
                xbmc.LOGWARNING,
            )
            return None
        tracks = [
            entry.get("track") for entry in res["collection"]
            if isinstance(entry, dict)
        ]
        tracks = [t for t in tracks if isinstance(t, dict)]
        if not tracks:
            return None
        return self._map_json_to_collection({
            "collection": tracks,
            "next_href": res.get("next_href"),
        })

    def system_playlist(self, urn):
        """
        Returns the tracks of a system playlist (a "station"): genre
        stations (soundcloud:system-playlists:trending-by-genre:{slug}),
        artist stations, track stations, personalized playlists such as
        "Mixed for you", ... The response hydrates the tracks under a
        "tracks" key, which the generic mapper handles; unhydrated
        tracks are resolved through the mapper's /tracks?ids= path.
        Returns None when the request fails.
        """
        res = self._do_request(
            "/system-playlists/" + urllib.parse.quote(urn, safe=""), {}
        )
        if not isinstance(res, dict) or "tracks" not in res:
            return None
        return self._map_json_to_collection(res)

    def discover_section(self, keywords):
        """
        Returns the items of the first /mixed-selections category whose
        urn, id, tracking feature name or title contains one of the
        given keywords (case-insensitive). This is how the personalized
        home sections ("Mixed for you", "Recently played", "More of what
        you like", ...) are reached: their section ids are user-specific
        and can NOT be hardcoded - they must be matched at runtime.
        Returns None when nothing matches (e.g. not logged in, or the
        sections were renamed).
        """
        res = self._do_request(
            "/mixed-selections", {}, self.api_cache["discover"]
        )
        # SoundCloud mixes dashes and underscores between fields and
        # locales (e.g. tracking_feature_name "mixed_for_you" vs the
        # "mixed-for-you" keywords, and localized titles like
        # "Tendances par genre") - normalize both sides to spaces so
        # the match survives either convention and any UI language.
        keywords = [
            str(kw).lower().replace("_", " ").replace("-", " ")
            for kw in keywords
        ]
        for category in (res or {}).get("collection", []):
            if not isinstance(category, dict):
                continue
            hay = " ".join([
                str(category.get(key) or "")
                for key in ("urn", "id", "tracking_feature_name", "title")
            ]).lower()
            hay = hay.replace("_", " ").replace("-", " ")
            if any(kw in hay for kw in keywords):
                items = category.get("items")
                if isinstance(items, dict) and items.get("collection"):
                    return self._map_json_to_collection(items)
                if category.get("tracks"):
                    return self._map_json_to_collection({
                        "collection": category["tracks"]
                    })
        return None

    def check_token(self, token):
        """
        Check a candidate OAuth token WITHOUT saving it: one GET /me with
        that token. Returns a dict:
          state    "valid" | "invalid" | "error"
          http     HTTP status (None on network errors)
          username, tier   when valid (tier: "free", "go_plus", ...)
          error    short reason when state is "error"
        Used by the token window so a token is only saved once
        SoundCloud has accepted it.
        """
        result = {"state": "error", "http": None, "username": None,
                  "tier": None, "error": None}
        if not token:
            result["state"] = "invalid"
            return result
        headers = {
            "Accept": "application/json",
            "Accept-Encoding": "gzip",
            "User-Agent": self.api_user_agent,
            "Authorization": "OAuth " + token,
            "Origin": "https://soundcloud.com",
            "Referer": "https://soundcloud.com/",
        }
        # SoundCloud occasionally answers a one-off 401 to a valid
        # token (see _do_request): only a second 401 in a row counts as
        # a refusal. A 403 comes from its anti-bot / region filters
        # rather than from the token, so it means "could not check" -
        # the window then offers to save the token anyway.
        for attempt in (1, 2):
            try:
                r = requests.get(
                    self.api_host + "/me",
                    headers=headers,
                    timeout=(5, getattr(self, "api_timeout", 15)),
                )
            except requests.exceptions.RequestException as e:
                result["error"] = type(e).__name__
                return result
            if r.status_code != 401 or attempt == 2:
                break
            time.sleep(1)
        result["http"] = r.status_code
        if r.status_code == 401:
            result["state"] = "invalid"
            return result
        if r.status_code != 200:
            result["error"] = "HTTP %d" % r.status_code
            return result
        try:
            me = r.json()
        except ValueError:
            result["error"] = "invalid JSON"
            return result
        if not isinstance(me, dict) or "id" not in me:
            result["error"] = "unexpected answer"
            return result
        result["state"] = "valid"
        result["username"] = me.get("username") or me.get("permalink")
        product = (me.get("consumer_subscription") or {}).get("product") or {}
        result["tier"] = product.get("id")
        return result

    def _rearm_if_token_changed(self, current_token):
        """
        If the token has changed since we last marked it invalid, reset
        the flag so the new token gets a fresh chance. This way the user
        doesn't have to restart Kodi after saving a new token.
        """
        if (
            getattr(self, "_token_invalid", False)
            and current_token
            and current_token != getattr(self, "_last_invalid_token", None)
        ):
            xbmc.log(
                "plugin.audio.soundcloud::ApiV2() OAuth token changed since "
                "last 401 — re-enabling auth for this session",
                xbmc.LOGINFO,
            )
            self._token_invalid = False
            self._last_invalid_token = None
            self._consecutive_401 = 0

    def reset_auth_state(self):
        """
        Forget everything learned about the previous token: the
        invalid-token latch, the 401 counter, the once-per-process
        notification guard and the cached /me profile. Called after a
        new token is saved so it gets a fresh chance immediately.
        """
        self._token_invalid = False
        self._last_invalid_token = None
        self._consecutive_401 = 0
        ApiV2._auth_error_notified = False
        try:
            self.cache.vfs.delete("api-me-profile")
        except Exception:
            pass

    def like_track(self, track_id):
        """PUT /me/favorites/{id} — True on HTTP 2xx."""
        return self._modify_favorite(track_id, method="PUT")

    def unlike_track(self, track_id):
        """DELETE /me/favorites/{id} — True on HTTP 2xx."""
        return self._modify_favorite(track_id, method="DELETE")

    def _modify_favorite(self, track_id, method):
        """
        PUT/DELETE a favorite. Direct requests call on purpose (not
        _do_request): that helper is GET-oriented (client_id fallback,
        anonymous retry after 401), none of which makes sense for a
        user-scoped write. Success = any 2xx status.
        """
        current_token = self.settings.get_oauth_token()
        if not current_token:
            return False
        url = self.api_host + "/me/favorites/%s" % urllib.parse.quote(
            str(track_id)
        )
        headers = {
            "Accept-Encoding": "gzip",
            "User-Agent": self.api_user_agent,
            "Authorization": "OAuth " + current_token,
            "Origin": "https://soundcloud.com",
            "Referer": "https://soundcloud.com/",
        }
        try:
            r = requests.request(
                method,
                url,
                headers=headers,
                timeout=(5, getattr(self, "api_timeout", 15)),
            )
            ok = 200 <= r.status_code < 300
            xbmc.log(
                "plugin.audio.soundcloud::ApiV2() %s %s -> HTTP %d"
                % (method, url, r.status_code),
                xbmc.LOGDEBUG,
            )
            return ok
        except requests.exceptions.RequestException as e:
            xbmc.log(
                "plugin.audio.soundcloud::ApiV2() %s %s failed: %s"
                % (method, url, str(e)),
                xbmc.LOGWARNING,
            )
            return False

    def resolve_id(self, id):
        res = self._do_request("/tracks", {"ids": id})
        # Error responses come back as dicts (e.g. {"collection": []})
        # instead of the expected list of tracks - guard the mapper
        # (audit ST3).
        if not isinstance(res, list):
            res = []
        return self._map_json_to_collection({"collection": res})

    def resolve_url(self, url):
        url = self._sanitize_url(url)
        res = self._do_request("/resolve", {"url": url})
        return self._map_json_to_collection(res)

    def resolve_media_url(self, url):
        """
        Resolves a transcoding URL (e.g. /media/.../stream/hls) to the actual
        playable stream URL.

        Note: SoundCloud HLS/progressive transcoding URLs are short-lived
        (typically 30 minutes after the parent track was fetched). If the
        URL has expired, the API responds 404 and we return None — the
        caller (plugin.py play handler) is responsible for telling Kodi
        the resolution failed via setResolvedUrl(succeeded=False).
        """
        url = urllib.parse.urlparse(url)
        res = self._do_request(url.path, urllib.parse.parse_qs(url.query))
        resolved = res.get("url") if isinstance(res, dict) else None
        if not resolved:
            xbmc.log(
                "plugin.audio.soundcloud::ApiV2() Could not resolve stream URL %s "
                "(probably expired transcoding token)" % url.path,
                xbmc.LOGWARNING,
            )
        return resolved

    def _do_request(self, path, payload, cache=0, _retry_after_401=False):
        # Read the current token from settings. We always re-read because
        # the user might have just edited it (Settings now creates a fresh
        # Addon() per call to bypass Kodi's in-memory caching).
        current_token = self.settings.get_oauth_token()
        self._rearm_if_token_changed(current_token)

        # Inject OAuth token when the user has configured one in the settings.
        # However, if we've previously seen the token rejected with 401, we
        # disable it for the rest of this session — otherwise we keep getting
        # 401s on EVERY endpoint (even public ones like /charts) because
        # SoundCloud refuses any request bearing an invalid token.
        oauth_token = (
            current_token
            if not getattr(self, "_token_invalid", False)
            else None
        )
        authenticated = bool(oauth_token)

        # The client_id is required for unauthenticated calls. When we have
        # an OAuth token we leave it out — sending both can cause some /me/*
        # endpoints to return empty collections (the API arbitrates between
        # the two and the client_id "wins" the user context, giving back the
        # client_id app's empty profile instead of the user's data).
        if not authenticated:
            payload["client_id"] = self.api_client_id
        payload["app_locale"] = self.api_lang

        # Security (audit S1): validate the request path BEFORE the
        # OAuth Authorization header is added below. A forged "call"
        # value like ".evil.example/x" or "@evil.example/x" would
        # otherwise be glued to the API host and send the user's
        # token to an attacker-controlled host. Only plain "/..."
        # paths on the official API host ever carry authentication.
        if (
            not isinstance(path, str)
            or not path.startswith("/")
            or path.startswith("//")
            or "@" in path
            or "\\" in path
        ):
            xbmc.log(
                "plugin.audio.soundcloud::ApiV2 refusing suspicious "
                "API path",
                xbmc.LOGWARNING,
            )
            return {"collection": []}
        request_url = self.api_host + path
        if urllib.parse.urlsplit(request_url).hostname \
                != "api-v2.soundcloud.com":
            xbmc.log(
                "plugin.audio.soundcloud::ApiV2 refusing API request "
                "to a foreign host",
                xbmc.LOGWARNING,
            )
            return {"collection": []}

        headers = {
            "Accept-Encoding": "gzip",
            "User-Agent": self.api_user_agent,
            # SoundCloud's edge tightened up filtering in 2025: requests
            # without Origin/Referer headers get HTTP 403 on user-scoped
            # endpoints like /me even when the OAuth token is valid.
            # Mimic the headers a real browser session on soundcloud.com
            # would send, and we get the same 200 response.
            "Origin": "https://soundcloud.com",
            "Referer": "https://soundcloud.com/",
        }
        if authenticated:
            headers["Authorization"] = "OAuth " + oauth_token

        path = request_url
        # Personalised answers (/mixed-selections...) must not be served
        # to another account after a token change: authenticated
        # requests get a fingerprint of the token (never the token
        # itself) in their cache key.
        key_source = path + str(payload)
        if oauth_token:
            key_source += "|" + hashlib.sha256(oauth_token.encode()).hexdigest()[:16]
        cache_key = hashlib.sha1(key_source.encode()).hexdigest()

        # Redact the token before logging the headers.
        log_headers = dict(headers)
        if "Authorization" in log_headers:
            log_headers["Authorization"] = "OAuth <redacted>"

        xbmc.log(
            "plugin.audio.soundcloud::ApiV2() Calling %s with header %s and payload %s" %
            (path, str(log_headers), str(payload)),
            xbmc.LOGDEBUG
        )

        # If caching is active, check for an existing cached file.
        if cache:
            cached_response = self.cache.get(cache_key, cache)
            if cached_response:
                xbmc.log("plugin.audio.soundcloud::ApiV2() Cache hit", xbmc.LOGDEBUG)
                return json.loads(cached_response)

        # Send the request, measuring how long it took.
        import time
        t_start = time.time()
        # Timeout borné : 5 s pour etablir la connexion, 15 s pour la
        # reponse. Sans cela, un serveur muet gele la fenetre UI (les
        # appels API partent du thread GUI) jusqu'au timeout TCP de
        # l'OS — potentiellement plusieurs minutes sans aucun retour.
        try:
            raw = requests.get(
                path, headers=headers, params=payload,
                timeout=(5, getattr(self, "api_timeout", 15))
            )
        except requests.exceptions.RequestException as e:
            xbmc.log(
                "plugin.audio.soundcloud::ApiV2() Network error on %s: %s" %
                (path, str(e)),
                xbmc.LOGWARNING,
            )
            return {"collection": []}
        elapsed_ms = int((time.time() - t_start) * 1000)

        # Status-code-aware handling. We log the body on errors (truncated)
        # so debug logs reveal the real cause without crashing the addon.
        body_preview = (raw.text or "")[:200]

        # Verbose log of every authenticated call so we can correlate
        # any 401 with the chain of requests that led up to it.
        # Token is never logged (already redacted in log_headers).
        if authenticated:
            xbmc.log(
                "plugin.audio.soundcloud::ApiV2() AUTH GET %s -> %d in %dms "
                "(token_len=%d)" %
                (path, raw.status_code, elapsed_ms, len(oauth_token or "")),
                xbmc.LOGDEBUG,
            )

            # Token lifetime tracking: remember when this specific token
            # value first started working, and the most recent successful
            # call. When we hit a 401 we'll log how long the token lived.
            # Note: we skip the reset/tracking when this call is itself
            # the anonymous retry of a previous 401 (_retry_after_401),
            # because that retry's 200 doesn't prove the token works —
            # only that the underlying endpoint is reachable.
            if 200 <= raw.status_code < 300 and not _retry_after_401:
                # Reset consecutive-401 counter on AUTHENTICATED success.
                if getattr(self, "_consecutive_401", 0) > 0:
                    xbmc.log(
                        "plugin.audio.soundcloud::ApiV2() Resetting 401 "
                        "counter (was %d) — token works again." %
                        self._consecutive_401,
                        xbmc.LOGINFO,
                    )
                self._consecutive_401 = 0

                if (
                    not hasattr(self, "_token_first_ok_ts")
                    or getattr(self, "_token_tracked", None) != oauth_token
                ):
                    self._token_first_ok_ts = time.time()
                    self._token_tracked = oauth_token
                    self._token_call_count = 0
                self._token_last_ok_ts = time.time()
                self._token_call_count = getattr(self, "_token_call_count", 0) + 1

        if authenticated and raw.status_code in (401, 403) and not _retry_after_401:
            # Lifetime diagnostic: how long did this token actually work?
            lifetime_diag = ""
            if hasattr(self, "_token_first_ok_ts"):
                lived_s = int(time.time() - self._token_first_ok_ts)
                idle_s = int(time.time() - getattr(self, "_token_last_ok_ts", 0))
                calls = getattr(self, "_token_call_count", 0)
                lifetime_diag = (
                    " | TOKEN LIFETIME: worked for %d seconds across %d "
                    "calls, last success %d seconds ago" %
                    (lived_s, calls, idle_s)
                )

            # Count consecutive 401s. We only mark the token invalid
            # after 2 in a row, because SoundCloud occasionally returns
            # a transient 401 even for valid tokens (network glitch,
            # backend deploy, rate limit window). Marking it dead on
            # the first 401 was way too aggressive and likely the cause
            # of the "token disconnects all the time" complaint.
            self._consecutive_401 = getattr(self, "_consecutive_401", 0) + 1

            xbmc.log(
                "plugin.audio.soundcloud::ApiV2() Authentication failed (HTTP %d) on %s. "
                "Body: %r. Consecutive 401s: %d.%s" %
                (raw.status_code, path, body_preview,
                 self._consecutive_401, lifetime_diag),
                xbmc.LOGWARNING
            )

            if self._consecutive_401 >= 2:
                xbmc.log(
                    "plugin.audio.soundcloud::ApiV2() %d consecutive 401s — "
                    "disabling token for the rest of this session. Update it in "
                    "Settings > Account > Manage the OAuth token to fix." %
                    self._consecutive_401,
                    xbmc.LOGWARNING,
                )
                self._notify_auth_error()
                self._token_invalid = True
                self._last_invalid_token = current_token
            else:
                xbmc.log(
                    "plugin.audio.soundcloud::ApiV2() Treating this 401 as "
                    "transient — token NOT disabled yet. Will retry "
                    "anonymously this time but keep the token armed for "
                    "next call.",
                    xbmc.LOGINFO,
                )
                # Don't mark token invalid yet, but still retry this
                # specific call anonymously so the user gets some content.
            # Retry the same request immediately, this time anonymously.
            # The _retry_after_401 flag prevents infinite recursion if the
            # endpoint somehow returns 401 even unauthenticated.
            retry_path = path.replace(self.api_host, "", 1)
            # Drop any auth-side payload key we may have added (defensive,
            # currently none). The recursive call adds client_id itself.
            payload.pop("oauth_token", None)
            return self._do_request(
                retry_path, payload, cache, _retry_after_401=True
            )

        if raw.status_code >= 400:
            xbmc.log(
                "plugin.audio.soundcloud::ApiV2() HTTP %d on %s. Body: %r" %
                (raw.status_code, path, body_preview),
                xbmc.LOGWARNING
            )
            return {"collection": []}

        # Some endpoints can return an empty body (204 No Content, or even
        # a successful 200 with no body for empty user lists). Don't crash.
        if not raw.text or not raw.text.strip():
            xbmc.log(
                "plugin.audio.soundcloud::ApiV2() Empty body on %s (status %d)" %
                (path, raw.status_code),
                xbmc.LOGDEBUG
            )
            return {"collection": []}

        try:
            response = raw.json()
        except ValueError as e:
            xbmc.log(
                "plugin.audio.soundcloud::ApiV2() Non-JSON response on %s (status %d): %s. "
                "Body: %r" %
                (path, raw.status_code, str(e), body_preview),
                xbmc.LOGWARNING
            )
            return {"collection": []}

        # If caching is active, cache the response.
        if cache:
            self.cache.add(cache_key, json.dumps(response))

        return response

    _auth_error_notified = False

    def _notify_auth_error(self):
        """
        Shows a non-blocking notification about an invalid OAuth token.
        Guarded so we only bother the user once per plugin invocation.
        """
        if ApiV2._auth_error_notified:
            return
        ApiV2._auth_error_notified = True
        try:
            import xbmcaddon
            import xbmcgui
            addon = xbmcaddon.Addon()
            xbmcgui.Dialog().notification(
                addon.getAddonInfo("name"),
                addon.getLocalizedString(30024),
                xbmcgui.NOTIFICATION_WARNING,
                8000
            )
        except Exception:
            # Never let a notification failure break playback.
            pass

    def _extract_media_url(self, item):
        """
        Pick the best transcoding URL for the configured audio format,
        and attach the track-level track_authorization query parameter
        if SoundCloud included one.

        Background: since 2025-ish, SoundCloud's /media/{urn}/{tid}/stream/...
        endpoint requires a `track_authorization` query parameter (a JWT)
        in addition to the OAuth token in the Authorization header. Without
        it, the API responds 404. The JWT lives on the track object at
        `track.track_authorization`, *not* on individual transcodings, so
        we have to read it from the parent track and stitch it into the
        URL ourselves.

        The authorization JWT typically expires ~2 hours after fetch.
        """
        transcodings = (item.get("media") or {}).get("transcodings") or []
        if not transcodings:
            return None

        setting = self.settings.get("audio.format")
        chosen = None
        for codec in transcodings:
            if self._is_preferred_codec(codec["format"], self.settings.AUDIO_FORMATS[setting]):
                chosen = codec
                break

        if chosen is None:
            # Fallback to first transcoding
            chosen = transcodings[0]

        url = chosen.get("url")
        if not url:
            return None

        # Stitch track_authorization if present.
        track_auth = item.get("track_authorization")
        if track_auth:
            sep = "&" if "?" in url else "?"
            url = url + sep + "track_authorization=" + urllib.parse.quote(
                track_auth, safe=""
            )

        return url

    def _find_id_in_selection(self, selection, selection_id):
        for category in selection:
            if category["id"] == selection_id:
                if "items" in category:
                    return category["items"]
                elif "tracks" in category:
                    return {"collection": category["tracks"]}
            elif "items" in category:
                res = self._find_id_in_selection(category["items"]["collection"], selection_id)
                if res:
                    return res

    def _map_json_to_collection(self, json_obj):
        collection = ApiCollection()
        collection.items = []  # Reset list in order to resolve problems in unit tests.
        collection.load = []
        collection.next_href = json_obj.get("next_href", None)

        if "kind" in json_obj and json_obj["kind"] == "track":
            # If we are dealing with a single track, pack it into a dict
            json_obj = {"collection": [json_obj]}

        if "collection" in json_obj:
            raw_collection = json_obj["collection"]
            # API error payloads can put a non-list here; treat as
            # empty instead of crashing with "string indices must be
            # integers" (audit ST3).
            if not isinstance(raw_collection, list):
                raw_collection = []

            for item in raw_collection:
                kind = item.get("kind", None)

                # /me/* endpoints wrap the actual content in a "like" / "repost" /
                # "playlist-like" envelope with the real object nested inside.
                # Unwrap so the rest of the code sees the underlying track / playlist.
                if kind in ("like", "track-like"):
                    if isinstance(item.get("track"), dict):
                        item = item["track"]
                        kind = item.get("kind", "track")
                    elif isinstance(item.get("playlist"), dict):
                        item = item["playlist"]
                        kind = item.get("kind", "playlist")
                    elif isinstance(item.get("system_playlist"), dict):
                        item = item["system_playlist"]
                        kind = item.get("kind", "system-playlist")
                    else:
                        continue
                elif kind in ("track-repost", "repost"):
                    if isinstance(item.get("track"), dict):
                        item = item["track"]
                        kind = item.get("kind", "track")
                    else:
                        continue
                elif kind == "playlist-like":
                    if isinstance(item.get("playlist"), dict):
                        item = item["playlist"]
                        kind = item.get("kind", "playlist")
                    else:
                        continue
                elif kind == "playlist-repost":
                    if isinstance(item.get("playlist"), dict):
                        item = item["playlist"]
                        kind = item.get("kind", "playlist")
                    else:
                        continue
                elif kind == "system-playlist-like":
                    if isinstance(item.get("system_playlist"), dict):
                        item = item["system_playlist"]
                        kind = item.get("kind", "system-playlist")
                    else:
                        continue

                if kind == "track":
                    if "title" not in item:
                        # Track not fully returned by API
                        collection.load.append(item["id"])
                        continue

                    track = self._build_track(item)
                    collection.items.append(track)

                elif kind == "user":
                    user = User(id=item["id"], label=item["username"])
                    user.label2 = item.get("full_name", "")
                    user.thumb = self._get_thumbnail(item, self.thumbnail_size)
                    user.fanart = self._get_user_banner(item)
                    user.info = {
                        "description": item.get("description", ""),
                        "followers": item.get("followers_count", 0)
                    }
                    collection.items.append(user)

                elif kind == "playlist":
                    playlist = Playlist(id=item["id"], label=item.get("title"))
                    playlist.is_album = item.get("is_album", False)
                    playlist.label2 = item.get("label_name", "")
                    playlist.thumb = self._get_thumbnail(item, self.thumbnail_size)
                    playlist.fanart = playlist.thumb
                    playlist.info = {
                        "artist": item["user"]["username"],
                        "description": item.get("description", ""),
                        "likes": item.get("likes_count", 0),
                        "track_count": item.get("track_count", 0),
                    }
                    collection.items.append(playlist)

                elif kind == "system-playlist":
                    # System playlists appear inside selections and in
                    # /me/likes/system-playlists; the liked entries
                    # carry a "urn" but no "id".
                    playlist = Selection(
                        id=item.get("id") or item.get("urn"),
                        label=item.get("title"),
                    )
                    playlist.thumb = self._get_thumbnail(item, self.thumbnail_size)
                    collection.items.append(playlist)

                elif kind == "selection":
                    selection = Selection(id=item["id"], label=item.get("title"))
                    selection.label2 = item.get("description", "")
                    collection.items.append(selection)

                else:
                    xbmc.log("plugin.audio.soundcloud::ApiV2() "
                             "Could not convert JSON kind to model...",
                             xbmc.LOGWARNING)

        elif "tracks" in json_obj and isinstance(json_obj["tracks"], list):

            for item in json_obj["tracks"]:
                if "title" not in item:
                    # Track not fully returned by API
                    collection.load.append(item["id"])
                    continue

                track = self._build_track(item)
                track.label2 = json_obj["title"]
                collection.items.append(track)

        else:
            # Audit ST3: an unexpected API payload (e.g. a user
            # profile where a collection was expected) used to raise
            # and crash the caller; log and return empty instead.
            xbmc.log(
                "plugin.audio.soundcloud::ApiV2 could not map JSON "
                "(keys: %s)" % sorted(json_obj.keys()),
                xbmc.LOGWARNING,
            )

        # Load unresolved tracks
        if collection.load:
            # The API only supports a max of 50 track IDs per request:
            for chunk in self._chunks(collection.load, self.api_limit_tracks):
                track_ids = ",".join(str(x) for x in chunk)
                loaded_tracks = self._do_request("/tracks", {"ids": track_ids})
                if not isinstance(loaded_tracks, list):
                    loaded_tracks = []
                # Because returned tracks are not sorted, we have to manually match them
                for track_id in chunk:
                    loaded_track = [lt for lt in loaded_tracks if lt["id"] == track_id]
                    if len(loaded_track):  # Sometimes a track cannot be resolved
                        track = self._build_track(loaded_track[0])
                        collection.items.append(track)

        return collection

    def _build_track(self, item):
        album = None
        if type(item.get("publisher_metadata")) is dict:
            artist = item["publisher_metadata"].get("artist", item["user"]["username"])
            album = item["publisher_metadata"].get("album_title")
        else:
            artist = item["user"]["username"]

        track = Track(id=item["id"], label=item["title"])
        track.blocked = True if item.get("policy") == "BLOCK" else False
        track.preview = True if item.get("policy") == "SNIP" else False
        track.thumb = self._get_thumbnail(item, self.thumbnail_size)
        track.fanart = track.thumb  # Artwork doubles as fanart for detail views.
        track.media = self._extract_media_url(item)
        track.info = {
            "artist": artist,
            "album": album,
            "genre": item.get("genre", None),
            "date": item.get("display_date", None),
            "description": item.get("description", None),
            "duration": int(item.get("duration") or 0) / 1000,
            "playback_count": item.get("playback_count", 0),
            # Stashed here for the fullscreen "now playing" overlay
            # (waveform style); harmless for other consumers.
            "waveform_url": item.get("waveform_url", ""),
        }

        return track

    @staticmethod
    def fetch_client_id():
        headers = {"Accept-Encoding": "gzip", "User-Agent": ApiV2.api_user_agent}

        # Get the HTML (includes a reference to the JS file we need)
        html = requests.get(
            "https://soundcloud.com/", headers=headers, timeout=(5, 15)
        ).text

        # Extract the HREF to the JS file (which contains the API key)
        matches = re.findall(r"=\"(https://a-v2\.sndcdn\.com/assets/.*.js)\"", html)

        if matches:
            for match in matches:
                # Get the JS
                response = requests.get(match, headers=headers, timeout=(5, 15))
                response.encoding = "utf-8"  # This speeds up `response.text` by 3 seconds

                # Extract the API key
                key = re.search(r"client_application_id:[1-9]+,client_id:\"(\w*)\"", response.text)

                if key:
                    return str(key.group(1))

            raise Exception("Failed to extract client key from js")
        else:
            raise Exception("Failed to extract js href from html")

    @staticmethod
    def _is_preferred_codec(codec, setting):
        return codec["mime_type"] == setting["mime_type"] and \
               codec["protocol"] == setting["protocol"]

    @staticmethod
    def _sanitize_url(url):
        return url.replace("m.soundcloud.com/", "soundcloud.com/")

    @staticmethod
    def _get_thumbnail(item, size):
        """
        Extracts the best available artwork URL from a SoundCloud
        API item (track, playlist or user) and rewrites it to the
        requested thumbnail size.

        availableSizes: [
          [ 20, 't20x20'],
          [ 50, 't50x50'],
          [120, 't120x120'],
          [200, 't200x200'],
          [500, 't500x500']
        ]

        SoundCloud returns `"artwork_url": null` for tracks that don't
        have a custom cover uploaded — a very common case. Python's
        `dict.get(key, default)` returns the explicit None, NOT the
        default, so we use `or` chaining instead. We also fall back to
        the uploading artist's avatar (track["user"]["avatar_url"])
        like soundcloud.com itself does — this is the behaviour users
        expect when they see a track widget on their home screen.
        """
        # Priority order: explicit artwork on the item itself, then
        # the calculated artwork (some endpoints provide this for
        # tracks that inherit from their playlist), then avatar_url
        # for user objects.
        url = (
            item.get("artwork_url")
            or item.get("calculated_artwork_url")
            or item.get("avatar_url")
        )

        # Track without its own artwork? Fall back to the artist's
        # avatar — that's what shows on soundcloud.com.
        if not url:
            user = item.get("user")
            if isinstance(user, dict):
                url = user.get("avatar_url")

        if not url:
            return None

        return re.sub(
            r"^(.*/)(\w+)-([-a-zA-Z0-9]+)-([a-z0-9]+)\.(jpg|png|gif).*$",
            r"\1\2-\3-t{x}x{y}.\5".format(x=size, y=size),
            url
        )

    @staticmethod
    def _get_user_banner(item):
        """
        SoundCloud user objects can include a `visuals` section with the
        profile-page banner (usually 2480x520 px). We use it as fanart so
        the detail view of an artist looks rich instead of showing the
        addon's default fanart.

        Structure:
          "visuals": {"visuals": [{"visual_url": "https://..."}]}
        """
        visuals = item.get("visuals") or {}
        inner = visuals.get("visuals") or []
        if inner and isinstance(inner, list):
            url = inner[0].get("visual_url")
            if url:
                return url
        return None

    @staticmethod
    def _chunks(lst, size):
        for i in range(0, len(lst), size):
            yield lst[i:i + size]
