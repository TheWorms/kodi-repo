# CLAUDE.md — kodi-addon-keyboardbattery

## Rôle
Moniteur de batterie clavier Bluetooth (BlueZ/`bluetoothctl`) avec notifications configurables.

## Stack
Python (`service.py` + `default.py` + `resources/lib/ktools.py`), `settings.xml`, .po FR/EN.

## Build / test
Validation manuelle. Livrable = zip source uniquement.

## Déploiement
GitHub `TheWorms/kodi-addon-keyboardbattery` + Forgejo, distribué via `kodi-repo`.

## Accès hors-repo
- `../kodi-repo` (régénération)
- `../release-addon.sh`

## Pièges
- IDs de langue numériques bruts dans `settings.xml` (pas `$LOCALIZE`).
- `allowempty` obligatoire sur les champs vides.
- Batterie non lisible = comportement NORMAL quand le clavier est déconnecté/replié,
  pas un bug à corriger.

## Dépendances croisées
`kodi-repo`.
