# -*- coding: utf-8 -*-
"""Pause du VPN (addon ProtonVPN de TheWorms) AVANT d'extraire un flux.

Les adresses des flux YouTube sont liées à l'adresse IP qui les a obtenues
(paramètre ip= de l'URL). ProtonVPN ne coupait le tunnel qu'au démarrage de
la lecture : le flux, obtenu par le VPN, était lu sans lui et YouTube le
coupait au bout de 20 à 30 s, une fois le tampon épuisé (HTTP 403).

Wtube demande donc la pause dès qu'il prépare une lecture et attend qu'elle
soit effective (ProtonVPN 0.6.8 ou plus). Rien n'est attendu si ProtonVPN est
absent ou plus ancien, si Wtube n'est pas dans ses exceptions, ou si le VPN
est déjà coupé.

La demande porte un numéro propre à chaque lecture : la fin d'une lecture ne
retire pas la demande de la vidéo enchaînée qui prépare déjà la sienne.
"""
import os
import time

import xbmc
import xbmcgui

ADDON_ID = 'plugin.video.wtube'
PROP_IDS = 'protonvpn.exception_ids'      # addons en exception, séparés par des virgules
PROP_REQUEST = 'protonvpn.pause_request'  # « <id> <échéance epoch> <numéro> »
PROP_READY = 'protonvpn.pause_ready'      # id de l'addon une fois le tunnel coupé
PROP_CONNECTED = 'protonvpn.connected'    # "true" tant que le tunnel est monté
HOLD = 60    # secondes : la demande expire seule si Wtube s'arrête net
WAIT = 6.0   # secondes d'attente maximum de la coupure du tunnel


def _home():
    return xbmcgui.Window(10000)


def wanted(home=None):
    """Wtube est-il dans les exceptions « Pause du VPN » de ProtonVPN ?"""
    ids = (home or _home()).getProperty(PROP_IDS) or ''
    return ADDON_ID in [i.strip() for i in ids.split(',')]


class Pause:
    """Demande de pause d'une lecture : ensure() avant l'extraction,
    release() quand la lecture est finie (ProtonVPN garde la pause pendant
    la lecture d'une vidéo Wtube de lui-même)."""

    def __init__(self, home=None, clock=time.time):
        self.home = home or _home()
        self.clock = clock
        self.token = '%d%04d' % (os.getpid(), int(clock() * 1000) % 10000)
        self.asked = False

    def _value(self, hold):
        return '%s %d %s' % (ADDON_ID, self.clock() + hold, self.token)

    def ensure(self, monitor=None, wait=WAIT):
        """True si le tunnel est coupé pour Wtube (ou l'était déjà), False si
        rien n'a été attendu (pas d'exception, VPN coupé, ProtonVPN muet)."""
        if not wanted(self.home):
            return False
        self.home.setProperty(PROP_REQUEST, self._value(HOLD))
        self.asked = True
        if self.home.getProperty(PROP_CONNECTED) != 'true':
            return self.home.getProperty(PROP_READY) == ADDON_ID
        monitor = monitor or xbmc.Monitor()
        end = self.clock() + wait
        while self.clock() < end:
            if self.home.getProperty(PROP_CONNECTED) != 'true':
                xbmc.log('[wtube] VPN en pause avant l\'extraction', xbmc.LOGINFO)
                return True
            if monitor.waitForAbort(0.2):
                return False
        xbmc.log('[wtube] VPN : pause non confirmée après %d s, extraction quand même' % wait,
                 xbmc.LOGWARNING)
        return False

    def release(self):
        if not self.asked:
            return
        self.asked = False
        parts = (self.home.getProperty(PROP_REQUEST) or '').split()
        if len(parts) >= 3 and parts[0] == ADDON_ID and parts[2] == self.token:
            self.home.clearProperty(PROP_REQUEST)
