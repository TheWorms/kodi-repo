from __future__ import annotations
import time
import xbmcaddon
import xbmcplugin
import xbmcgui
import json
import hashlib
import random

from .downloadutils import DownloadUtils
from .utils import get_emby_url
from .datamanager import DataManager
from .simple_logging import SimpleLogging
from .kodi_utils import HomeWindow
from .dir_functions import process_directory, DirectoryResult
from .tracking import timer


log = SimpleLogging(__name__)
background_items = []
background_current_item = 0


@timer
def set_random_movies() -> None:
    log.debug("set_random_movies Called")

    settings = xbmcaddon.Addon()
    hide_watched = settings.getSetting("hide_watched") == "true"

    url_params = {}
    url_params["Recursive"] = True
    url_params["limit"] = 20
    if hide_watched:
        url_params["IsPlayed"] = False
    url_params["SortBy"] = "Random"
    url_params["IncludeItemTypes"] = "Movie"
    url_params["ImageTypeLimit"] = 0

    url = get_emby_url("{server}/emby/Users/{userid}/Items", url_params)

    download_utils = DownloadUtils()
    download_utils.set_host_domain()
    results = download_utils.download_url(url, suppress=True)
    results = json.loads(results)

    randon_movies_list = []
    if results is not None:
        items = results.get("Items", [])
        for item in items:
            randon_movies_list.append(item.get("Id"))

    random.shuffle(randon_movies_list)
    movies_list_string = ",".join(randon_movies_list)
    home_window = HomeWindow()
    m = hashlib.md5()
    m.update(movies_list_string.encode("utf-8"))
    new_widget_hash = m.hexdigest()

    log.debug("set_random_movies : {0}", movies_list_string)
    log.debug("set_random_movies : {0}", new_widget_hash)
    home_window.set_property("random-movies", movies_list_string)
    home_window.set_property("random-movies-changed", new_widget_hash)


def set_background_image(force: bool = False) -> None:
    log.debug("set_background_image Called forced={0}", force)

    global background_current_item
    global background_items

    if force:
        background_current_item = 0
        del background_items
        background_items = []

    if len(background_items) == 0:
        log.debug(
            "set_background_image: Need to load more backgrounds {0} - {1}",
            len(background_items),
            background_current_item,
        )

        url_params = {}
        url_params["Recursive"] = True
        # url_params["limit"] = 60
        url_params["SortBy"] = "Random"
        url_params["IncludeItemTypes"] = "Movie,Series"
        url_params["ImageTypeLimit"] = 1

        url = get_emby_url("{server}/emby/Users/{userid}/Items", url_params)

        download_utils = DownloadUtils()
        download_utils.set_host_domain()

        server = download_utils.get_server()
        results = download_utils.download_url(url, suppress=True)
        results = json.loads(results)

        if results is not None:
            items = results.get("Items", [])
            background_current_item = 0
            background_items = []

            settings = xbmcaddon.Addon()
            max_image_width = int(settings.getSetting("max_image_width"))

            for item in items:
                bg_image = download_utils.get_artwork(
                    item, "Backdrop", server=server, maxwidth=max_image_width
                )
                if bg_image:
                    label = item.get("Name")
                    item_background = {}
                    item_background["image"] = bg_image
                    item_background["name"] = label
                    background_items.append(item_background)

            random.shuffle(background_items)

        log.debug(
            "set_background_image: Loaded {0} more backgrounds", len(background_items)
        )

    if len(background_items) > 0:
        bg_image = background_items[background_current_item].get("image")
        label = background_items[background_current_item].get("name")
        log.debug(
            "set_background_image: {0} - {1} - {2}",
            background_current_item,
            label,
            bg_image,
        )

        background_current_item += 1
        if background_current_item >= len(background_items):
            background_current_item = 0

        home_window = HomeWindow()
        home_window.set_property("random-gb", bg_image)
        home_window.set_property("random-gb-label", label)


@timer
def check_for_new_content() -> None:
    log.info("check_for_new_content called")

    home_window = HomeWindow()
    # EmbyCon FR: valeur UNIQUE a chaque appel (precision sous-seconde). Les
    # widgets d'accueil se rechargent parce que leur URL contient
    # &reload=<embycon_widget_reload> : quand la valeur change, le chemin change
    # et Kodi recharge le widget. Avec l'ancienne precision de 1 seconde, deux
    # marquages rapproches (ou un marquage juste apres un refresh) donnaient la
    # meme valeur -> aucun rechargement. On garantit desormais un changement.
    ts = repr(time.time())
    home_window.set_property("embycon_widget_reload", ts)
    home_window.set_property("random-movies-changed", ts)


@timer
def get_widget_content_cast(handle: int, params: dict) -> int:
    log.debug("get_widget_content_cast Called: {0}", params)
    download_utils = DownloadUtils()
    server = download_utils.get_server()
    if server is None:
        log.error("get_widget_content_cast: No server info")
        xbmcplugin.addDirectoryItems(handle, [])
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
        return 0

    item_id = params["id"]
    data_manager = DataManager()
    result = data_manager.get_content(
        "{server}/emby/Users/{userid}/Items/" + item_id + "?format=json"
    )
    log.debug("ItemInfo: {0}", result)

    if not result:
        xbmcplugin.addDirectoryItems(handle, [])
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
        return 0

    if (
        result.get("Type", "") in ["Episode", "Season"]
        and params.get("auto", "true") == "true"
    ):
        series_id = result.get("SeriesId")
        if series_id:
            params["id"] = series_id
            return get_widget_content_cast(handle, params)

    list_items = []
    if result is not None:
        people = result.get("People", [])
    else:
        people = []

    for person in people:
        # if (person.get("Type") == "Director"):
        #     director = director + person.get("Name") + ' '
        # if (person.get("Type") == "Writing"):
        #     writer = person.get("Name")
        # if (person.get("Type") == "Writer"):
        #    writer = person.get("Name")
        if person.get("Type") == "Actor":
            person_name = person.get("Name")
            person_role = person.get("Role")
            person_id = person.get("Id")
            person_tag = person.get("PrimaryImageTag")
            person_thumbnail = None
            if person_tag:
                person_thumbnail = download_utils.image_url(
                    person_id, "Primary", 0, 400, 400, person_tag, server=server
                )

            list_item = xbmcgui.ListItem(label=person_name, offscreen=True)
            list_item.setProperty("id", person_id)

            if person_thumbnail:
                art_links = {}
                art_links["thumb"] = person_thumbnail
                art_links["poster"] = person_thumbnail
                list_item.setArt(art_links)

            # labels = {}
            # labels["mediatype"] = "artist"
            # list_item.setInfo(type="music", infoLabels=labels)

            if person_role:
                list_item.setLabel2(person_role)

            item_tupple = ("", list_item, False)
            list_items.append(item_tupple)

    xbmcplugin.setContent(handle, "artists")
    xbmcplugin.addDirectoryItems(handle, list_items)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
    return 0


@timer
def get_widget_content(handle: int, params: dict) -> int:
    log.debug("getWigetContent Called: {0}", params)

    settings = xbmcaddon.Addon()
    hide_watched = settings.getSetting("hide_watched") == "true"

    widget_type = params.get("type")
    if widget_type is None:
        log.error("getWigetContent type not set")
        return 0

    log.debug("widget_type: {0}", widget_type)

    url_verb = "{server}/emby/Users/{userid}/Items"
    url_params = {}
    url_params["Limit"] = "{ItemLimit}"
    url_params["format"] = "json"
    url_params["Fields"] = "{field_filters}"
    url_params["ImageTypeLimit"] = 1
    url_params["IsMissing"] = False

    if widget_type == "recent_movies":
        xbmcplugin.setContent(handle, "movies")
        url_params["Recursive"] = True
        url_params["SortBy"] = "DateCreated"
        url_params["SortOrder"] = "Descending"
        url_params["Filters"] = "IsNotFolder"
        if hide_watched:
            url_params["IsPlayed"] = False
        url_params["IsVirtualUnaired"] = False
        url_params["IncludeItemTypes"] = "Movie"

    elif widget_type == "inprogress_movies":
        xbmcplugin.setContent(handle, "movies")
        url_params["Recursive"] = True
        url_params["SortBy"] = "DatePlayed"
        url_params["SortOrder"] = "Descending"
        url_params["Filters"] = "IsResumable"
        url_params["IsVirtualUnaired"] = False
        url_params["IncludeItemTypes"] = "Movie"

    elif widget_type == "random_movies":
        xbmcplugin.setContent(handle, "movies")

        home_window = HomeWindow()
        random_movies = home_window.get_property("random-movies")
        if not random_movies:
            xbmcplugin.addDirectoryItems(handle, [])
            xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
            return 0
        url_params["Ids"] = random_movies

    elif widget_type == "recent_tvshows":
        xbmcplugin.setContent(handle, "tvshows")
        # EmbyCon FR: on utilise /Items (comme recent_movies) et NON /Items/Latest.
        # L'endpoint /Items/Latest ignore le filtre serveur IsPlayed=false : les
        # episodes deja vus y restaient affiches. /Items respecte le filtre et
        # renvoie un statut "vu" correct par episode.
        url_params["Recursive"] = True
        url_params["SortBy"] = "DateCreated"
        url_params["SortOrder"] = "Descending"
        url_params["Filters"] = "IsNotFolder"
        if hide_watched:
            url_params["IsPlayed"] = False
        url_params["IsVirtualUnaired"] = False
        url_params["IncludeItemTypes"] = "Episode"

    elif widget_type == "recent_episodes":
        xbmcplugin.setContent(handle, "episodes")
        url_params["Recursive"] = True
        url_params["SortBy"] = "DateCreated"
        url_params["SortOrder"] = "Descending"
        url_params["Filters"] = "IsNotFolder"
        if hide_watched:
            url_params["IsPlayed"] = False
        url_params["IsVirtualUnaired"] = False
        url_params["IncludeItemTypes"] = "Episode"

    elif widget_type == "inprogress_episodes":
        xbmcplugin.setContent(handle, "episodes")
        url_params["Recursive"] = True
        url_params["SortBy"] = "DatePlayed"
        url_params["SortOrder"] = "Descending"
        url_params["Filters"] = "IsResumable"
        url_params["IsVirtualUnaired"] = False
        url_params["IncludeItemTypes"] = "Episode"

    elif widget_type == "nextup_episodes":
        xbmcplugin.setContent(handle, "episodes")
        url_verb = "{server}/emby/Shows/NextUp"
        url_params["Limit"] = "{ItemLimit}"
        url_params["userid"] = "{userid}"
        url_params["Recursive"] = True
        url_params["Fields"] = "{field_filters}"
        url_params["format"] = "json"
        url_params["ImageTypeLimit"] = 1
        url_params["Legacynextup"] = "true"

    elif widget_type == "movie_recommendations":
        suggested_items_url_params = {}
        suggested_items_url_params["userId"] = "{userid}"
        suggested_items_url_params["categoryLimit"] = 15
        suggested_items_url_params["ItemLimit"] = 20
        suggested_items_url_params["ImageTypeLimit"] = 0
        suggested_items_url = get_emby_url(
            "{server}/emby/Movies/Recommendations", suggested_items_url_params
        )

        data_manager = DataManager()
        suggested_items = data_manager.get_content(suggested_items_url)
        ids = []
        set_id = 0
        while len(ids) < 20 and suggested_items:
            items = suggested_items[set_id]
            log.debug(
                "BaselineItemName : {0} - {1}", set_id, items.get("BaselineItemName")
            )
            items = items["Items"]
            rand = random.randint(0, len(items) - 1)
            # log.debug("random suggestions index : {0} {1}", rand, set_id)
            item = items[rand]
            if (
                item["Type"] == "Movie"
                and item["Id"] not in ids
                and (not item["UserData"]["Played"] or not hide_watched)
            ):
                # log.debug("random suggestions adding : {0}", item["Id"])
                ids.append(item["Id"])
            # else:
            #     log.debug("random suggestions not valid : {0} - {1} - {2}", item["Id"], item["Type"], item["UserData"]["Played"])
            del items[rand]
            # log.debug("items len {0}", len(items))
            if len(items) == 0:
                # log.debug("Removing Set {0}", set_id)
                del suggested_items[set_id]
            set_id += 1
            if set_id >= len(suggested_items):
                set_id = 0

        id_list = ",".join(ids)
        log.debug("Recommended Items : {0}", len(ids), id_list)
        url_params["Ids"] = id_list

    items_url = get_emby_url(url_verb, url_params)

    directory_result: DirectoryResult | None = process_directory(
        items_url, None, params, False
    )
    if (
        directory_result is None
        or directory_result.dir_items is None
        or len(directory_result.dir_items) == 0
    ):
        xbmcplugin.addDirectoryItems(handle, [])
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
        return 0

    dir_items = directory_result.dir_items
    # EmbyCon FR: filtrage cote client des episodes deja vus. L'endpoint
    # /Items/Latest (widget recent_tvshows) ignore le filtre serveur IsPlayed ;
    # on retire donc ici les episodes vus quand "masquer les vus" est actif,
    # ce qui garantit qu'un episode deja lu ne reste jamais dans la liste.
    if hide_watched and widget_type in ("recent_tvshows", "recent_episodes"):
        dir_items = [gi for gi in dir_items if gi.play_count == 0]

    list_items = [item.as_tuple() for item in dir_items]
    detected_type = directory_result.detected_type

    # remove resumable items from next up
    """
    if widget_type == "nextup_episodes":
        filtered_list = []
        for item in list_items:
            vit = item[1].getVideoInfoTag()
            resume_time = vit.getResumeTime()
            if resume_time is None or float(resume_time) == 0.0:
                filtered_list.append(item)
        list_items = filtered_list
    """

    if detected_type is not None:
        # if the media type is not set then try to use the detected type
        log.debug("Detected content type: {0}", detected_type)
        content_type = None

        if detected_type == "Movie":
            content_type = "movies"
        elif detected_type == "Episode":
            content_type = "episodes"
        elif detected_type == "Series":
            content_type = "tvshows"
        elif (
            detected_type == "Music"
            or detected_type == "Audio"
            or detected_type == "Musicalbum"
        ):
            content_type = "songs"

        if content_type:
            xbmcplugin.setContent(handle, content_type)

    xbmcplugin.addDirectoryItems(handle, list_items)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)

    return len(list_items)
