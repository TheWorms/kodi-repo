# -*- coding: utf-8 -*-

#################################################################################################
from __future__ import annotations

import json
import threading

import xbmc
import xbmcgui

from .functions import play_action
from .simple_logging import SimpleLogging
from . import clientinfo
from . import downloadutils
from .jsonrpc import JsonRpc
from .kodi_utils import HomeWindow
from .websocket import WebSocketApp, enableTrace
from .library_change_monitor import LibraryChangeMonitor

log = SimpleLogging(__name__)


class WebSocketClient(threading.Thread):
    _shared_state = {}

    _client = None
    _stop_websocket: bool = False
    _library_monitor: LibraryChangeMonitor | None = None

    def __init__(self, library_change_monitor: LibraryChangeMonitor) -> None:
        self.__dict__ = self._shared_state
        self.monitor = xbmc.Monitor()

        self.client_info = clientinfo.ClientInformation()
        self.device_id = self.client_info.get_device_id()

        self._library_monitor = library_change_monitor

        threading.Thread.__init__(self)

    def on_message(self, message: str) -> None:
        result = json.loads(message)
        message_type = result["MessageType"]

        if message_type == "Play":
            data = result["Data"]
            self._play(data)

        elif message_type == "Playstate":
            data = result["Data"]
            self._playstate(data)

        elif message_type == "UserDataChanged":
            data = result["Data"]
            self._library_changed(data)

        elif message_type == "LibraryChanged":
            data = result["Data"]
            self._library_changed(data)

        elif message_type == "GeneralCommand":
            data = result["Data"]
            self._general_commands(data)

        else:
            log.debug("WebSocket Message Type: {0}", message)

    def _library_changed(self, data: dict) -> None:
        log.debug("Library_Changed: {0}", data)
        if self._library_monitor is not None:
            self._library_monitor.check_for_updates()

    def _play(self, data: dict) -> None:
        item_ids = data["ItemIds"]
        command = data["PlayCommand"]

        if command == "PlayNow":
            home_screen = HomeWindow()
            home_screen.set_property("skip_select_user", "true")

            startat = data.get("StartPositionTicks", -1)
            log.debug("WebSocket Message PlayNow: {0}", data)

            media_source_id = data.get("MediaSourceId", "")
            subtitle_stream_index = data.get("SubtitleStreamIndex", None)
            audio_stream_index = data.get("AudioStreamIndex", None)

            start_index = data.get("StartIndex", 0)

            if start_index > 0 and start_index < len(item_ids):
                item_ids = item_ids[start_index:]

            if len(item_ids) == 1:
                item_ids = item_ids[0]

            params = {}
            params["item_id"] = item_ids
            params["auto_resume"] = str(startat)
            params["media_source_id"] = media_source_id
            params["subtitle_stream_index"] = subtitle_stream_index
            params["audio_stream_index"] = audio_stream_index
            play_action(params)

    def _playstate(self, data: dict) -> None:
        command = data["Command"]
        player = xbmc.Player()

        actions = {
            "Stop": player.stop,
            "Unpause": player.pause,
            "Pause": player.pause,
            "PlayPause": player.pause,
            "NextTrack": player.playnext,
            "PreviousTrack": player.playprevious,
        }
        if command == "Seek":
            if player.isPlaying():
                seek_to = data["SeekPositionTicks"]
                seek_time = seek_to / 10000000.0
                player.seekTime(seek_time)
                log.debug("Seek to {0}", seek_time)

        elif command in actions:
            actions[command]()
            log.debug("Command: {0} completed", command)

        else:
            log.debug("Unknown command: {0}", command)
            return

    def _general_commands(self, data: dict) -> None:
        command = data["Name"]
        arguments = data["Arguments"]

        if command in (
            "Mute",
            "Unmute",
            "SetVolume",
            "SetSubtitleStreamIndex",
            "SetAudioStreamIndex",
            "SetRepeatMode",
        ):
            player = xbmc.Player()
            # These commands need to be reported back
            if command == "Mute":
                xbmc.executebuiltin("Mute")

            elif command == "Unmute":
                xbmc.executebuiltin("Mute")

            elif command == "SetVolume":
                volume = arguments["Volume"]
                xbmc.executebuiltin("SetVolume(%s[,showvolumebar])" % volume)

            elif command == "SetAudioStreamIndex":
                index = int(arguments["Index"])
                player.setAudioStream(index - 1)

            elif command == "SetSubtitleStreamIndex":
                index = int(arguments["Index"])
                player.setSubtitleStream(index - 1)

            elif command == "SetRepeatMode":
                mode = arguments["RepeatMode"]
                xbmc.executebuiltin("PlayerControl(%s)" % mode)

        elif command == "DisplayMessage":
            # header = arguments['Header']
            text = arguments["Text"]
            # show notification here
            log.debug("WebSocket DisplayMessage: {0}", text)
            xbmcgui.Dialog().notification("EmbyCon", text)

        elif command == "SendString":
            params = {"text": arguments["String"], "done": False}
            JsonRpc("Input.SendText").execute(params)

        elif command in ("MoveUp", "MoveDown", "MoveRight", "MoveLeft"):
            # Commands that should wake up display
            actions = {
                "MoveUp": "Input.Up",
                "MoveDown": "Input.Down",
                "MoveRight": "Input.Right",
                "MoveLeft": "Input.Left",
            }
            JsonRpc(actions[command]).execute({})

        elif command == "GoHome":
            JsonRpc("GUI.ActivateWindow").execute({"window": "home"})

        elif command == "Guide":
            JsonRpc("GUI.ActivateWindow").execute({"window": "tvguide"})

        else:
            builtin = {
                "ToggleFullscreen": "Action(FullScreen)",
                "ToggleOsdMenu": "Action(OSD)",
                "ToggleContextMenu": "Action(ContextMenu)",
                "Select": "Action(Select)",
                "Back": "Action(back)",
                "PageUp": "Action(PageUp)",
                "NextLetter": "Action(NextLetter)",
                "GoToSearch": "VideoLibrary.Search",
                "GoToSettings": "ActivateWindow(Settings)",
                "PageDown": "Action(PageDown)",
                "PreviousLetter": "Action(PrevLetter)",
                "TakeScreenshot": "TakeScreenshot",
                "ToggleMute": "Mute",
                "VolumeUp": "Action(VolumeUp)",
                "VolumeDown": "Action(VolumeDown)",
            }
            if command in builtin:
                xbmc.executebuiltin(builtin[command])

    def on_close(self) -> None:
        log.debug("Closed")

    def on_open(self) -> None:
        log.debug("Connected")
        self.post_capabilities()

    def on_error(self, error: Exception) -> None:
        log.error("Error: {0}", error)

    def run(self) -> None:
        # websocket.enableTrace(True)
        download_utils = downloadutils.DownloadUtils()

        token = None
        while token is None or token == "":
            download_utils.set_host_domain()
            token = download_utils.authenticate()
            if self.monitor.waitForAbort(10):
                return

        # Get the appropriate prefix for the websocket
        download_utils.set_host_domain()
        server = download_utils.get_server()
        if server is None:
            log.error("No server found for WebSocketClient")
            return

        if "https" in server:
            server = server.replace("https", "wss")
        else:
            server = server.replace("http", "ws")

        websocket_url = "%s/embywebsocket?api_key=%s&deviceId=%s" % (
            server,
            token,
            self.device_id,
        )
        log.debug("websocket url: {0}", websocket_url)

        enableTrace(True)

        self._client = WebSocketApp(
            websocket_url,
            on_open=self.on_open,
            on_message=self.on_message,
            on_error=self.on_error,
            on_close=self.on_close,
        )
        log.debug("Starting WebSocketClient")

        while not self.monitor.abortRequested():
            self._client.run_forever(ping_interval=10)

            if self._stop_websocket:
                break

            if self.monitor.waitForAbort(20):
                # Abort was requested, exit
                break

            log.debug("Reconnecting WebSocket")

        log.debug("WebSocketClient Stopped")

    def stop_client(self) -> None:
        self._stop_websocket = True
        if self._client is not None:
            self._client.close()
        log.debug("Stopping WebSocket (stop_client called)")

    def post_capabilities(self) -> None:
        download_utils = downloadutils.DownloadUtils()
        download_utils.post_capabilities()
