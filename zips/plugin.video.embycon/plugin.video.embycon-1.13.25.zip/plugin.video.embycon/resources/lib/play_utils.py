# Gnu General Public License - see LICENSE.TXT
from __future__ import annotations

import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs

from datetime import timedelta
import json
import os
import base64

from .simple_logging import SimpleLogging
from .downloadutils import DownloadUtils
from .resume_dialog import ResumeDialog
from .utils import PlayUtils, get_art, send_event_notification, convert_size
from .kodi_utils import HomeWindow
from .translation import string_load
from .datamanager import DataManager, clear_old_cache_data
from .item_functions import (
    extract_item_info,
    add_gui_item,
    GuiItem,
    DisplayOptions,
    GuiOptions,
)
from .clientinfo import ClientInformation
from .functions import delete, mark_item_watched
from .cache_images import CacheArtwork
from .picture_viewer import PictureViewer
from .tracking import timer
from .skip_intro_dialog import SkipIntroMonitor, SkipCreditsMonitor

log = SimpleLogging(__name__)


def play_all_files(
    items: list,
    auto_resume: str,
    monitor: PlaybackMonitorService,
    play_items: bool = True,
) -> xbmc.PlayList | None:
    log.debug("playAllFiles called with items: {0}", items)
    download_utils = DownloadUtils()
    server = download_utils.get_server()
    if server is None or server == "":
        log.debug("playAllFiles: No server found, cannot play files")
        return None

    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()

    settings = xbmcaddon.Addon()
    max_image_width = int(settings.getSetting("max_image_width"))

    for item in items:
        item_id = item.get("Id")

        # get playback info
        playback_info = download_utils.get_item_playback_info(item_id, False)
        if playback_info is None:
            log.debug(
                "playback_info was None, could not get MediaSources so can not play!"
            )
            return None
        if playback_info.get("ErrorCode") is not None:
            error_string = playback_info.get("ErrorCode", "code_unknown")
            xbmcgui.Dialog().notification(
                string_load(30316),
                error_string,
                icon="special://home/addons/plugin.video.embycon/icon.png",
            )
            return None

        play_session_id = playback_info.get("PlaySessionId", "")
        live_stream_id = playback_info.get("LiveStreamId", "")

        # select the media source to use
        sources = playback_info.get("MediaSources")
        if sources is None or len(sources) == 0:
            log.debug("Play Failed! There is no MediaSources data!")
            return None

        selected_media_source = sources[0]
        source_id = selected_media_source.get("Id")

        play_result = PlayUtils().get_play_url(selected_media_source)
        playurl = play_result.playurl
        playback_type = play_result.playback_type
        listitem_props = play_result.listitem_props
        log.info(
            "Play URL: {0} PlaybackType: {1} ListItem Properties: {2}",
            playurl,
            playback_type,
            listitem_props,
        )

        if playurl is None:
            return None

        playback_type_string = "DirectPlay"
        if playback_type == "2":
            playback_type_string = "Transcode"
        elif playback_type == "1":
            playback_type_string = "DirectStream"

        # add the playback type into the overview
        if item.get("Overview", None) is not None:
            item["Overview"] = playback_type_string + "\n" + item.get("Overview")
        else:
            item["Overview"] = playback_type_string

        # add title decoration is needed
        item_title = item.get("Name", string_load(30280))

        use_prem_date_for_added = (
            settings.getSetting("use_prem_date_for_added") == "true"
        )
        gui_options = GuiOptions(
            server=server,
            name_format=None,
            name_format_type="",
            max_image_width=max_image_width,
            use_prem_date_for_added=use_prem_date_for_added,
        )
        item_details = extract_item_info(
            item, gui_options, download_utils=download_utils
        )

        # create ListItem
        display_options = DisplayOptions()
        display_options.addCounts = False
        display_options.addResumePercent = False
        display_options.addSubtitleAvailable = False

        gui_item: GuiItem | None = add_gui_item(
            "", item_details, display_options, False
        )
        if gui_item is None:
            log.debug("playAllFiles: gui_item was None, cannot play item")
            continue

        list_item: xbmcgui.ListItem = gui_item.list_item
        # list_item = xbmcgui.ListItem(label=item_title)

        # add playurl and data to the monitor
        data = {}
        data["item_id"] = item_id
        data["source_id"] = source_id
        data["playback_type"] = playback_type_string
        data["play_session_id"] = play_session_id
        data["live_stream_id"] = live_stream_id
        data["play_action_type"] = "play_all"
        monitor.played_information[playurl] = data
        log.debug("Add to played_information: {0}", monitor.played_information)

        list_item.setPath(playurl)
        list_item = set_list_item_props(
            item_id,
            list_item,
            item,
            server,
            listitem_props,
            item_title,
            max_image_width,
        )

        playlist.add(playurl, list_item)

    if play_items:
        # auto_resume = "9000000000" # 15 min
        auto_resume_int: int = int(auto_resume)
        seek_time = 0
        # process user data for resume points
        if auto_resume_int != -1:
            seek_time = (auto_resume_int / 1000) / 10000

        log.debug(
            "play_all_files auto_resume : {0} seekto : {1}", auto_resume_int, seek_time
        )

        player = xbmc.Player()
        player.play(playlist)

        if seek_time != 0:
            player.pause()
            xbmc_monitor: xbmc.Monitor = xbmc.Monitor()
            count = 0
            while (
                not player.isPlaying()
                and not xbmc_monitor.abortRequested()
                and count != 100
            ):
                count = count + 1
                xbmc.sleep(100)

            if count == 100 or not player.isPlaying() or xbmc_monitor.abortRequested():
                log.info(
                    "PlaybackResumeAction : Playback item did not get to a play state in 10 seconds so exiting"
                )
                player.stop()
                return None

            log.info("PlaybackResumeAction : Playback is Running")

            seek_to_time = seek_time
            target_seek = seek_to_time - 10

            count = 0
            max_loops = 2 * 120
            while (
                not xbmc_monitor.abortRequested()
                and player.isPlaying()
                and count < max_loops
            ):
                log.info("PlaybackResumeAction : Seeking to : {0}", seek_to_time)
                player.seekTime(seek_to_time)
                current_position = player.getTime()
                if current_position >= target_seek:
                    break
                log.info(
                    "PlaybackResumeAction : target:{0} current:{1}",
                    target_seek,
                    current_position,
                )
                count = count + 1
                xbmc.sleep(500)

            if count == max_loops:
                log.info(
                    "PlaybackResumeAction : Playback could not seek to required position"
                )
                player.stop()
            else:
                count = 0
                while bool(xbmc.getCondVisibility("Player.Paused")) and count < 10:
                    log.info("PlaybackResumeAction : Unpausing playback")
                    player.pause()
                    xbmc.sleep(1000)
                    count = count + 1

                if count == 10:
                    log.info("PlaybackResumeAction : Could not unpause")
                else:
                    log.info("PlaybackResumeAction : Playback resumed")

        return None
    return playlist


def play_list_of_items(
    id_list: list[str], auto_resume: str, monitor: PlaybackMonitorService
) -> xbmc.PlayList | None:
    log.debug("Loading  all items in the list")
    data_manager = DataManager()
    items = []

    for item_id in id_list:
        url = "{server}/emby/Users/{userid}/Items/%s?format=json"
        url = url % (item_id,)
        result = data_manager.get_content(url)
        if result is None:
            log.debug("Playfile item was None, so can not play!")
            return None
        items.append(result)

    return play_all_files(items, auto_resume, monitor)


def add_to_playlist(play_info: dict[str, str], monitor: PlaybackMonitorService) -> None:
    log.debug("Adding item to playlist : {0}", play_info)

    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    download_utils = DownloadUtils()
    server = download_utils.get_server()
    if server is None or server == "":
        log.debug("No server found, cannot add to playlist")
        return

    item_id = play_info.get("item_id")
    if item_id is None:
        log.debug("No item_id in play_info, cannot add to playlist")
        return

    url = "{server}/emby/Users/{userid}/Items/%s?format=json"
    url = url % (item_id,)
    data_manager = DataManager()
    item = data_manager.get_content(url)
    if item is None:
        log.debug("Playfile item was None, so can not play!")
        return

    # get playback info
    playback_info = download_utils.get_item_playback_info(item_id, False)
    if playback_info is None:
        log.debug("playback_info was None, could not get MediaSources so can not play!")
        return
    if playback_info.get("ErrorCode") is not None:
        error_string = playback_info.get("ErrorCode", "code_unknown")
        xbmcgui.Dialog().notification(
            string_load(30316),
            error_string,
            icon="special://home/addons/plugin.video.embycon/icon.png",
        )
        return

    # play_session_id = id_generator()
    play_session_id = playback_info.get("PlaySessionId", "")
    live_stream_id = playback_info.get("LiveStreamId", "")

    # select the media source to use
    # sources = item.get("MediaSources")
    sources = playback_info.get("MediaSources")
    if sources is None or len(sources) == 0:
        log.debug("Play Failed! There is no MediaSources data!")
        return

    selected_media_source = sources[0]
    source_id = selected_media_source.get("Id")

    play_result = PlayUtils().get_play_url(selected_media_source)
    playurl = play_result.playurl
    playback_type = play_result.playback_type
    listitem_props = play_result.listitem_props
    log.info(
        "Play URL: {0} PlaybackType: {1} ListItem Properties: {2}",
        playurl,
        playback_type,
        listitem_props,
    )

    if playurl is None:
        return

    playback_type_string = "DirectPlay"
    if playback_type == "2":
        playback_type_string = "Transcode"
    elif playback_type == "1":
        playback_type_string = "DirectStream"

    # add the playback type into the overview
    if item.get("Overview", None) is not None:
        item["Overview"] = playback_type_string + "\n" + item.get("Overview", "")
    else:
        item["Overview"] = playback_type_string

    # add title decoration is needed
    item_title = item.get("Name", string_load(30280))
    list_item = xbmcgui.ListItem(label=item_title)

    settings = xbmcaddon.Addon()
    max_image_width = int(settings.getSetting("max_image_width"))

    # add playurl and data to the monitor
    data = {}
    data["item_id"] = item_id
    data["source_id"] = source_id
    data["playback_type"] = playback_type_string
    data["play_session_id"] = play_session_id
    data["live_stream_id"] = live_stream_id
    data["play_action_type"] = "play_all"
    monitor.played_information[playurl] = data
    log.debug("Add to played_information: {0}", monitor.played_information)

    list_item.setPath(playurl)
    list_item = set_list_item_props(
        item_id,
        list_item,
        item,
        server,
        listitem_props,
        item_title,
        maxwidth=max_image_width,
    )

    playlist.add(playurl, list_item)


def get_playback_intros(item_id: str) -> list[dict] | None:
    log.debug("get_playback_intros")
    data_manager = DataManager()
    url = "{server}/emby/Users/{userid}/Items/%s/Intros" % item_id
    intro_items = data_manager.get_content(url)

    if intro_items is None:
        log.debug("get_playback_intros failed!")
        return None

    into_list = []
    intro_items = intro_items["Items"]
    for into in intro_items:
        into_list.append(into)

    return into_list


@timer
def play_file(
    play_info: dict[str, str], monitor: PlaybackMonitorService
) -> xbmc.PlayList | None:
    item_id = play_info.get("item_id")
    if item_id is None:
        log.debug("No item_id in play_info, cannot play file")
        return None

    home_window = HomeWindow()
    last_url = home_window.get_property("last_content_url")
    if last_url:
        home_window.set_property("skip_cache_for_" + last_url, "true")

    auto_resume = play_info.get("auto_resume", "-1")
    action = play_info.get("action", "play")
    if action == "add_to_playlist":
        add_to_playlist(play_info, monitor)
        return None

    # if this is a list of items add them all to the play list
    if isinstance(item_id, list):
        return play_list_of_items(item_id, auto_resume, monitor)

    force_transcode: bool = bool(play_info.get("force_transcode", False))
    media_source_id: str = play_info.get("media_source_id", "")
    subtitle_stream_index = play_info.get("subtitle_stream_index", None)
    audio_stream_index = play_info.get("audio_stream_index", None)

    log.debug(
        "playFile id({0}) resume({1}) force_transcode({2})",
        item_id,
        auto_resume,
        force_transcode,
    )

    settings = xbmcaddon.Addon()
    addon_path = settings.getAddonInfo("path")
    force_auto_resume = settings.getSetting("forceAutoResume") == "true"
    jump_back_amount = int(settings.getSetting("jump_back_amount"))
    play_cinema_intros = settings.getSetting("play_cinema_intros") == "true"
    auto_play_first_version = settings.getSetting("auto_play_first_version") == "true"

    download_utils = DownloadUtils()
    server = download_utils.get_server()
    if server is None or server == "":
        log.debug("No server found, cannot play file")
        return None

    url = "{server}/emby/Users/{userid}/Items/%s?fields=Chapters&format=json" % (
        item_id,
    )
    data_manager = DataManager()
    result = data_manager.get_content(url)
    log.debug("Playfile item: {0}", dict(result))

    if result is None:
        log.debug("Playfile item was None, so can not play!")
        return None

    # if this is a season, playlist or album then play all items in that parent
    if result.get("Type") in ["Season", "MusicAlbum", "Playlist"]:
        log.debug("PlayAllFiles for parent item id: {0}", item_id)
        url = "".join(
            [
                "{server}/emby/Users/{userid}/items",
                "?ParentId=%s",
                "&Fields={field_filters}",
                "&format=json",
            ]
        )
        url = url % (item_id,)
        result = data_manager.get_content(url)
        log.debug("PlayAllFiles items: {0}", result)

        # process each item
        items = result["Items"]
        if items is None:
            items = []
        return play_all_files(items, "-1", monitor)

    # if this is a program from live tv epg then play the actual channel
    if result.get("Type") == "Program":
        channel_id = result.get("ChannelId")
        url = "{server}/emby/Users/{userid}/Items/%s?format=json" % (channel_id,)
        result = data_manager.get_content(url)
        item_id = result["Id"]

    if result.get("Type") == "Photo":
        play_url = "%s/emby/Items/%s/Images/Primary"
        play_url = play_url % (server, item_id)

        plugin_path = xbmcvfs.translatePath(
            os.path.join(xbmcaddon.Addon().getAddonInfo("path"))
        )
        action_menu = PictureViewer("PictureViewer.xml", plugin_path, "default", "720p")
        action_menu.setPicture(play_url)
        action_menu.doModal()
        return None

    # get playback info from the server using the device profile
    playback_info = download_utils.get_item_playback_info(item_id, force_transcode)
    if playback_info is None:
        log.debug("playback_info was None, could not get MediaSources so can not play!")
        return None
    if playback_info.get("ErrorCode") is not None:
        error_string = playback_info.get("ErrorCode", "code_unknown")
        xbmcgui.Dialog().notification(
            string_load(30316),
            error_string,
            icon="special://home/addons/plugin.video.embycon/icon.png",
        )
        return None

    play_session_id = playback_info.get("PlaySessionId", "")

    # select the media source to use
    media_sources = playback_info.get("MediaSources")
    selected_media_source = None

    if media_sources is None or len(media_sources) == 0:
        log.debug("Play Failed! There is no MediaSources data!")
        return None

    if len(media_sources) == 1 or auto_play_first_version:
        selected_media_source = media_sources[0]

    elif media_source_id != "":
        for source in media_sources:
            if source.get("Id", "na") == media_source_id:
                selected_media_source = source
                break

    elif len(media_sources) > 1:
        items = []
        for source in media_sources:
            label = source.get("Name", {})
            label2 = __build_label2_from(source)
            items.append(xbmcgui.ListItem(label=label, label2=label2))
        dialog = xbmcgui.Dialog()
        resp = dialog.select(string_load(30309), items, useDetails=True)
        if resp > -1:
            selected_media_source = media_sources[resp]
        else:
            log.debug("Play Aborted, user did not select a MediaSource")
            return None

    if selected_media_source is None:
        log.debug("Play Aborted, MediaSource was None")
        return None

    source_id = selected_media_source.get("Id")
    live_stream_id = selected_media_source.get("LiveStreamId", "")
    seek_time = 0
    auto_resume = int(auto_resume)
    user_data = result.get("UserData", {})
    playback_pos = int(user_data.get("PlaybackPositionTicks", -1))

    # process user data for resume points
    if auto_resume != -1:
        seek_time = (auto_resume / 1000) / 10000

    elif force_auto_resume:
        if playback_pos > 0:
            reasonable_ticks = playback_pos / 1000
            seek_time = reasonable_ticks / 10000

    else:
        user_data = result.get("UserData")
        if playback_pos > 0:
            reasonable_ticks = playback_pos / 1000
            seek_time = int(reasonable_ticks / 10000)
            display_time = str(timedelta(seconds=seek_time))

            resume_dialog = ResumeDialog(
                "ResumeDialog.xml", addon_path, "default", "720p"
            )
            resume_dialog.setResumeTime("Resume from " + display_time)
            resume_dialog.doModal()
            resume_result = resume_dialog.getResumeAction()
            del resume_dialog
            log.debug("Resume Dialog Result: {0}", resume_result)

            # check system settings for play action
            # if prompt is set ask to set it to auto resume
            # remove for now as the context dialog is now handeled in the monitor thread
            # params = {"setting": "myvideos.selectaction"}
            # setting_result = json_rpc('Settings.getSettingValue').execute(params)
            # log.debug("Current Setting (myvideos.selectaction): {0}", setting_result)
            # current_value = setting_result.get("result", None)
            # if current_value is not None:
            #     current_value = current_value.get("value", -1)
            # if current_value not in (2,3):
            #     return_value = xbmcgui.Dialog().yesno(string_load(30276), string_load(30277))
            #     if return_value:
            #         params = {"setting": "myvideos.selectaction", "value": 2}
            #         json_rpc_result = json_rpc('Settings.setSettingValue').execute(params)
            #         log.debug("Save Setting (myvideos.selectaction): {0}", json_rpc_result)

            if resume_result == 1:
                seek_time = 0
            elif resume_result == -1:
                return None

    log.debug("play_session_id: {0}", play_session_id)
    log.debug("live_stream_id: {0}", live_stream_id)
    play_result = PlayUtils().get_play_url(selected_media_source)
    playurl = play_result.playurl
    playback_type = play_result.playback_type
    listitem_props = play_result.listitem_props
    log.info(
        "Play URL: {0} Playback Type: {1} ListItem Properties: {2}",
        playurl,
        playback_type,
        listitem_props,
    )

    if playurl is None:
        return None

    playback_type_string = "DirectPlay"
    if playback_type == "2":
        playback_type_string = "Transcode"
    elif playback_type == "1":
        playback_type_string = "DirectStream"

    # add the playback type into the overview
    if result.get("Overview", None) is not None:
        result["Overview"] = playback_type_string + "\n" + result.get("Overview", "")
    else:
        result["Overview"] = playback_type_string

    # add title decoration is needed
    item_title = result.get("Name", string_load(30280))

    # extract item info from result
    settings = xbmcaddon.Addon()
    max_image_width = int(settings.getSetting("max_image_width"))
    use_prem_date_for_added = settings.getSetting("use_prem_date_for_added") == "true"
    gui_options = GuiOptions(
        server=server,
        name_format=None,
        name_format_type="",
        max_image_width=max_image_width,
        use_prem_date_for_added=use_prem_date_for_added,
    )
    item_details = extract_item_info(result, gui_options, download_utils=download_utils)

    # create ListItem
    display_options = DisplayOptions()
    display_options.addCounts = False
    display_options.addResumePercent = False
    display_options.addSubtitleAvailable = False

    gui_item: GuiItem | None = add_gui_item("", item_details, display_options, False)
    if gui_item is None:
        log.debug("gui_item was None, cannot play item")
        return None

    list_item = gui_item.list_item

    if playback_type == "2":  # if transcoding then prompt for audio and subtitle
        playurl = audio_subs_pref(
            playurl,
            list_item,
            selected_media_source,
            item_id,
            audio_stream_index or "",
            subtitle_stream_index or "",
        )
        log.debug("New playurl for transcoding: {0}", playurl)

    elif playback_type == "1":  # for direct stream add any streamable subtitles
        external_subs(selected_media_source, list_item, item_id)

    # get chapters for skip intro action
    chapters = result.get("Chapters", [])
    intro_start = 0
    intro_end = 0
    credits_start = 0
    for chapter in chapters:
        log.debug(
            "Play Item Chapter : {0} - {1} - {2}",
            chapter["MarkerType"],
            chapter["Name"],
            chapter["StartPositionTicks"],
        )
        if intro_start == 0 and chapter["MarkerType"] == "IntroStart":
            intro_start = chapter["StartPositionTicks"]
        elif intro_end == 0 and chapter["MarkerType"] == "IntroEnd":
            intro_end = chapter["StartPositionTicks"]
        elif credits_start == 0 and chapter["MarkerType"] == "CreditsStart":
            credits_start = chapter["StartPositionTicks"]

    # add playurl and data to the monitor
    data = {}
    data["item_id"] = item_id
    data["source_id"] = source_id
    data["playback_type"] = playback_type_string
    data["play_session_id"] = play_session_id
    data["live_stream_id"] = live_stream_id
    data["play_action_type"] = "play"
    data["item_type"] = result.get("Type", None)
    data["can_delete"] = result.get("CanDelete", False)
    data["intro_start"] = intro_start
    data["intro_end"] = intro_end
    data["credits_start"] = credits_start
    data["subtitle_stream_index"] = subtitle_stream_index
    monitor.played_information[playurl] = data
    log.debug("Add to played_information: {0}", monitor.played_information)

    list_item.setPath(playurl)
    list_item = set_list_item_props(
        item_id,
        list_item,
        result,
        server,
        listitem_props,
        item_title,
        maxwidth=max_image_width,
    )

    player = xbmc.Player()

    intro_items = []
    if play_cinema_intros and seek_time == 0:
        intro_items = get_playback_intros(item_id)
    if intro_items is None:
        intro_items = []

    if len(intro_items) > 0:
        playlist = play_all_files(intro_items, "-1", monitor, play_items=False)
        if playlist is None:
            log.debug("Could not build intro playlist, playing main item only")
            playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            playlist.clear()
            playlist.add(playurl, list_item)
        playlist.add(playurl, list_item)
    else:
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playlist.clear()
        playlist.add(playurl, list_item)

    player.play(playlist)

    if seek_time != 0:
        player.pause()
        xbmc_monitor: xbmc.Monitor = xbmc.Monitor()
        count = 0
        while (
            not player.isPlaying()
            and not xbmc_monitor.abortRequested()
            and count != 100
        ):
            count = count + 1
            xbmc.sleep(100)

        if count == 100 or not player.isPlaying() or xbmc_monitor.abortRequested():
            log.info(
                "PlaybackResumeAction : Playback item did not get to a play state in 10 seconds so exiting"
            )
            player.stop()
            return None

        log.info("PlaybackResumeAction : Playback is Running")

        seek_to_time = seek_time - jump_back_amount
        target_seek = seek_to_time - 10

        count = 0
        max_loops = 2 * 120
        while (
            not xbmc_monitor.abortRequested()
            and player.isPlaying()
            and count < max_loops
        ):
            log.info("PlaybackResumeAction : Seeking to : {0}", seek_to_time)
            player.seekTime(seek_to_time)
            current_position = player.getTime()
            if current_position >= target_seek:
                break
            log.info(
                "PlaybackResumeAction : target:{0} current:{1}",
                target_seek,
                current_position,
            )
            count = count + 1
            xbmc.sleep(500)

        if count == max_loops:
            log.info(
                "PlaybackResumeAction : Playback could not seek to required position"
            )
            player.stop()
        else:
            count = 0
            while bool(xbmc.getCondVisibility("Player.Paused")) and count < 10:
                log.info("PlaybackResumeAction : Unpausing playback")
                player.pause()
                xbmc.sleep(1000)
                count = count + 1

            if count == 10:
                log.info("PlaybackResumeAction : Could not unpause")
            else:
                log.info("PlaybackResumeAction : Playback resumed")

    next_episode = get_next_episode(result)

    if next_episode is not None:
        next_epp_art = get_art(
            next_episode,
            server,
            maxwidth=max_image_width,
            download_utils=download_utils,
        )
        next_episode["art"] = next_epp_art

    data["next_episode"] = next_episode
    send_next_episode_details(result, next_episode)
    return None


def __build_label2_from(source: dict) -> str:
    videos = [
        item for item in source.get("MediaStreams", {}) if item.get("Type") == "Video"
    ]
    audios = [
        item for item in source.get("MediaStreams", {}) if item.get("Type") == "Audio"
    ]
    subtitles = [
        item
        for item in source.get("MediaStreams", {})
        if item.get("Type") == "Subtitle"
    ]

    details = [str(convert_size(source.get("Size", 0)))]
    # details.append(source.get('Container', ''))
    for video in videos:
        details.append(
            "{} {} {}bit".format(
                video.get("DisplayTitle", ""),
                video.get("VideoRange", ""),
                video.get("BitDepth", ""),
            )
        )
    aud = []
    for audio in audios:
        aud.append(
            "{} {} {}".format(
                audio.get("Language", ""),
                audio.get("Codec", ""),
                audio.get("Channels", ""),
            )
        )
    if len(aud) > 0:
        details.append(", ".join(aud).upper())
    subs = []
    for subtitle in subtitles:
        subs.append(subtitle.get("Language", ""))
    if len(subs) > 0:
        details.append("S: {}".format(", ".join(subs)).upper())
    return " | ".join(details)


def get_next_episode(item: dict) -> dict | None:
    if item.get("Type", "na") != "Episode":
        log.debug("Not an episode, can not get next")
        return None

    parent_id = item.get("ParentId", "na")
    item_index = item.get("IndexNumber", -1)

    if parent_id == "na":
        log.debug("No parent id, can not get next")
        return None

    if item_index == -1:
        log.debug("No episode number, can not get next")
        return None

    url = "".join(
        [
            "{server}/emby/Users/{userid}/Items?",
            "?Recursive=true",
            "&ParentId=" + parent_id,
            "&IsVirtualUnaired=false",
            "&IsMissing=False",
            "&IncludeItemTypes=Episode",
            "&ImageTypeLimit=1",
            "&fields=CriticRating,OfficialRating,CommunityRating,Overview",
        ]
    )

    data_manager = DataManager()
    items_result = data_manager.get_content(url)
    log.debug("get_next_episode, sibling list: {0}", items_result)

    if items_result is None:
        log.debug("get_next_episode no results")
        return None

    item_list = items_result.get("Items", [])

    for item in item_list:
        index = item.get("IndexNumber", -1)
        # find the very next episode in the season
        if index == item_index + 1:
            log.debug("get_next_episode, found next episode: {0}", item)
            return item

    return None


def send_next_episode_details(item: dict, next_episode: dict | None) -> None:
    if next_episode is None:
        log.debug("No next episode")
        return

    settings = xbmcaddon.Addon()
    max_image_width = int(settings.getSetting("max_image_width"))
    download_utils = DownloadUtils()
    server = download_utils.get_server()
    if server is None or server == "":
        log.debug("No server found, cannot send next episode details")
        return

    use_prem_date_for_added = settings.getSetting("use_prem_date_for_added") == "true"

    gui_options = GuiOptions(
        server=server,
        name_format=None,
        name_format_type="",
        max_image_width=max_image_width,
        use_prem_date_for_added=use_prem_date_for_added,
    )

    item_details = extract_item_info(item, gui_options, download_utils=download_utils)
    next_item_details = extract_item_info(
        next_episode, gui_options, download_utils=download_utils
    )

    current_item = {}
    current_item["episodeid"] = item_details.id
    current_item["tvshowid"] = item_details.series_name
    current_item["title"] = item_details.name
    current_item["art"] = {}
    if item_details.art is not None:
        current_item["art"]["tvshow.poster"] = item_details.art.get("tvshow.poster", "")
        current_item["art"]["thumb"] = item_details.art.get("thumb", "")
        current_item["art"]["tvshow.fanart"] = item_details.art.get("tvshow.fanart", "")
        current_item["art"]["tvshow.landscape"] = item_details.art.get(
            "tvshow.landscape", ""
        )
        current_item["art"]["tvshow.clearart"] = item_details.art.get(
            "tvshow.clearart", ""
        )
        current_item["art"]["tvshow.clearlogo"] = item_details.art.get(
            "tvshow.clearlogo", ""
        )
    current_item["plot"] = item_details.plot
    current_item["showtitle"] = item_details.series_name
    current_item["playcount"] = item_details.play_count
    current_item["season"] = item_details.season_number
    current_item["episode"] = item_details.episode_number
    current_item["rating"] = item_details.critic_rating
    current_item["firstaired"] = item_details.year

    next_item = {}
    next_item["episodeid"] = next_item_details.id
    next_item["tvshowid"] = next_item_details.series_name
    next_item["title"] = next_item_details.name
    next_item["art"] = {}
    if next_item_details.art is not None:
        next_item["art"]["tvshow.poster"] = next_item_details.art.get(
            "tvshow.poster", ""
        )
        next_item["art"]["thumb"] = next_item_details.art.get("thumb", "")
        next_item["art"]["tvshow.fanart"] = next_item_details.art.get(
            "tvshow.fanart", ""
        )
        next_item["art"]["tvshow.landscape"] = next_item_details.art.get(
            "tvshow.landscape", ""
        )
        next_item["art"]["tvshow.clearart"] = next_item_details.art.get(
            "tvshow.clearart", ""
        )
        next_item["art"]["tvshow.clearlogo"] = next_item_details.art.get(
            "tvshow.clearlogo", ""
        )
    next_item["plot"] = next_item_details.plot
    next_item["showtitle"] = next_item_details.series_name
    next_item["playcount"] = next_item_details.play_count
    next_item["season"] = next_item_details.season_number
    next_item["episode"] = next_item_details.episode_number
    next_item["rating"] = next_item_details.critic_rating
    next_item["firstaired"] = next_item_details.year

    next_info = {
        "current_episode": current_item,
        "next_episode": next_item,
        "play_info": {
            "item_id": next_item_details.id,
            "auto_resume": False,
            "force_transcode": False,
        },
    }
    send_event_notification("upnext_data", next_info)


def set_list_item_props(
    _item_id: str,
    list_item: xbmcgui.ListItem,
    result: dict,
    server: str,
    extra_props: list,
    title: str,
    maxwidth: int = 0,
) -> xbmcgui.ListItem:
    # set up item and item info

    download_utils = DownloadUtils()
    art = get_art(
        result, server=server, maxwidth=maxwidth, download_utils=download_utils
    )
    list_item.setArt(
        {"icon": art["thumb"]}
    )  # changed to setArt due to setIconImage removed from v19
    list_item.setProperty("fanart_image", art["fanart"])  # back compat
    list_item.setProperty("discart", art["discart"])  # not avail to setArt
    list_item.setArt(art)

    list_item.setProperty("IsPlayable", "false")
    list_item.setProperty("IsFolder", "false")
    list_item.setProperty("id", result.get("Id", "unknown"))

    for prop in extra_props:
        list_item.setProperty(prop[0], prop[1])

    item_type = result.get("Type", "").lower()
    mediatype = "video"

    if item_type == "movie" or item_type == "boxset":
        mediatype = "movie"
    elif item_type == "series":
        mediatype = "tvshow"
    elif item_type == "season":
        mediatype = "season"
    elif item_type == "episode":
        mediatype = "episode"
    elif item_type == "audio":
        mediatype = "song"

    if item_type == "audio":
        info_tag_music = list_item.getMusicInfoTag()
        info_tag_music.setMediaType(mediatype)
        info_tag_music.setTitle(title)

    else:
        info_tag_video = list_item.getVideoInfoTag()
        info_tag_video.setMediaType(mediatype)
        info_tag_video.setTitle(title)
        info_tag_video.setPlot(result.get("Overview"))

        tv_show_name = result.get("SeriesName")
        if tv_show_name is not None:
            info_tag_video.setTvShowTitle(tv_show_name)

        if item_type == "episode":
            episode_number = result.get("IndexNumber", -1)
            if episode_number is not None:
                info_tag_video.setEpisode(episode_number)
            season_number = result.get("ParentIndexNumber", -1)
            if season_number is not None:
                info_tag_video.setSeason(season_number)
        elif item_type == "season":
            season_number = result.get("IndexNumber", -1)
            if season_number is not None:
                info_tag_video.setSeason(season_number)

    return list_item


# For transcoding only
# Present the list of audio and subtitles to select from
# for external streamable subtitles add the URL to the Kodi item and let Kodi handle it
# else ask for the subtitles to be burnt in when transcoding
def audio_subs_pref(
    url: str,
    list_item: xbmcgui.ListItem,
    media_source: dict,
    item_id: str,
    audio_stream_index: str,
    subtitle_stream_index: str,
) -> str:
    dialog = xbmcgui.Dialog()
    audio_streams_list = {}
    audio_streams: list[str | xbmcgui.ListItem] = []
    subtitle_streams_list = {}
    subtitle_streams: list[str | xbmcgui.ListItem] = ["No subtitles"]
    downloadable_streams = []
    select_audio_index = audio_stream_index
    select_subs_index = subtitle_stream_index
    playurlprefs = ""
    default_audio = media_source.get("DefaultAudioStreamIndex", 1)
    default_sub = media_source.get("DefaultSubtitleStreamIndex", "")
    source_id = media_source["Id"]

    media_streams = media_source["MediaStreams"]
    download_utils = DownloadUtils()

    for stream in media_streams:
        # Since Emby returns all possible tracks together, have to sort them.
        index = stream["Index"]

        if "Audio" in stream["Type"]:
            codec = stream["Codec"]
            channel_layout = stream.get("ChannelLayout", "")

            try:
                track = "%s - %s - %s %s" % (
                    index,
                    stream["Language"],
                    codec,
                    channel_layout,
                )
            except Exception:
                track = "%s - %s %s" % (index, codec, channel_layout)

            audio_streams_list[track] = index
            audio_streams.append(track)

        elif "Subtitle" in stream["Type"]:
            try:
                track = "%s - %s" % (index, stream["Language"])
            except Exception:
                track = "%s - %s" % (index, stream["Codec"])

            default = stream["IsDefault"]
            forced = stream["IsForced"]
            downloadable = (
                stream["IsTextSubtitleStream"]
                and stream["IsExternal"]
                and stream["SupportsExternalStream"]
            )

            if default:
                track = "%s - Default" % track
            if forced:
                track = "%s - Forced" % track
            if downloadable:
                downloadable_streams.append(index)

            subtitle_streams_list[track] = index
            subtitle_streams.append(track)

    # set audio index
    if select_audio_index:
        playurlprefs += "&AudioStreamIndex=%s" % select_audio_index

    elif len(audio_streams) > 1:
        resp = dialog.select(string_load(30291), audio_streams)
        if resp > -1:
            # User selected audio
            selected = audio_streams[resp]
            select_audio_index = audio_streams_list[selected]
            playurlprefs += "&AudioStreamIndex=%s" % select_audio_index
        else:  # User backed out of selection
            playurlprefs += "&AudioStreamIndex=%s" % default_audio

    # set subtitle index
    log.debug(
        "Subtitle streams available: ({0}) ({1})", select_subs_index, subtitle_streams
    )
    if select_subs_index:
        # Load subtitles in the listitem if downloadable
        if select_subs_index in downloadable_streams:
            subtitle_url = "%s/emby/Videos/%s/%s/Subtitles/%s/Stream.srt"
            subtitle_url = subtitle_url % (
                download_utils.get_server(),
                item_id,
                source_id,
                select_subs_index,
            )
            log.debug(
                "Streaming subtitles url: {0} {1}", select_subs_index, subtitle_url
            )
            list_item.setSubtitles([subtitle_url])
        else:
            # Burn subtitles
            playurlprefs += "&SubtitleStreamIndex=%s" % select_subs_index

    elif len(subtitle_streams) > 1:
        log.debug("Prompting user for subtitle selection")
        resp = dialog.select(string_load(30292), subtitle_streams)
        if resp == 0:
            # User selected no subtitles
            pass
        elif resp > -1:
            # User selected subtitles
            selected = subtitle_streams[resp]
            select_subs_index = subtitle_streams_list[selected]

            # Load subtitles in the listitem if downloadable
            if select_subs_index in downloadable_streams:
                subtitle_url = "%s/emby/Videos/%s/%s/Subtitles/%s/Stream.srt"
                subtitle_url = subtitle_url % (
                    download_utils.get_server(),
                    item_id,
                    source_id,
                    select_subs_index,
                )
                log.debug(
                    "Streaming subtitles url: {0} {1}", select_subs_index, subtitle_url
                )
                list_item.setSubtitles([subtitle_url])
            else:
                # Burn subtitles
                playurlprefs += "&SubtitleStreamIndex=%s" % select_subs_index

        else:  # User backed out of selection
            playurlprefs += "&SubtitleStreamIndex=%s" % default_sub

    if url.find("|verifypeer=false") != -1:
        new_url = url.replace("|verifypeer=false", playurlprefs + "|verifypeer=false")
    else:
        new_url = url + playurlprefs

    return new_url


# direct stream, set any available subtitle streams
def external_subs(
    media_source: dict, list_item: xbmcgui.ListItem, item_id: str
) -> None:
    media_streams = media_source.get("MediaStreams")

    if media_streams is None:
        return

    externalsubs = []
    sub_names = []
    download_utils = DownloadUtils()

    for stream in media_streams:
        if (
            stream["Type"] == "Subtitle"
            and stream["IsExternal"]
            and stream["IsTextSubtitleStream"]
            and stream["SupportsExternalStream"]
        ):
            index = stream["Index"]
            source_id = media_source["Id"]
            server = download_utils.get_server()
            token = download_utils.authenticate()

            if stream.get("DeliveryUrl", "").lower().startswith("/videos"):
                url = "%s/emby%s" % (server, stream.get("DeliveryUrl"))
            else:
                url = "%s/emby/Videos/%s/%s/Subtitles/%s/Stream.%s?api_key=%s" % (
                    server,
                    item_id,
                    source_id,
                    index,
                    stream["Codec"],
                    token,
                )

            default = ""
            if stream["IsDefault"]:
                default = "default"
            forced = ""
            if stream["IsForced"]:
                forced = "forced"

            sub_name = (
                stream.get("Language", "n/a")
                + " ("
                + stream.get("Codec", "n/a")
                + ") "
                + default
                + " "
                + forced
            )

            sub_names.append(sub_name)
            externalsubs.append(url)

    if len(externalsubs) == 0:
        return

    settings = xbmcaddon.Addon()
    direct_stream_sub_select = settings.getSetting("direct_stream_sub_select")

    if direct_stream_sub_select == "0" or (
        len(externalsubs) == 1 and not direct_stream_sub_select == "2"
    ):
        list_item.setSubtitles(externalsubs)
    else:
        resp = xbmcgui.Dialog().select(string_load(30292), sub_names)
        if resp > -1:
            selected_sub = externalsubs[resp]
            log.debug("External Subtitle Selected: {0}", selected_sub)
            list_item.setSubtitles([selected_sub])


def send_progress(monitor: PlaybackMonitorService) -> None:
    play_data = get_playing_data(monitor.played_information)

    if play_data is None:
        return

    log.debug("Sending Progress Update")

    player = xbmc.Player()
    play_time = player.getTime()
    total_play_time = player.getTotalTime()
    play_data["currentPossition"] = play_time
    play_data["duration"] = total_play_time
    play_data["currently_playing"] = True

    item_id = play_data.get("item_id")
    if item_id is None:
        return

    source_id = play_data.get("source_id")

    ticks = int(play_time * 10000000)
    duration = int(total_play_time * 10000000)
    paused = play_data.get("paused", False)
    playback_type = play_data.get("playback_type")
    play_session_id = play_data.get("play_session_id", "")
    live_stream_id = play_data.get("live_stream_id", "")

    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist_position = playlist.getposition()
    playlist_size = playlist.size()

    volume, muted = get_volume()

    postdata = {
        "QueueableMediaTypes": "Video",
        "CanSeek": True,
        "ItemId": item_id,
        "MediaSourceId": source_id,
        "IsPaused": paused,
        "IsMuted": muted,
        "PlayMethod": playback_type,
        "PlaySessionId": play_session_id,
        "LiveStreamId": live_stream_id,
        "PlaylistIndex": playlist_position,
        "PlaylistLength": playlist_size,
        "VolumeLevel": volume,
    }

    if duration is not None and duration > 0:
        postdata["RunTimeTicks"] = duration
        postdata["PositionTicks"] = ticks

    log.debug("Sending POST progress started: {0}", postdata)
    url = "{server}/emby/Sessions/Playing/Progress"
    download_utils = DownloadUtils()
    download_utils.download_url(url, post_body=postdata, method="POST")


def get_volume() -> tuple[int | None, bool | None]:
    json_data = xbmc.executeJSONRPC(
        '{ "jsonrpc": "2.0", "method": "Application.GetProperties", "params": {"properties": ["volume", "muted"]}, "id": 1 }'
    )
    result = json.loads(json_data)
    result = result.get("result", {})
    volume = result.get("volume")
    muted = result.get("muted")

    return volume, muted


def prompt_for_stop_actions(item_id: str, data: dict) -> None:
    log.debug("prompt_for_stop_actions Called : {0}", data)

    settings = xbmcaddon.Addon()
    current_position = data.get("currentPossition", 0)
    duration = data.get("duration", 0)
    # media_source_id = data.get("source_id")
    next_episode = data.get("next_episode")
    item_type = data.get("item_type")
    can_delete = data.get("can_delete", False)

    prompt_next_percentage = int(settings.getSetting("promptPlayNextEpisodePercentage"))
    play_prompt = (
        settings.getSetting("promptPlayNextEpisodePercentage_prompt") == "true"
    )
    prompt_delete_episode_percentage = int(
        settings.getSetting("promptDeleteEpisodePercentage")
    )
    prompt_delete_movie_percentage = int(
        settings.getSetting("promptDeleteMoviePercentage")
    )

    # everything is off so return
    if (
        prompt_next_percentage == 100
        and prompt_delete_episode_percentage == 100
        and prompt_delete_movie_percentage == 100
    ):
        return

    prompt_to_delete = False

    # if no runtime we cant calculate perceantge so just return
    if duration == 0:
        log.debug("No duration so returing")
        return

    # item percentage complete
    # percenatge_complete = int(((current_position * 10000000) / runtime) * 100)
    percenatge_complete = int((current_position / duration) * 100)
    log.debug("Episode Percentage Complete: {0}", percenatge_complete)

    if (
        can_delete
        and prompt_delete_episode_percentage < 100
        and item_type == "Episode"
        and percenatge_complete > prompt_delete_episode_percentage
    ):
        prompt_to_delete = True

    if (
        can_delete
        and prompt_delete_movie_percentage < 100
        and item_type == "Movie"
        and percenatge_complete > prompt_delete_movie_percentage
    ):
        prompt_to_delete = True

    if prompt_to_delete:
        log.debug("Prompting for delete")
        delete(item_id)

    # prompt for next episode
    if (
        next_episode is not None
        and prompt_next_percentage < 100
        and item_type == "Episode"
        and percenatge_complete > prompt_next_percentage
    ):
        if play_prompt:
            from .playnext import PlayNextDialog

            plugin_path = settings.getAddonInfo("path")
            plugin_path_real = xbmcvfs.translatePath(os.path.join(plugin_path))

            play_next_dialog = PlayNextDialog(
                "PlayNextDialog.xml", plugin_path_real, "default", "720p"
            )
            play_next_dialog.set_episode_info(next_episode)
            play_next_dialog.doModal()

            if not play_next_dialog.get_play_called():
                xbmc.executebuiltin("Container.Refresh")

        else:
            next_item_id = next_episode.get("Id")
            log.debug("Playing Next Episode: {0}", next_item_id)
            play_info = {}
            play_info["item_id"] = next_item_id
            play_info["auto_resume"] = "-1"
            play_info["force_transcode"] = False
            send_event_notification("embycon_play_action", play_info)


def stop_all_playback(played_information: dict[str, dict]) -> None:
    log.debug("stop_all_playback : {0}", played_information)

    if len(played_information) == 0:
        return

    log.debug("played_information: {0}", played_information)

    home_screen = HomeWindow()
    home_screen.clear_property("currently_playing_id")
    download_utils = DownloadUtils()

    for item_url in played_information:
        data = played_information.get(item_url, {})
        if data.get("currently_playing", False) is True:
            log.debug("item_url: {0}", item_url)
            log.debug("item_data: {0}", data)

            current_position = data.get("currentPossition", 0)
            duration = data.get("duration", 0)
            emby_item_id = data.get("item_id")
            emby_source_id = data.get("source_id")
            play_session_id = data.get("play_session_id", "")
            live_stream_id = data.get("live_stream_id", "")

            if emby_item_id is not None and current_position >= 0:
                log.debug("Playback Stopped at: {0}", current_position)

                url = "{server}/emby/Sessions/Playing/Stopped"
                postdata = {
                    "ItemId": emby_item_id,
                    "MediaSourceId": emby_source_id,
                    "PositionTicks": int(current_position * 10000000),
                    "RunTimeTicks": int(duration * 10000000),
                    "PlaySessionId": play_session_id,
                    "LiveStreamId": live_stream_id,
                }
                download_utils.download_url(url, post_body=postdata, method="POST")
                data["currently_playing"] = False

                if data.get("play_action_type", "") == "play":
                    prompt_for_stop_actions(emby_item_id, data)

    device_id = ClientInformation().get_device_id()
    url = "{server}/emby/Videos/ActiveEncodings?DeviceId=%s" % device_id
    download_utils.download_url(url, method="DELETE")


def get_playing_data(play_data_map: dict[str, dict]) -> dict | None:
    try:
        playing_file = xbmc.Player().getPlayingFile()
    except Exception as e:
        log.error("get_playing_data : getPlayingFile() : {0}", e)
        return None
    log.debug("get_playing_data : getPlayingFile() : {0}", playing_file)
    if playing_file not in play_data_map:
        infolabel_path_and_file = xbmc.getInfoLabel("Player.Filenameandpath")
        log.debug("get_playing_data : Filenameandpath : {0}", infolabel_path_and_file)
        if infolabel_path_and_file not in play_data_map:
            log.debug("get_playing_data : play data not found")
            return None
        playing_file = infolabel_path_and_file

    return play_data_map.get(playing_file)


# EmbyCon FR: correspondance de langue tolerante (codes ISO 639-2/B et /T,
# codes 2 lettres, noms courants FR/EN) pour la selection auto des sous-titres.
_LANG_ALIASES = {
    "fre": {"fre", "fra", "fr", "french", "francais", "français"},
    "eng": {"eng", "en", "english", "anglais"},
    "spa": {"spa", "es", "spanish", "espanol", "español", "espagnol"},
    "ger": {"ger", "deu", "de", "german", "allemand"},
    "ita": {"ita", "it", "italian", "italien"},
    "por": {"por", "pt", "portuguese", "portugais"},
    "jpn": {"jpn", "ja", "japanese", "japonais"},
    "dut": {"dut", "nld", "nl", "dutch", "neerlandais", "néerlandais"},
}


def _lang_matches(stream_lang: str, pref_code: str) -> bool:
    """Vrai si la langue d'un flux correspond au code de langue prefere."""
    if not stream_lang or not pref_code:
        return False
    s = stream_lang.strip().lower()
    aliases = _LANG_ALIASES.get(pref_code, {pref_code})
    for a in aliases:
        if s == a or s.startswith(a):
            return True
    return False


def _kodi_subtitle_streams() -> list:
    """Pistes de sous-titres du lecteur avec langue + drapeau 'isforced'.

    L'API xbmc.Player n'expose PAS l'attribut forced ; on passe donc par
    JSON-RPC Player.GetProperties qui renvoie index/language/isforced/isdefault
    (disponible depuis Kodi 19 Matrix). L'index renvoye correspond a celui
    attendu par player.setSubtitleStream().
    """
    req = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "Player.GetProperties",
        "params": {"playerid": 1, "properties": ["subtitles"]},
    }
    try:
        resp = json.loads(xbmc.executeJSONRPC(json.dumps(req)))
        return resp.get("result", {}).get("subtitles", []) or []
    except Exception as e:
        log.error("_kodi_subtitle_streams failed: {0}", e)
        return []


def _pick_subtitle(
    streams: list,
    pref_sub: str,
    forced_only: bool = False,
    prefer_non_forced: bool = False,
):
    """Index Kodi d'un sous-titre de la langue preferee, ou None.

    forced_only=True      -> uniquement une piste forced (traduction des
                             passages etrangers / textes a l'ecran).
    prefer_non_forced=True -> privilegie une piste complete (non-forced),
                             et retombe sur une forced a defaut.
    """
    match_forced = None
    match_full = None
    for s in streams:
        if not _lang_matches(s.get("language", ""), pref_sub):
            continue
        if s.get("isforced"):
            if match_forced is None:
                match_forced = s.get("index")
        elif match_full is None:
            match_full = s.get("index")
    if forced_only:
        return match_forced
    if prefer_non_forced:
        return match_full if match_full is not None else match_forced
    return match_full if match_full is not None else match_forced


def apply_intelligent_subtitle(play_data: dict) -> None:
    """Mode sous-titres « Intelligent » (facon Emby).

    Au demarrage de la lecture : si l'audio n'est PAS dans la langue audio
    preferee, active automatiquement une piste de sous-titres dans la langue
    de sous-titres preferee. Si l'audio est deja dans la langue preferee, les
    sous-titres sont desactives. Un choix manuel de sous-titres est respecte.

    Applique via l'API du lecteur Kodi -> fonctionne pour la lecture directe,
    le direct stream et le transcodage, sans dupliquer le rendu (gere par Kodi).
    """
    try:
        settings = xbmcaddon.Addon()
        if settings.getSetting("subtitle_auto_mode") != "1":
            return
        # Ne jamais ecraser un choix explicite de l'utilisateur.
        if play_data and play_data.get("subtitle_stream_index"):
            return
        pref_audio = settings.getSetting("pref_audio_lang")
        pref_sub = settings.getSetting("pref_subtitle_lang")
        if not pref_audio or not pref_sub:
            return

        player = xbmc.Player()
        audio_lang = xbmc.getInfoLabel("VideoPlayer.AudioLanguage")

        # Attendre l'enumeration des pistes : les sous-titres embarques
        # (notamment forced) apparaissent parfois un instant apres onAVStarted.
        streams = []
        for _ in range(20):  # ~2 s max
            streams = _kodi_subtitle_streams()
            if streams:
                break
            xbmc.sleep(100)

        log.debug(
            "Intelligent subs: audio='{0}' pref_audio='{1}' pref_sub='{2}' streams={3}",
            audio_lang, pref_audio, pref_sub, streams,
        )

        if _lang_matches(audio_lang, pref_audio):
            # L'audio est deja dans la langue preferee : pas de sous-titres
            # complets, MAIS on active une eventuelle piste FORCED de la langue
            # preferee (traduction des passages etrangers / textes a l'ecran),
            # qui doit toujours s'afficher.
            forced_idx = _pick_subtitle(streams, pref_sub, forced_only=True)
            if forced_idx is not None:
                player.setSubtitleStream(forced_idx)
                player.showSubtitles(True)
                log.debug("Intelligent subs: forced sub actif (stream {0})", forced_idx)
            else:
                player.showSubtitles(False)
            return

        # Audio dans une langue etrangere : afficher des sous-titres COMPLETS
        # dans la langue preferee (on privilegie une piste non-forced).
        idx = _pick_subtitle(streams, pref_sub, prefer_non_forced=True)
        if idx is not None:
            player.setSubtitleStream(idx)
            player.showSubtitles(True)
            log.debug("Intelligent subs: sous-titres actifs (stream {0})", idx)
            return
        log.debug("Intelligent subs: aucun sous-titre correspondant a '{0}'", pref_sub)
    except Exception as e:
        log.error("apply_intelligent_subtitle failed: {0}", e)


class PlaybackMonitorService(xbmc.Player):
    def __init__(self) -> None:
        log.debug("Starting PlaybackMonitorService")
        self.played_information = {}
        self.currently_playing_id = None

    def onPlayBackStarted(self) -> None:
        # Will be called when xbmc starts playing a file
        log.debug("onPlayBackStarted")

        if not xbmc.Player().isPlaying():
            log.debug("onPlayBackStarted: not playing file!")
            return

        play_data = get_playing_data(self.played_information)

        if play_data is None:
            stop_all_playback(self.played_information)
            return

        play_data["paused"] = False
        play_data["currently_playing"] = True

        emby_item_id = play_data["item_id"]
        emby_source_id = play_data["source_id"]
        playback_type = play_data["playback_type"]
        play_session_id = play_data["play_session_id"]
        live_stream_id = play_data["live_stream_id"]

        # if we could not find the ID of the current item then return
        if emby_item_id is None:
            return

        # set currently play item id
        self.currently_playing_id = emby_item_id

        log.debug("Sending Playback Started")
        postdata = {
            "QueueableMediaTypes": "Video",
            "CanSeek": True,
            "ItemId": emby_item_id,
            "MediaSourceId": emby_source_id,
            "PlayMethod": playback_type,
            "PlaySessionId": play_session_id,
            "LiveStreamId": live_stream_id,
        }

        log.debug("Sending POST play started: {0}", postdata)

        url = "{server}/emby/Sessions/Playing"
        download_utils = DownloadUtils()
        download_utils.download_url(url, post_body=postdata, method="POST")

        home_screen = HomeWindow()
        home_screen.set_property("currently_playing_id", str(emby_item_id))

        # start the skip intro monitor
        settings = xbmcaddon.Addon()
        skip_intros = settings.getSetting("skip_intros")
        if skip_intros != "0":
            intro_start = play_data.get("intro_start", 0)
            intro_end = play_data.get("intro_end", 0)
            # Repli duree fixe : si le serveur n'a pas de marqueur d'intro,
            # sauter les X premieres secondes (0 = desactive)
            if not (intro_end > 0 and intro_end > intro_start):
                try:
                    fb_intro = int(settings.getSetting("skip_intro_fallback_seconds"))
                except (TypeError, ValueError):
                    fb_intro = 0
                if fb_intro > 0:
                    intro_start = 0
                    intro_end = fb_intro * 10000000
            if intro_end > 0 and intro_end > intro_start:
                skip_monitor = SkipIntroMonitor()
                skip_monitor.set_times(intro_start, intro_end)
                skip_monitor.set_auto_skip(skip_intros == "2")
                skip_monitor.set_play_path(xbmc.Player().getPlayingFile())
                skip_monitor.start()

        # start the skip credits (end of episode) monitor
        skip_credits = settings.getSetting("skip_credits")
        if skip_credits and skip_credits != "0":
            credits_start = play_data.get("credits_start", 0)
            # Repli duree fixe : si le serveur n'a pas de marqueur CreditsStart,
            # proposer/effectuer le saut X secondes avant la fin (0 = desactive)
            try:
                fb_credits = int(settings.getSetting("skip_credits_fallback_seconds"))
            except (TypeError, ValueError):
                fb_credits = 0
            if credits_start > 0 or fb_credits > 0:
                credits_monitor = SkipCreditsMonitor()
                credits_monitor.set_credits_start(credits_start)
                credits_monitor.set_before_end(fb_credits)
                credits_monitor.set_auto_skip(skip_credits == "2")
                credits_monitor.set_play_path(xbmc.Player().getPlayingFile())
                credits_monitor.start()

    def onAVStarted(self) -> None:
        if not xbmc.Player().isPlayingVideo():
            return
        play_data = get_playing_data(self.played_information)
        if play_data is None:
            return
        apply_intelligent_subtitle(play_data)
        log.debug("onAVStarted: ActivateWindow(fullscreenvideo)")
        xbmc.executebuiltin("ActivateWindow(fullscreenvideo)")

    def onPlayBackEnded(self) -> None:
        # Will be called when kodi stops playing a file
        log.info("onPlayBackEnded")
        stop_all_playback(self.played_information)
        if self.currently_playing_id is not None:
            log.info("marking item watched : {0}", self.currently_playing_id)
            mark_item_watched(self.currently_playing_id, refresh=False)
        self.currently_playing_id = None
        self._flag_refresh_after_playback()

    def onPlayBackStopped(self) -> None:
        # Will be called when user stops kodi playing a file
        log.info("onPlayBackStopped")
        stop_all_playback(self.played_information)
        self.currently_playing_id = None
        self._flag_refresh_after_playback()

    def _flag_refresh_after_playback(self) -> None:
        # EmbyCon FR: demande au service de rafraichir la liste une fois la
        # lecture terminee (met a jour l'etat lu / disparition des Ajouts recents).
        settings = xbmcaddon.Addon()
        if settings.getSetting("auto_refresh_after_playback") == "true":
            HomeWindow().set_property("embycon_refresh_pending", "true")

    def onPlayBackPaused(self) -> None:
        # Will be called when kodi pauses the video
        log.info("onPlayBackPaused")

        play_data = get_playing_data(self.played_information)

        if play_data is not None:
            play_data["paused"] = True
            send_progress(self)

    def onPlayBackResumed(self) -> None:
        # Will be called when kodi resumes the video
        log.info("onPlayBackResumed")

        play_data = get_playing_data(self.played_information)

        if play_data is not None:
            play_data["paused"] = False
            send_progress(self)

    def onPlayBackSeek(self, time: int, seekOffset: int) -> None:  # noqa: ARG002
        # Will be called when kodi seeks in video
        log.info("onPlayBackSeek")
        send_progress(self)


class MonitoringService(xbmc.Monitor):
    background_image_cache_thread = None
    play_monitor: PlaybackMonitorService

    def __init__(self, monitor: PlaybackMonitorService) -> None:
        self.play_monitor = monitor

    def onNotification(self, sender: str, method: str, data: str) -> None:
        log.debug("PlaybackService:onNotification:{0}:{1}:{2}", sender, method, data)

        if method == "GUI.OnScreensaverActivated":
            self.screensaver_activated()
            return

        if method == "GUI.OnScreensaverDeactivated":
            self.screensaver_deactivated()
            return

        if sender[-7:] != ".SIGNAL":
            return

        signal = method.split(".", 1)[-1]
        if signal not in (
            "embycon_play_action",
            "embycon_play_youtube_trailer_action",
            "set_view",
        ):
            return

        data_json = json.loads(data)
        message_data = data_json[0]
        log.debug("PlaybackService:onNotification:{0}", message_data)
        decoded_data = base64.b64decode(message_data)
        play_info = json.loads(decoded_data.decode("utf-8"))

        if signal == "embycon_play_action":
            log.info("Received embycon_play_action : {0}", play_info)
            play_file(play_info, self.play_monitor)
        elif signal == "embycon_play_youtube_trailer_action":
            log.info("Received embycon_play_trailer_action : {0}", play_info)
            trailer_link = play_info["url"]
            xbmc.executebuiltin(trailer_link)
        elif signal == "set_view":
            view_id = play_info["view_id"]
            log.debug("Setting view id: {0}", view_id)
            xbmc.executebuiltin("Container.SetViewMode(%s)" % int(view_id))

    def screensaver_activated(self) -> None:
        log.debug("Screen Saver Activated")

        home_screen = HomeWindow()
        home_screen.clear_property("skip_select_user")

        settings = xbmcaddon.Addon()
        stop_playback = settings.getSetting("stopPlaybackOnScreensaver") == "true"

        if stop_playback:
            player = xbmc.Player()
            if player.isPlayingVideo():
                log.debug("Screen Saver Activated : isPlayingVideo() = true")
                play_data = get_playing_data(self.play_monitor.played_information)
                if play_data:
                    log.debug(
                        "Screen Saver Activated : this is an EmbyCon item so stop it"
                    )
                    player.stop()

        # xbmc.executebuiltin("Dialog.Close(selectdialog, true)")

        clear_old_cache_data()

        cache_images = settings.getSetting("cacheImagesOnScreenSaver") == "true"
        if cache_images:
            self.background_image_cache_thread = CacheArtwork()
            self.background_image_cache_thread.start()

    def screensaver_deactivated(self) -> None:
        log.debug("Screen Saver Deactivated")

        if self.background_image_cache_thread:
            self.background_image_cache_thread.stop_activity()
            self.background_image_cache_thread = None

        settings = xbmcaddon.Addon()
        show_change_user = settings.getSetting("changeUserOnScreenSaver") == "true"
        if show_change_user:
            home_screen = HomeWindow()
            skip_select_user = home_screen.get_property("skip_select_user")
            if skip_select_user is not None and skip_select_user == "true":
                return
            xbmc.executebuiltin("RunScript(plugin.video.embycon,0,?mode=CHANGE_USER)")
