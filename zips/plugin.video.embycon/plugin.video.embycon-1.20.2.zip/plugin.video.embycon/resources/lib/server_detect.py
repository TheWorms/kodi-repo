# Gnu General Public License - see LICENSE.TXT
from __future__ import annotations

import socket
import json
from urllib.parse import urlparse
import http.client
import ssl
import time
import hashlib
import threading
from datetime import datetime

import xbmcaddon
import xbmcgui
import xbmc

from .kodi_utils import HomeWindow
from .downloadutils import DownloadUtils, save_user_details, load_user_details
from .simple_logging import SimpleLogging
from .translation import string_load
from .utils import datetime_from_string
from .clientinfo import ClientInformation

log = SimpleLogging(__name__)

# v1.15 : qualite auto fiabilisee
_WARMUP_BYTES = 1000000  # 1 Mo d'echauffement non chronometre
_AUTO_BITRATE_SAMPLES = 2  # 2 mesures -> mediane
_bitrate_lock = threading.Lock()  # une seule mesure a la fois (service + bouton)


def check_connection_speed() -> int:
    log.debug("check_connection_speed")

    settings = xbmcaddon.Addon()
    verify_cert = settings.getSetting("verify_cert") == "true"
    http_timeout = int(settings.getSetting("http_timeout"))
    # v1.19 : une seule taille de test (manuel et qualite auto)
    try:
        speed_test_data_size = int(settings.getSetting("auto_bitrate_test_size"))
    except ValueError:
        speed_test_data_size = 8
    test_data_size = speed_test_data_size * 1000000

    du = DownloadUtils()
    server = du.get_server()
    if server is None:
        log.error("No server configured for speed test")
        xbmcgui.Dialog().ok(
            "Speed Test Error", "No server configured, please setup server first"
        )
        return -1

    url = server + "/emby/playback/bitratetest?size=%s" % test_data_size

    url_bits = urlparse(url.strip())

    protocol = url_bits.scheme
    host_name = url_bits.hostname
    port = url_bits.port
    # user_name = url_bits.username
    # user_password = url_bits.password
    url_path = url_bits.path
    url_puery = url_bits.query

    server = "%s:%s" % (host_name, port)
    url_path = url_path + "?" + url_puery

    local_use_https = False
    if protocol.lower() == "https":
        local_use_https = True

    if local_use_https and verify_cert:
        log.debug("Connection: HTTPS, Cert checked")
        conn = http.client.HTTPSConnection(server, timeout=http_timeout)
    elif local_use_https and not verify_cert:
        log.debug("Connection: HTTPS, Cert NOT checked")
        context = ssl.create_default_context()
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
        conn = http.client.HTTPSConnection(
            server, timeout=http_timeout, context=context
        )
    else:
        log.debug("Connection: HTTP")
        conn = http.client.HTTPConnection(server, timeout=http_timeout)

    head = du.get_auth_header(True)
    head["User-Agent"] = "EmbyCon-" + ClientInformation().get_version()

    conn.request(method="GET", url=url_path, headers=head)

    progress_dialog = xbmcgui.DialogProgress()
    message = "Testing with {0} MB of data".format(speed_test_data_size)
    progress_dialog.create("EmbyCon connection speed test", message)
    total_data_read = 0
    total_time = time.time()

    log.debug("Starting Connection Speed Test")
    response = conn.getresponse()
    last_percentage_done = 0
    if int(response.status) == 200:
        data = response.read(10240)
        while len(data) > 0:
            total_data_read += len(data)
            percentage_done = int(
                float(total_data_read) / float(test_data_size) * 100.0
            )
            if last_percentage_done != percentage_done:
                progress_dialog.update(percentage_done)
                last_percentage_done = percentage_done
            data = response.read(10240)
    else:
        log.error("HTTP response error: {0} {1}", response.status, response.reason)
        error_message = "HTTP response error: %s\n%s" % (
            response.status,
            response.reason,
        )
        xbmcgui.Dialog().ok("Speed Test Error", error_message)
        return -1

    total_data_read_kbits = (total_data_read * 8) / 1000
    total_time = time.time() - total_time
    speed = int(total_data_read_kbits / total_time)
    log.debug(
        "Finished Connection Speed Test, speed: {0} total_data: {1}, total_time: {2}",
        speed,
        total_data_read,
        total_time,
    )

    progress_dialog.close()
    del progress_dialog

    heading = "Speed Test Result : {0:,} Kbs".format(speed)
    message = "Do you want to set this speed as your max stream bitrate for playback?\n"
    message += "{0:,} MB over {1} sec".format(
        int((total_data_read / 1000000)), total_time
    )

    response = xbmcgui.Dialog().yesno(heading, message)
    if response:
        settings.setSetting("max_stream_bitrate", str(speed))

    return speed


def measure_connection_speed_silent(data_size_mb: int) -> int:
    """Mesure le debit vers le serveur Emby sans aucune interface.

    Renvoie la vitesse en Kb/s, ou -1 en cas d'erreur. Concue pour etre
    appelee juste avant une lecture en mode qualite automatique.
    """
    settings = xbmcaddon.Addon()
    verify_cert = settings.getSetting("verify_cert") == "true"
    # Timeout borne : la mesure ne doit jamais rester bloquee longtemps.
    http_timeout = min(int(settings.getSetting("http_timeout")), 10)
    test_data_size = int(data_size_mb) * 1000000

    du = DownloadUtils()
    server = du.get_server()
    if server is None:
        log.error("Silent speed test: no server configured")
        return -1

    url = server + "/emby/playback/bitratetest?size=%s" % test_data_size
    url_bits = urlparse(url.strip())
    protocol = url_bits.scheme
    host_name = url_bits.hostname
    port = url_bits.port
    url_path = url_bits.path + "?" + url_bits.query
    server_host = "%s:%s" % (host_name, port)

    try:
        if protocol.lower() == "https" and verify_cert:
            conn = http.client.HTTPSConnection(server_host, timeout=http_timeout)
        elif protocol.lower() == "https" and not verify_cert:
            context = ssl.create_default_context()
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE
            conn = http.client.HTTPSConnection(
                server_host, timeout=http_timeout, context=context
            )
        else:
            conn = http.client.HTTPConnection(server_host, timeout=http_timeout)

        head = du.get_auth_header(True)
        head["User-Agent"] = "EmbyCon-" + ClientInformation().get_version()
        conn.request(method="GET", url=url_path, headers=head)

        response = conn.getresponse()
        if int(response.status) != 200:
            log.error("Silent speed test HTTP error: {0}", response.status)
            return -1
        # v1.15 : on ne chronometre qu'apres un echauffement (montee en
        # charge TCP + latence du serveur distant), sinon la mesure sur un
        # petit volume sous-estime nettement le debit reel.
        warmup_bytes = min(_WARMUP_BYTES, test_data_size // 4)
        total_data_read = 0
        measured_bytes = 0
        start_time = None
        data = response.read(65536)
        while len(data) > 0:
            total_data_read += len(data)
            if start_time is None:
                if total_data_read >= warmup_bytes:
                    start_time = time.time()
            else:
                measured_bytes += len(data)
            data = response.read(65536)
        end_time = time.time()
        conn.close()
    except Exception as e:
        log.error("Silent speed test failed: {0}", e)
        return -1

    if start_time is None:
        return -1
    total_time = end_time - start_time
    if total_time <= 0 or measured_bytes <= 0:
        return -1

    speed = int((measured_bytes * 8) / 1000 / total_time)
    log.debug(
        "Silent speed test result: {0} Kbs ({1} bytes in {2:.2f}s after warmup)",
        speed,
        measured_bytes,
        total_time,
    )
    return speed


def compute_auto_bitrate(
    measures: list[int], margin_percent: int, floor_kbps: int, ceiling_kbps: int
) -> int:
    """Debit a appliquer : moyenne des mesures valides x marge, borne.

    Avec 2 mesures, la moyenne est la mediane. Renvoie -1 si aucune mesure
    n'est exploitable (on garde alors la valeur precedente).
    """
    valides = [m for m in measures if m and m > 0]
    if not valides:
        return -1
    valides.sort()
    milieu = len(valides) // 2
    if len(valides) % 2:
        mediane = valides[milieu]
    else:
        mediane = (valides[milieu - 1] + valides[milieu]) / 2.0
    margin_percent = min(max(margin_percent, 10), 100)
    applique = int(mediane * margin_percent / 100)
    if floor_kbps > 0:
        applique = max(applique, floor_kbps)
    if ceiling_kbps > 0:
        applique = min(applique, ceiling_kbps)
    return applique


def _int_setting(settings: xbmcaddon.Addon, key: str, default: int) -> int:
    try:
        return int(settings.getSetting(key))
    except (TypeError, ValueError):
        return default


def auto_detect_and_set_bitrate(force: bool = False) -> tuple[int, int] | None:
    """Mode qualite automatique : mesure la connexion et fixe max_stream_bitrate.

    Concue pour tourner en arriere-plan (thread du service), jamais sur le
    chemin de lecture. Silencieuse et non bloquante en cas d'echec (on garde
    alors la derniere valeur connue).

    v1.15 : 2 mesures (mediane), marge de securite (80 % par defaut),
    plancher / plafond, et trace de la derniere mesure dans les reglages.
    Renvoie (mesure, applique) en Kb/s, ou None si rien n'a ete applique.
    """
    if not _bitrate_lock.acquire(blocking=False):
        log.debug("Auto quality: measurement already running")
        return None
    try:
        settings = xbmcaddon.Addon()
        if settings.getSetting("bitrate_mode") != "1" and not force:
            return None
        data_size_mb = _int_setting(settings, "auto_bitrate_test_size", 8)
        margin = _int_setting(settings, "auto_bitrate_margin", 80)
        floor_kbps = _int_setting(settings, "auto_bitrate_min", 2000)
        ceiling_kbps = _int_setting(settings, "auto_bitrate_max", 0)

        measures = []
        for _ in range(_AUTO_BITRATE_SAMPLES):
            measures.append(measure_connection_speed_silent(data_size_mb))
        valides = [m for m in measures if m and m > 0]
        applique = compute_auto_bitrate(measures, margin, floor_kbps, ceiling_kbps)
        horodatage = datetime.now().strftime("%d/%m %H:%M")

        if applique <= 0:
            log.info("Qualite auto : mesure en echec, debit precedent conserve")
            settings.setSetting(
                "auto_bitrate_last", "%s  —  %s" % (horodatage, string_load(30548))
            )
            return None

        mesure = int(sum(valides) / len(valides))
        settings.setSetting("max_stream_bitrate", str(applique))
        settings.setSetting(
            "auto_bitrate_last",
            "%s  —  %s"
            % (horodatage, string_load(30547).format(_kbps(mesure), _kbps(applique))),
        )
        log.info(
            "Qualite auto : mesures {0} Kb/s -> applique {1} Kb/s (marge {2} %)",
            measures,
            applique,
            margin,
        )
        return mesure, applique
    finally:
        _bitrate_lock.release()


def _kbps(value: int) -> str:
    return "{0:,}".format(int(value)).replace(",", " ")


def measure_bitrate_now() -> None:
    """Bouton « Mesurer maintenant » des reglages (qualite auto)."""
    icon = "special://home/addons/plugin.video.embycon/icon.png"
    heading = string_load(30537)
    xbmcgui.Dialog().notification(heading, string_load(30546), icon=icon, time=3000)
    result = auto_detect_and_set_bitrate(force=True)
    if result is None:
        xbmcgui.Dialog().notification(heading, string_load(30548), icon=icon)
        return
    mesure, applique = result
    xbmcgui.Dialog().notification(
        heading, string_load(30547).format(_kbps(mesure), _kbps(applique)), icon=icon
    )


def get_server_details() -> list[dict]:
    log.debug("Getting Server Details from Network")
    servers = []

    message = "who is EmbyServer?"
    multi_group = ("<broadcast>", 7359)
    # multi_group = ("127.0.0.1", 7359)

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.settimeout(4.0)

    sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 3)  # timeout
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    # sock.setsockopt(socket.SOL_IP, socket.IP_MULTICAST_LOOP, 1)
    sock.setsockopt(socket.IPPROTO_IP, socket.SO_REUSEADDR, 1)

    log.debug("MutliGroup: {0}", multi_group)
    log.debug("Sending UDP Data: {0}", message)

    addon_name = xbmcaddon.Addon().getAddonInfo("name")
    progress = xbmcgui.DialogProgress()
    progress.create(addon_name + " : " + string_load(30373))
    progress.update(0, string_load(30374))
    xbmc.sleep(1000)
    server_count = 0

    # while True:
    try:
        sock.sendto(message.encode("utf-8"), multi_group)
        while True:
            try:
                server_count += 1
                progress.update(server_count * 10, string_load(30375) % server_count)
                xbmc.sleep(1000)
                data, _addr = sock.recvfrom(1024)
                responce_data = json.loads(data)
                servers.append(responce_data)
                log.debug("UDP Responce Data : {0}", responce_data)
            except Exception:
                break
    except Exception as e:
        log.error("UPD Discovery Error: {0}", e)

    progress.close()

    log.debug("Found Servers: {0}", servers)
    return servers


def check_server(force: bool = False, change_user: bool = False) -> None:
    log.debug("checkServer Called")

    settings = xbmcaddon.Addon()
    server_url = ""
    something_changed = False
    du = DownloadUtils()
    du.set_host_domain()

    if force is False:
        # if not forcing use server details from settings
        svr = du.get_server()
        if svr is not None:
            server_url = svr

    # if the server is not set then try to detect it
    if server_url == "":
        # scan for local server
        server_info = get_server_details()

        addon = xbmcaddon.Addon()
        addon_name = addon.getAddonInfo("name")
        server_icon = addon.getAddonInfo("icon")

        server_list = []
        for server in server_info:
            server_item = xbmcgui.ListItem(server.get("Name", string_load(30063)))
            sub_line = server.get("Address", "no address")
            server_item.setLabel2(sub_line)
            server_item.setProperty("address", server.get("Address", "no address"))
            art = {"Thumb": server_icon}
            server_item.setArt(art)
            server_list.append(server_item)

        if len(server_list) > 0:
            return_index = xbmcgui.Dialog().select(
                addon_name + " : " + string_load(30166), server_list, useDetails=True
            )
            if return_index != -1:
                server_url = server_info[return_index]["Address"]

        if not server_url:
            return_index = xbmcgui.Dialog().yesno(addon_name, string_load(30282))
            if not return_index:
                xbmc.executebuiltin("ActivateWindow(Home)")
                return

            while True:
                kb = xbmc.Keyboard()
                kb.setHeading(string_load(30372))
                if server_url:
                    kb.setDefault(server_url)
                else:
                    kb.setDefault("http://<server address>:8096")
                kb.doModal()
                if kb.isConfirmed():
                    server_url = kb.getText()
                else:
                    xbmc.executebuiltin("ActivateWindow(Home)")
                    return

                url_bits = urlparse(server_url)
                server_address = url_bits.hostname
                server_port = str(url_bits.port)
                server_protocol = url_bits.scheme
                user_name = url_bits.username
                user_password = url_bits.password

                if user_name and user_password:
                    temp_url = "%s://%s:%s@%s:%s/emby/Users/Public?format=json" % (
                        server_protocol,
                        user_name,
                        user_password,
                        server_address,
                        server_port,
                    )
                else:
                    temp_url = "%s://%s:%s/emby/Users/Public?format=json" % (
                        server_protocol,
                        server_address,
                        server_port,
                    )

                log.debug("Testing_Url: {0}", temp_url)
                progress = xbmcgui.DialogProgress()
                progress.create(addon_name + " : " + string_load(30376))
                progress.update(0, string_load(30377))
                json_data = du.download_url(temp_url, authenticate=False)
                progress.close()

                result = json.loads(json_data)
                if result is not None:
                    xbmcgui.Dialog().ok(
                        addon_name + " : " + string_load(30167),
                        "%s://%s:%s/" % (server_protocol, server_address, server_port),
                    )
                    break
                message = server_url + "\n" + string_load(30371)
                return_index = xbmcgui.Dialog().yesno(
                    addon_name + " : " + string_load(30135), message
                )
                if not return_index:
                    xbmc.executebuiltin("ActivateWindow(Home)")
                    return

        log.debug("Selected server: {0}", server_url)

        # parse the url
        url_bits = urlparse(server_url)
        server_address = url_bits.hostname
        server_port = str(url_bits.port)
        server_protocol = url_bits.scheme
        user_name = url_bits.username
        user_password = url_bits.password
        log.debug(
            "Detected server info {0} - {1} - {2}",
            server_protocol,
            server_address,
            server_port,
        )

        # save the server info
        settings.setSetting("port", server_port)

        if user_name and user_password:
            server_address = "%s:%s@%s" % (
                url_bits.username,
                url_bits.password,
                server_address,
            )

        settings.setSetting("ipaddress", server_address or "")

        if server_protocol == "https":
            settings.setSetting("protocol", "1")
        else:
            settings.setSetting("protocol", "0")

        something_changed = True

    # do we need to change the user
    user_details = load_user_details(settings)
    current_username = user_details.get("username", "")

    # if asked or we have no current user then show user selection screen
    if something_changed or change_user or len(current_username) == 0:
        # stop playback when switching users
        xbmc.Player().stop()
        du = DownloadUtils()
        du.set_host_domain()

        # get a list of users
        log.debug("Getting user list")
        json_data = du.download_url(
            server_url + "/emby/Users/Public?format=json", authenticate=False
        )

        log.debug("jsonData: {0}", json_data)
        try:
            result = json.loads(json_data)
        except Exception:
            result = None

        if result is None:
            message = string_load(30201) + "\n" + string_load(30169) + server_url
            xbmcgui.Dialog().ok(string_load(30135), message)

        else:
            selected_id = -1
            users = []
            for user in result:
                is_hidden = False
                if user.get("Configuration", {}).get("IsHidden", False) is True:
                    is_hidden = True

                if not is_hidden:
                    name = user.get("Name")

                    time_ago = ""
                    last_active = user.get("LastActivityDate")
                    if last_active:
                        last_active_date = datetime_from_string(last_active)
                        log.debug("LastActivityDate: {0}", last_active_date)
                        ago = datetime.now() - last_active_date
                        log.debug("LastActivityDate: {0}", ago)
                        days = divmod(ago.seconds, 86400)
                        hours = divmod(days[1], 3600)
                        minutes = divmod(hours[1], 60)
                        log.debug(
                            "LastActivityDate: {0} {1} {2}",
                            days[0],
                            hours[0],
                            minutes[0],
                        )
                        if days[0]:
                            time_ago += " %sd" % days[0]
                        if hours[0]:
                            time_ago += " %sh" % hours[0]
                        if minutes[0]:
                            time_ago += " %sm" % minutes[0]
                        time_ago = time_ago.strip()
                        if not time_ago:
                            time_ago = "Active: now"
                        else:
                            time_ago = "Active: %s ago" % time_ago
                        log.debug("LastActivityDate: {0}", time_ago)

                    user_item = xbmcgui.ListItem(name)
                    user_image = du.get_user_artwork(user, "Primary")
                    if not user_image:
                        user_image = "DefaultUser.png"
                    art = {"Thumb": user_image}
                    user_item.setArt(art)
                    user_item.setLabel2("TEST")

                    sub_line = time_ago

                    if user.get("HasPassword", False) is True:
                        sub_line += ", Password"
                        user_item.setProperty("secure", "true")

                        m = hashlib.md5()
                        m.update(name.encode("utf-8"))
                        hashed_username = m.hexdigest()
                        saved_password = settings.getSetting(
                            "saved_user_password_" + hashed_username
                        )
                        if saved_password:
                            sub_line += ": Saved"

                    else:
                        user_item.setProperty("secure", "false")

                    user_item.setProperty("manual", "false")
                    user_item.setLabel2(sub_line)
                    users.append(user_item)

                    if current_username == name:
                        selected_id = len(users) - 1

            if current_username:
                selection_title = string_load(30180) + " (" + current_username + ")"
            else:
                selection_title = string_load(30180)

            # add manual login
            user_item = xbmcgui.ListItem(string_load(30365))
            art = {"Thumb": "DefaultUser.png"}
            user_item.setArt(art)
            user_item.setLabel2(string_load(30366))
            user_item.setProperty("secure", "true")
            user_item.setProperty("manual", "true")
            users.append(user_item)

            return_value = xbmcgui.Dialog().select(
                selection_title,
                users,
                preselect=selected_id,
                autoclose=20000,
                useDetails=True,
            )

            if return_value > -1:
                # v1.14 : re-selectionner l'utilisateur courant n'est plus un
                # no-op : cela declenche un re-login et permet de ressaisir
                # le mot de passe (utile apres purge par la garde 401).
                something_changed = True
                selected_user = users[return_value]
                secured = selected_user.getProperty("secure") == "true"
                manual = selected_user.getProperty("manual") == "true"
                selected_user_name = selected_user.getLabel()

                log.debug(
                    "Selected User Name: {0} : {1}", return_value, selected_user_name
                )

                if manual:
                    kb = xbmc.Keyboard()
                    kb.setHeading(string_load(30005))
                    if current_username:
                        kb.setDefault(current_username)
                    kb.doModal()
                    if kb.isConfirmed():
                        selected_user_name = kb.getText()
                        log.debug("Manual entered username: {0}", selected_user_name)
                    else:
                        return

                if secured:
                    # we need a password, check the settings first
                    m = hashlib.md5()
                    m.update(selected_user_name.encode("utf-8"))
                    hashed_username = m.hexdigest()
                    saved_password = settings.getSetting(
                        "saved_user_password_" + hashed_username
                    )
                    mdp_candidat = None
                    if saved_password:
                        # v1.14 : verifier le mot de passe sauvegarde AVANT
                        # de l'utiliser ; s'il est refuse on propose la saisie
                        log.debug(
                            "Verifying stored password for user: {0}", hashed_username
                        )
                        if du.authenticate(selected_user_name, saved_password) != "":
                            mdp_candidat = saved_password

                    if mdp_candidat is None:
                        afficher_mdp = xbmcgui.Dialog().yesno(
                            string_load(30316),
                            "Afficher le mot de passe pendant la saisie ?",
                        )
                        kb = xbmc.Keyboard()
                        kb.setHeading(string_load(30006))
                        kb.setHiddenInput(not afficher_mdp)
                        kb.doModal()
                        if kb.isConfirmed():
                            mdp_saisi = kb.getText()
                            log.debug(
                                "Verifying entered password for user: {0}",
                                selected_user_name,
                            )
                            if du.authenticate(selected_user_name, mdp_saisi) != "":
                                mdp_candidat = mdp_saisi
                            else:
                                # v1.14 : rien n'est ecrase tant que le mot
                                # de passe n'est pas valide par le serveur
                                xbmcgui.Dialog().ok(
                                    string_load(30316),
                                    "Mot de passe refusé.\n"
                                    "L'ancien mot de passe est conservé.",
                                )
                                return
                        else:
                            return

                    log.debug(
                        "Saving username and verified password: {0}",
                        selected_user_name,
                    )
                    save_user_details(settings, selected_user_name, mdp_candidat)

                    # should we save the password
                    save_password = xbmcgui.Dialog().yesno(
                        string_load(30363), string_load(30364)
                    )
                    if save_password:
                        log.debug(
                            "Saving password for fast user switching: {0}",
                            hashed_username,
                        )
                        settings.setSetting(
                            "saved_user_password_" + hashed_username,
                            mdp_candidat,
                        )
                else:
                    log.debug(
                        "Saving username with no password: {0}", selected_user_name
                    )
                    save_user_details(settings, selected_user_name, "")

        log.debug("Changed user - checking change : {0}", something_changed)
        if something_changed:
            home_window = HomeWindow()
            home_window.clear_property("userid")
            home_window.clear_property("AccessToken")
            home_window.clear_property("userimage")
            home_window.clear_property("embycon_widget_reload")
            du = DownloadUtils()
            du.set_host_domain()
            du.authenticate()
            du.get_user_id()
            log.debug("Changed user - refreshing home")
            xbmc.executebuiltin("Dialog.Close(all,true)")
            xbmc.executebuiltin("ActivateWindow(Home)")
            if "estuary_embycon" in xbmc.getSkinDir():
                # Skin clone EmbyCon : le rechargement complet est necessaire
                # pour reprendre en compte les noeuds/widgets injectes.
                xbmc.executebuiltin("SetFocus(9000, 0, absolute)")
                xbmc.executebuiltin("ReloadSkin()")
            else:
                # Skin tiers (ex. Arctic Zephyr) : un ReloadSkin() complet peut
                # figer l'interface juste apres l'identification. On rafraichit
                # uniquement les widgets Home via leur jeton dedie.
                home_window.set_property("embycon_widget_reload", str(time.time()))
