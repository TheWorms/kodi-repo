# coding=utf-8
# Gnu General Public License - see LICENSE.TXT

import time
import traceback
import threading

import xbmc
import xbmcaddon
import xbmcgui

from resources.lib import cache_db
from resources.lib.downloadutils import DownloadUtils
from resources.lib.simple_logging import SimpleLogging
from resources.lib.play_utils import (
    PlaybackMonitorService,
    MonitoringService,
    send_progress,
)
from resources.lib.kodi_utils import HomeWindow
from resources.lib.widgets import (
    set_background_image,
    set_random_movies,
    check_for_new_content,
)
from resources.lib.websocket_client import WebSocketClient
from resources.lib.menu_functions import set_library_window_values
from resources.lib.context_monitor import ContextMonitor
from resources.lib.server_detect import check_server, auto_detect_and_set_bitrate
from resources.lib.library_change_monitor import LibraryChangeMonitor
from resources.lib.tracking import set_timing_enabled
from resources.lib.image_server import HttpImageServerThread
from resources.lib.playnext import PlayNextService
from resources.lib.chapter_dialog import ChapterDialogMonitor

settings = xbmcaddon.Addon()

log_timing_data = settings.getSetting("log_timing") == "true"
if log_timing_data:
    set_timing_enabled(True)

# clear user and token when logging in
home_window = HomeWindow()
home_window.clear_property("userid")
home_window.clear_property("AccessToken")
home_window.clear_property("Params")

log = SimpleLogging("service")
kodi_monitor = xbmc.Monitor()

# wait for 10 seconds for the Kodi splash screen to close
i = 0
while not kodi_monitor.abortRequested():
    if i == 100 or not xbmc.getCondVisibility("Window.IsVisible(startup)"):
        break
    i += 1
    xbmc.sleep(100)

# notify of debug logging
enable_logging = settings.getSetting("log_debug") == "true"
if enable_logging:
    xbmcgui.Dialog().notification(
        settings.getAddonInfo("name"),
        "Debug logging enabled!",
        time=3000,
        icon=xbmcgui.NOTIFICATION_WARNING,
    )

# make sure we have a server before starting the service
du = DownloadUtils()
while not kodi_monitor.abortRequested():
    server = du.get_server()
    if server is not None:
        break
    kodi_monitor.waitForAbort(5)

if kodi_monitor.abortRequested():
    log.debug("Abort requested before service started")
    exit(0)

log.debug("Service starting up")

check_server()

# v1.14 : purge des entrees de cache SQLite expirees au demarrage du service
cache_db.purge_expire()

download_utils = DownloadUtils()

# auth the service
try:
    download_utils.authenticate()
    download_utils.get_user_id()
except Exception as error:
    log.error("Error with initial service auth: {0}", error)

image_server = HttpImageServerThread()
image_server.start()

# set up all the services
play_monitor_service: PlaybackMonitorService = PlaybackMonitorService()
monitor_service: MonitoringService = MonitoringService(play_monitor_service)

home_window = HomeWindow()
last_progress_update = time.time()
last_background_update = 0
last_random_movie_update = 0
skin_checked = False
skin_check_delay = 20
user_last_changed = time.time()

# start the library update monitor
library_change_monitor = LibraryChangeMonitor()
library_change_monitor.start()

# start the WebSocket Client running
remote_control = settings.getSetting("websocket_enabled") == "true"
websocket_client = WebSocketClient(library_change_monitor)
if remote_control:
    websocket_client.start()

play_next_service = None
play_next_trigger_time = int(settings.getSetting("play_next_trigger_time"))
if play_next_trigger_time > 0:
    play_next_service = PlayNextService(play_monitor_service)
    play_next_service.start()

# Start the context menu monitor
context_monitor = None
context_menu = settings.getSetting("override_contextmenu") == "true"
if context_menu:
    context_monitor = ContextMonitor()
    context_monitor.start()

# Start the bookmark/chapter monitor
chapter_dialog_monitor = None
emby_bookmarks = settings.getSetting("override_bookmarks") == "true"
if emby_bookmarks:
    chapter_dialog_monitor = ChapterDialogMonitor()
    chapter_dialog_monitor.start()

background_interval = int(settings.getSetting("background_interval"))
random_movie_list_interval = int(settings.getSetting("random_movie_refresh_interval"))
random_movie_list_interval = random_movie_list_interval * 60

prev_user_id = home_window.get_property("userid")

# EmbyCon FR: compteur de temporisation pour le rafraichissement post-lecture.
refresh_grace = 0

# EmbyCon FR: mesure periodique du debit en mode qualite auto (arriere-plan).
last_bitrate_check = 0.0
bitrate_auto_interval = 15 * 60

while not kodi_monitor.abortRequested():
    try:
        if xbmc.Player().isPlaying():
            last_random_movie_update = time.time() - (random_movie_list_interval - 15)
            # if playing every 10 seconds updated the server with progress
            if (time.time() - last_progress_update) > 10:
                last_progress_update = time.time()
                send_progress(play_monitor_service)

        else:
            # EmbyCon FR: rafraichissement differe apres lecture.
            # On n'agit qu'apres etre reellement sorti de la video plein ecran
            # depuis ~2s (temporisation). Cela evite de consommer le drapeau
            # pendant la breve transition entre deux episodes en lecture auto,
            # ou la video plein ecran reste affichee.
            if home_window.get_property("embycon_refresh_pending") == "true":
                if xbmc.getCondVisibility("Window.IsVisible(fullscreenvideo)"):
                    refresh_grace = 0
                else:
                    refresh_grace += 1
                    if refresh_grace >= 2:
                        refresh_grace = 0
                        home_window.clear_property("embycon_refresh_pending")
                        # EmbyCon FR: rechargement des widgets serialise ICI
                        # (thread unique du service, hors lecture) et jamais
                        # depuis les callbacks du player -> anti-race GUI.
                        check_for_new_content()
                        if (
                            xbmcaddon.Addon().getSetting(
                                "auto_refresh_after_playback"
                            )
                            == "true"
                        ):
                            folder_path = xbmc.getInfoLabel(
                                "Container.FolderPath"
                            )
                            if (
                                folder_path
                                and "plugin.video.embycon" in folder_path
                            ):
                                log.debug("Refreshing container after playback")
                                xbmc.executebuiltin("Container.Refresh")
            else:
                refresh_grace = 0

            # EmbyCon FR: qualite auto - mesure periodique du debit en arriere-plan
            # (thread dedie, ne bloque jamais l'interface ni la lecture).
            if (
                settings.getSetting("bitrate_mode") == "1"
                and (time.time() - last_bitrate_check) > bitrate_auto_interval
            ):
                last_bitrate_check = time.time()
                threading.Thread(
                    target=auto_detect_and_set_bitrate, daemon=True
                ).start()

            screen_saver_active = xbmc.getCondVisibility("System.ScreenSaverActive")

            if not screen_saver_active:
                user_changed = False
                if prev_user_id != home_window.get_property("userid"):
                    log.debug("user_change_detected")
                    prev_user_id = home_window.get_property("userid")
                    user_changed = True
                    user_last_changed = time.time()

                if user_changed or (
                    random_movie_list_interval != 0
                    and (time.time() - last_random_movie_update)
                    > random_movie_list_interval
                ):
                    last_random_movie_update = time.time()
                    set_random_movies()

                if user_changed or (
                    background_interval != 0
                    and (time.time() - last_background_update) > background_interval
                ):
                    last_background_update = time.time()
                    set_library_window_values(user_changed)
                    set_background_image(user_changed)

                if remote_control and user_changed:
                    websocket_client.stop_client()
                    # v1.14 : attendre la mort de l'ancien thread avant de
                    # relancer (anti double spawn). L'ordre est obligatoire :
                    # join AVANT de creer la nouvelle instance, sinon le borg
                    # partagerait l'etat du thread entre les deux instances.
                    websocket_client.join(10)
                    if websocket_client.is_alive():
                        log.error("Ancien client websocket toujours vivant, relance annulee")
                    else:
                        websocket_client = WebSocketClient(library_change_monitor)
                        websocket_client.start()

                if (
                    skin_checked is False
                    and (time.time() - user_last_changed) > skin_check_delay
                    and home_window.get_property("userid")
                ):
                    skin_checked = True
                    # check_skin_installed()

            elif screen_saver_active:
                last_random_movie_update = time.time() - (
                    random_movie_list_interval - 15
                )
                if background_interval != 0 and (
                    (time.time() - last_background_update) > background_interval
                ):
                    last_background_update = time.time()
                    set_background_image(False)

    except Exception as error:
        log.error("Exception in Playback Monitor: {0}", error)
        log.error("{0}", traceback.format_exc())

    kodi_monitor.waitForAbort(1)

image_server.stop()

# call stop on the library update monitor
library_change_monitor.stop()

# stop the play next episdoe service
if play_next_service:
    play_next_service.stop_service()

# call stop on the context menu monitor
if context_monitor:
    context_monitor.stop_monitor()

if chapter_dialog_monitor:
    chapter_dialog_monitor.stop_monitor()

# stop the WebSocket Client
websocket_client.stop_client()

# v1.14 : purge des entrees de cache SQLite expirees a l'arret du service
cache_db.purge_expire()

# clear user and token when loggin off
home_window.clear_property("userid")
home_window.clear_property("AccessToken")
home_window.clear_property("userimage")

log.debug("Service shutting down")
