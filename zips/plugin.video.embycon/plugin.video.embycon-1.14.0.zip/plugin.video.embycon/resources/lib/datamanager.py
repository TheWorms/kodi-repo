# Gnu General Public License - see LICENSE.TXT
from __future__ import annotations

from typing import List, Any
from dataclasses import dataclass
import json
from collections import defaultdict
import threading
import hashlib
import os
import time

from . import cache_db
from .downloadutils import DownloadUtils
from .simple_logging import SimpleLogging
from .item_functions import GuiOptions, extract_item_info
from .kodi_utils import HomeWindow
from .translation import string_load
from .tracking import timer
from .data_models import (
    DataSet,
    Item,
    MediaStream,
    MediaSource,
    Studio,
    GenreItem,
    UserData,
    TagItem,
    ImageTags,
)

import xbmc
import xbmcaddon
import xbmcvfs
import xbmcgui


log = SimpleLogging(__name__)


# --- Custom Data Loader ---
def process_json_data(json_raw_data: str) -> DataSet:
    """Load and parse the JSON data file into nested dataclasses."""

    log.info("loading emby data in dataclasses")

    def parse_media_source(ms: dict) -> MediaSource:
        if "MediaStreams" in ms:
            ms["MediaStreams"] = [MediaStream(**s) for s in ms["MediaStreams"]]
        return MediaSource(**ms)

    def parse_item(item: dict) -> Item:
        if "MediaSources" in item:
            item["MediaSources"] = [
                parse_media_source(ms) for ms in item["MediaSources"]
            ]
        if "Studios" in item:
            item["Studios"] = [Studio(**st) for st in item["Studios"]]
        if "GenreItems" in item:
            item["GenreItems"] = [GenreItem(**gi) for gi in item["GenreItems"]]
        if "UserData" in item:
            item["UserData"] = UserData(**(item["UserData"]))
        if "MediaStreams" in item:
            item["MediaStreams"] = [MediaStream(**ms) for ms in item["MediaStreams"]]
        if "TagItems" in item:
            item["TagItems"] = [TagItem(**ti) for ti in item["TagItems"]]
        if "ImageTags" in item:
            item["ImageTags"] = ImageTags(**(item["ImageTags"]))
        return Item(**item)

    raw_json = json.loads(json_raw_data)
    if raw_json is None or not isinstance(raw_json, dict) or "Items" not in raw_json:
        log.debug("JSON data does not contain 'Items' key")
        return DataSet(Items=[])

    items = [parse_item(i) for i in raw_json["Items"]]
    del raw_json
    new_dataset = DataSet(Items=items)

    log.info("process_json_data : {0}", new_dataset)
    # v1.14 : bloc de debug upstream supprime ( il ecrivait un pickle dans
    # "C:\Temp\test_pickle_files" a chaque chargement de dataset )

    return new_dataset


@dataclass
class GetItemsResult:
    """Result from get_items containing cache file path, items, total count, and cache thread."""

    cache_id: str
    item_list: List[Any]
    total_records: int
    cache_thread: CacheManagerThread | None


class CacheItem:
    def __init__(self) -> None:
        self.item_list: List[Any] | None = None
        self.item_list_hash: str | None = None
        self.date_saved: float | None = None
        self.date_last_used: float | None = None
        self.last_action: str | None = None
        self.items_url: str | None = None
        self.id_cache: str | None = None
        self.user_id: str | None = None
        self.total_records: int | None = None


def _duree_cache_secondes() -> int:
    """v1.14 : duree de vie du cache de listes ( reglage cache_duration, heures )."""
    try:
        heures = int(xbmcaddon.Addon().getSetting("cache_duration"))
    except (TypeError, ValueError):
        heures = 24
    if heures <= 0:
        return 0
    return heures * 3600


# v1.14 : throttle de revalidation. Un dict module serait perdu a chaque
# invocation du plugin ( CPythonInvoker neuf ), la garde ne verrait jamais la
# revalidation precedente : l'horodatage vit donc dans une propriete
# HomeWindow ( Window 10000 ), qui survit aux invocations.
_verrou_revalidation = threading.Lock()


def _duree_revalidation_secondes() -> int:
    """v1.14 : intervalle minimum entre deux revalidations d'une meme URL
    ( reglage revalidation_interval, minutes, 0 = desactive )."""
    try:
        minutes = int(xbmcaddon.Addon().getSetting("revalidation_interval"))
    except (TypeError, ValueError):
        minutes = 10
    if minutes <= 0:
        return 0
    return minutes * 60


def _revalidation_trop_proche(url: str) -> bool:
    """True si cette URL a deja ete revalidee il y a moins de l'intervalle.

    Ecrit la date de revalidation dans HomeWindow : les proprietes Window
    10000 sont partagees par toutes les instances du plugin dans la session
    Kodi, la garde fonctionne donc aussi entre invocations.
    """
    duree = _duree_revalidation_secondes()
    if duree <= 0 or not url:
        return False

    cle = "reval_" + hashlib.md5(url.encode("utf-8")).hexdigest()

    with _verrou_revalidation:
        home_window = HomeWindow()
        derniere = home_window.get_property(cle)
        maintenant = time.time()
        if derniere:
            try:
                ecart = maintenant - float(derniere)
            except ValueError:
                ecart = -1.0
            if ecart < duree:
                return True
        home_window.set_property(cle, str(maintenant))
        return False


class DataManager:
    def __init__(self) -> None:
        # log.debug("DataManager __init__")
        pass

    @timer
    def get_content_dataset(self, url: str) -> DataSet:
        json_data = DownloadUtils().download_url(url)
        dataset_data: DataSet = process_json_data(json_data)
        return dataset_data

    @staticmethod
    def load_json_data(json_data: str) -> dict:
        return json.loads(json_data, object_hook=lambda d: defaultdict(lambda: None, d))

    @timer
    def get_content(self, url: str | None) -> dict:
        if not url:
            raise ValueError("URL cannot be None or empty")
        du = DownloadUtils()
        du.set_host_domain()
        json_data = du.download_url(url)
        return self.load_json_data(json_data)

    def get_cache_id(self, url: str) -> str:
        """v1.14 : identifiant stable du cache pour cette URL ( base SQLite )."""
        download_utils = DownloadUtils()
        user_id = download_utils.get_user_id()
        server = download_utils.get_server()
        m = hashlib.md5()
        line = user_id + "|" + str(server) + "|" + url
        m.update(line.encode("utf-8"))
        return m.hexdigest()

    def supprime_cache(self, url: str) -> None:
        """v1.14 : supprime l'entree de cache d'une URL ( base SQLite )."""
        cache_db.supprime_item(self.get_cache_id(url))

    @timer
    def get_items(
        self, url: str, gui_options: GuiOptions, use_cache: bool = False
    ) -> GetItemsResult:
        home_window = HomeWindow()
        log.debug("last_content_url : use_cache={0} url={1}", use_cache, url)
        home_window.set_property("last_content_url", url)

        download_utils = DownloadUtils()
        user_id = download_utils.get_user_id()
        id_cache = self.get_cache_id(url)

        item_list = None
        total_records = 0
        baseline_name = None
        cache_thread = CacheManagerThread()
        cache_thread.gui_options = gui_options

        home_window.set_property("cache_" + id_cache, "true")

        # v1.14 : cache desactive ( cache_duration = 0 ) -> toujours du neuf
        if _duree_cache_secondes() <= 0:
            use_cache = False

        clear_cache = home_window.get_property("skip_cache_for_" + url)
        if clear_cache:
            log.debug("Clearing cache data and loading new data")
            home_window.clear_property("skip_cache_for_" + url)
            cache_db.supprime_item(id_cache)

        # EmbyCon FR: fenetre de fraicheur globale apres un marquage (vu/non-vu/
        # favori/suppression). Pendant quelques secondes, on ignore le cache pour
        # TOUTE URL, afin que le Container.Refresh qui suit renvoie des donnees a
        # jour aussi bien pour une liste que pour le widget d'accueil focalise
        # (dont l'URL n'est pas forcement last_content_url). Non destructif : pas
        # de ReloadSkin, l'utilisateur reste sur sa page.
        fresh_until = home_window.get_property("embycon_fresh_until")
        if fresh_until:
            try:
                within_window = time.time() < float(fresh_until)
            except ValueError:
                within_window = False
            if within_window:
                use_cache = False
                cache_db.supprime_item(id_cache)

        # try to load the list item data from the cache
        if use_cache:
            log.debug("Loading url data from SQLite cache")

            cache_item = cache_db.charge_item(id_cache)
            if cache_item is not None:
                cache_thread.cached_item = cache_item
                item_list = cache_item.item_list
                total_records = cache_item.total_records

        # we need to load the list item data form the server
        if item_list is None or len(item_list) == 0:
            log.debug("Loading url data from server")

            results = self.get_content(url)

            if results is None:
                results = []

            if isinstance(results, dict):
                total_records = results.get("TotalRecordCount", 0)

            if isinstance(results, dict) and results.get("Items") is not None:
                baseline_name = results.get("BaselineItemName")
                results = results.get("Items", [])
            elif (
                isinstance(results, list)
                and len(results) > 0
                and results[0].get("Items") is not None
            ):
                baseline_name = results[0].get("BaselineItemName")
                results = results[0].get("Items")

            item_list = []
            for item in results:
                item_data = extract_item_info(
                    item, gui_options, download_utils=download_utils
                )
                item_data.baseline_itemname = baseline_name
                item_list.append(item_data)

            cache_item = CacheItem()
            cache_item.item_list = item_list
            cache_item.id_cache = id_cache
            cache_item.items_url = url
            cache_item.user_id = user_id
            cache_item.last_action = "fresh_data"
            cache_item.date_saved = time.time()
            cache_item.date_last_used = time.time()
            cache_item.total_records = total_records

            cache_thread.cached_item = cache_item
            # copy.deepcopy(item_list)

        if not use_cache:
            cache_thread = None

        return GetItemsResult(
            cache_id=id_cache,
            item_list=item_list,
            total_records=total_records,
            cache_thread=cache_thread,
        )


class CacheManagerThread(threading.Thread):
    def __init__(self) -> None:
        threading.Thread.__init__(self)
        self.cached_item: CacheItem | None = None
        self.gui_options: GuiOptions

    @staticmethod
    def get_data_hash(items: list) -> str:
        m = hashlib.md5()
        for item in items:
            item_string = "%s_%s_%s_%s_%s_%s" % (
                item.name,
                item.play_count,
                item.favorite,
                item.resume_time,
                item.recursive_unplayed_items_count,
                item.etag,
            )
            item_string = item_string.encode("UTF-8")
            m.update(item_string)

        return m.hexdigest()

    def run(self) -> None:
        log.debug("CacheManagerThread : Started")
        # log.debug("CacheManagerThread : Cache Item : {0}", self.cached_item.__dict__)

        download_utils = DownloadUtils()
        is_fresh = False

        if self.cached_item is None:
            log.debug("CacheManagerThread : No cached item")
            return

        # if the data is fresh then just save it
        # if the data is to old do a reload
        if (
            self.cached_item.date_saved is not None
            and (time.time() - self.cached_item.date_saved) < 20
            and self.cached_item.last_action == "fresh_data"
        ):
            is_fresh = True

        if (
            is_fresh
            and self.cached_item.item_list is not None
            and len(self.cached_item.item_list) > 0
        ):
            log.debug(
                "CacheManagerThread : Data is still fresh, not reloading from server"
            )
            cached_hash = self.get_data_hash(self.cached_item.item_list)
            self.cached_item.item_list_hash = cached_hash
            self.cached_item.last_action = "cached_data"
            self.cached_item.date_saved = time.time()
            self.cached_item.date_last_used = time.time()

            cache_db.sauve_item(
                self.cached_item.id_cache, self.cached_item, _duree_cache_secondes()
            )

        else:
            # v1.14 : pas plus d'une revalidation par URL par intervalle
            # ( reglage revalidation_interval, 0 = comportement d'origine ).
            if _revalidation_trop_proche(self.cached_item.items_url):
                log.debug("CacheManagerThread : revalidation trop recente, skip")
                return

            log.debug("CacheManagerThread : Reloading to recheck data hashes")
            cached_hash = self.cached_item.item_list_hash
            log.debug("CacheManagerThread : Cache Hash : {0}", cached_hash)

            data_manager = DataManager()
            results = data_manager.get_content(self.cached_item.items_url)
            if results is None:
                results = []

            if isinstance(results, dict) and results.get("Items") is not None:
                results = results.get("Items", [])
            elif (
                isinstance(results, list)
                and len(results) > 0
                and results[0].get("Items") is not None
            ):
                results = results[0].get("Items")

            total_records = 0
            if isinstance(results, dict):
                total_records = results.get("TotalRecordCount", 0)

            loaded_items = []
            for item in results:
                item_data = extract_item_info(
                    item, self.gui_options, download_utils=download_utils
                )
                loaded_items.append(item_data)

            if loaded_items is None or len(loaded_items) == 0:
                log.debug(
                    "CacheManagerThread : loaded_items is None or Empty so not saving it"
                )
                return

            loaded_hash = self.get_data_hash(loaded_items)
            log.debug("CacheManagerThread : Loaded Hash : {0}", loaded_hash)

            # if they dont match then save the data and trigger a content reload
            if cached_hash != loaded_hash:
                log.debug(
                    "CacheManagerThread : Hashes different, saving new data and reloading container"
                )

                self.cached_item.item_list = loaded_items
                self.cached_item.item_list_hash = loaded_hash
                self.cached_item.last_action = "fresh_data"
                self.cached_item.date_saved = time.time()
                self.cached_item.date_last_used = time.time()
                self.cached_item.total_records = total_records

                cache_db.sauve_item(
                    self.cached_item.id_cache, self.cached_item, _duree_cache_secondes()
                )

                log.debug("CacheManagerThread : Sending container refresh")
                time.sleep(1)
                # EmbyCon FR: jamais de refresh pendant une lecture ni si le
                # container affiche n'est pas EmbyCon (anti-race GUI depuis un
                # thread de fond).
                if not xbmc.Player().isPlaying():
                    folder_path = xbmc.getInfoLabel("Container.FolderPath")
                    if folder_path and "plugin.video.embycon" in folder_path:
                        xbmc.executebuiltin("Container.Refresh")

            else:
                self.cached_item.date_last_used = time.time()
                cache_db.sauve_item(
                    self.cached_item.id_cache, self.cached_item, _duree_cache_secondes()
                )
                log.debug("CacheManagerThread : Updating last used date for cache data")

        log.debug("CacheManagerThread : Exited")


def _delete_content_cache_files(delete_locks: bool = False) -> int:
    """Vide le cache de listes. Retourne le nombre d'entrees supprimees.

    v1.14 : les entrees vivent dans la base SQLite ( cache.db ) ; on ramasse
    aussi les anciens fichiers pickle/lock du cache fichier ( < v1.14 ).
    """
    del_count = cache_db.purge_tout()

    addon_dir = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
    cache_path = os.path.join(addon_dir, "cache")
    if xbmcvfs.exists(cache_path):
        _dirs, files = xbmcvfs.listdir(cache_path)
        for filename in files:
            if (delete_locks and filename.endswith(".lock")) or (
                filename.startswith("cache_") and filename.endswith(".pickle")
            ):
                xbmcvfs.delete(os.path.join(cache_path, filename))
                del_count += 1
    return del_count


def clear_cached_server_data() -> None:
    log.debug("clear_cached_server_data() called")
    del_count = _delete_content_cache_files(delete_locks=True)
    msg = string_load(30394) % del_count
    xbmcgui.Dialog().ok(string_load(30393), msg)


def invalidate_content_cache() -> None:
    """Purge silencieuse des caches de contenu apres un marquage.

    Le prochain rendu de n'importe quelle liste OU widget d'accueil re-interroge
    alors le serveur : l'element vu disparait des widgets (ex. 'derniers ajouts')
    des qu'ils se rechargent au focus du menu -- sans token &reload dans le skin
    ni ReloadSkin qui ejecterait l'utilisateur.
    """
    try:
        n = _delete_content_cache_files()
        log.debug("invalidate_content_cache: {0} fichier(s) purge(s)", n)
    except Exception as e:
        log.error("invalidate_content_cache a echoue: {0}", e)


def clear_old_cache_data() -> None:
    """v1.14 : purge des entrees expirees de la base + residus de l'ancien cache."""
    log.debug("clear_old_cache_data() : called")
    purge = cache_db.purge_expire()
    try:
        addon_dir = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
        cache_path = os.path.join(addon_dir, "cache")
        if xbmcvfs.exists(cache_path):
            _dirs, files = xbmcvfs.listdir(cache_path)
            for filename in files:
                if filename.startswith("cache_") and filename.endswith(".pickle"):
                    xbmcvfs.delete(os.path.join(cache_path, filename))
    except Exception as e:
        log.error("clear_old_cache_data() ancien cache : {0}", e)
    log.debug("clear_old_cache_data() : entrees expirees supprimees : {0}", purge)
