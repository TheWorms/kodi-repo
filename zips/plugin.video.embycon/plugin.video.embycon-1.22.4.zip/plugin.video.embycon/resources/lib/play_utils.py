# Gnu General Public License - see LICENSE.TXT
from __future__ import annotations

import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs

from datetime import timedelta
import json
import os
import base64

from .simple_logging import SimpleLogging
from .downloadutils import DownloadUtils, _masque_donnees_sensibles
from .resume_dialog import ResumeDialog
from .utils import PlayUtils, get_art, send_event_notification, convert_size
from .kodi_utils import HomeWindow
from .translation import string_load
from .datamanager import DataManager, clear_old_cache_data
from .item_functions import (
    extract_item_info,
    add_gui_item,
    GuiItem,
    DisplayOptions,
    GuiOptions,
)
from .clientinfo import ClientInformation
from .functions import delete, mark_item_watched
from .cache_images import CacheArtwork
from .picture_viewer import PictureViewer
from .tracking import timer
from .skip_intro_dialog import SkipIntroMonitor, SkipCreditsMonitor
from .sort_options import sort_emby_items
from . import random_session
from .transcode_check import check_transcode_later, decision_line
from .track_menu import choose_track
from .track_choice import (
    LANG_ALIASES,
    canonical_lang,
    choose_audio,
    choose_subtitle,
    lang_matches,
    menu,
    stream_language,
    subtitle_label,
)

log = SimpleLogging(__name__)

# v1.17 : un film arrete au-dela de ce pourcentage (generique) est considere
# comme termine pour l'enchainement automatique du film suivant
NEXT_MOVIE_AUTO_PERCENT = 90
# v1.20.0 : notification « Épisode suivant » (enchainement automatique)
NEXT_EPISODE_STRING = 30440

# v1.15 : ordre de lecture d'une collection (reglage collection_play_order)
_ORDRES_COLLECTION = {
    "0": ("PremiereDate,ProductionYear,SortName", "Ascending"),
    "1": ("PremiereDate,ProductionYear,SortName", "Descending"),
    "2": ("SortName", "Ascending"),
}


def build_play_all_url(
    parent_id: str, parent_type: str, shuffle: bool, collection_order: str
) -> str:
    """URL des elements d'un conteneur a lire d'un bloc.

    - Fields=Chapters pour que le saut d'intro/generique marche aussi en
      « Tout lire » (avant v1.15 les marqueurs etaient ignores).
    - Collection : uniquement le lisible (films, episodes, videos), dans
      l'ordre du reglage (date de sortie croissante par defaut).
    - Aleatoire : tri Random cote serveur, quel que soit le conteneur.
    """
    parts = [
        "{server}/emby/Users/{userid}/items",
        "?ParentId=" + parent_id,
        "&Fields=Chapters,{field_filters}",
        "&IsMissing=false",
    ]
    if parent_type == "BoxSet":
        parts.append("&IncludeItemTypes=Movie,Episode,Video,MusicVideo")
    if shuffle:
        parts.append("&SortBy=Random")
    elif parent_type == "BoxSet":
        sort_by, sort_order = _ORDRES_COLLECTION.get(
            collection_order or "0", _ORDRES_COLLECTION["0"]
        )
        parts.append("&SortBy=" + sort_by + "&SortOrder=" + sort_order)
    parts.append("&format=json")
    return "".join(parts)


def extract_markers(chapters: list) -> tuple[int, int, int]:
    """(intro_start, intro_end, credits_start) en ticks, 0 si absent."""
    intro_start = 0
    intro_end = 0
    credits_start = 0
    for chapter in chapters or []:
        marker = chapter.get("MarkerType")
        ticks = chapter.get("StartPositionTicks") or 0
        if not marker or marker == "Chapter":
            continue
        log.debug("Play Item Marker : {0} - {1}", marker, ticks)
        if intro_start == 0 and marker == "IntroStart":
            intro_start = ticks
        elif intro_end == 0 and marker == "IntroEnd":
            intro_end = ticks
        elif credits_start == 0 and marker == "CreditsStart":
            credits_start = ticks
    return intro_start, intro_end, credits_start


def _ticks_hms(ticks: int) -> str:
    if not ticks:
        return "-"
    return str(timedelta(seconds=int(ticks / 10000000)))


def log_markers(
    name: str, intro_start: int, intro_end: int, credits_start: int
) -> None:
    """v1.15 : une ligne claire par lecture pour diagnostiquer le saut."""
    if intro_end > intro_start:
        intro = "intro %s -> %s" % (_ticks_hms(intro_start), _ticks_hms(intro_end))
    else:
        intro = "intro : aucun marqueur serveur"
    if credits_start:
        credits = "generique %s" % _ticks_hms(credits_start)
    else:
        credits = "generique : aucun marqueur serveur"
    log.info("Marqueurs [{0}] : {1} | {2}", name, intro, credits)


def _prepare_play_all_item(
    item: dict,
    download_utils: DownloadUtils,
    server: str,
    settings: xbmcaddon.Addon,
    max_image_width: int,
    monitor: PlaybackMonitorService,
) -> tuple[str, xbmcgui.ListItem] | None:
    """Prepare UN element de « Tout lire » : URL de lecture + ListItem.

    Enregistre aussi les donnees de suivi (marqueurs intro/generique inclus,
    v1.15) dans monitor.played_information. None si l'element est illisible.
    """
    item_id = item.get("Id")

    # get playback info
    playback_info = download_utils.get_item_playback_info(item_id, False)
    if playback_info is None:
        log.debug(
            "playback_info was None, could not get MediaSources so can not play!"
        )
        return None
    if playback_info.get("ErrorCode") is not None:
        error_string = playback_info.get("ErrorCode", "code_unknown")
        xbmcgui.Dialog().notification(
            string_load(30316),
            error_string,
            icon="special://home/addons/plugin.video.embycon/icon-addon.png",
        )
        return None

    play_session_id = playback_info.get("PlaySessionId", "")
    live_stream_id = playback_info.get("LiveStreamId", "")

    # select the media source to use
    sources = playback_info.get("MediaSources")
    if sources is None or len(sources) == 0:
        log.debug("Play Failed! There is no MediaSources data!")
        return None

    selected_media_source = sources[0]
    source_id = selected_media_source.get("Id")

    play_result = PlayUtils().get_play_url(selected_media_source)
    playurl = play_result.playurl
    playback_type = play_result.playback_type
    listitem_props = play_result.listitem_props
    log.info(
        "Play URL: {0} PlaybackType: {1} ListItem Properties: {2}",
        _masque_donnees_sensibles(playurl or ""),
        playback_type,
        listitem_props,
    )

    if playurl is None:
        return None

    playback_type_string = "DirectPlay"
    if playback_type == "2":
        playback_type_string = "Transcode"
    elif playback_type == "1":
        playback_type_string = "DirectStream"

    # add the playback type into the overview
    if item.get("Overview", None) is not None:
        item["Overview"] = playback_type_string + "\n" + item.get("Overview")
    else:
        item["Overview"] = playback_type_string

    # add title decoration is needed
    item_title = item.get("Name", string_load(30280))

    use_prem_date_for_added = settings.getSetting("use_prem_date_for_added") == "true"
    gui_options = GuiOptions(
        server=server,
        name_format=None,
        name_format_type="",
        max_image_width=max_image_width,
        use_prem_date_for_added=use_prem_date_for_added,
    )
    item_details = extract_item_info(item, gui_options, download_utils=download_utils)

    # create ListItem
    display_options = DisplayOptions()
    display_options.addCounts = False
    display_options.addResumePercent = False
    display_options.addSubtitleAvailable = False

    gui_item: GuiItem | None = add_gui_item("", item_details, display_options, False)
    if gui_item is None:
        log.debug("playAllFiles: gui_item was None, cannot play item")
        return None

    list_item: xbmcgui.ListItem = gui_item.list_item

    # v1.22.0 : video reduite -> pistes choisies automatiquement (jamais de
    # question au milieu d'un « Tout lire »)
    _log_decision(item.get("Name", ""), selected_media_source, playback_type_string, False)
    if playback_type == "2":
        playurl = audio_subs_pref(
            playurl, list_item, selected_media_source, item_id, "", "", allow_prompt=False
        )

    # v1.15 : marqueurs -> le saut d'intro/generique marche aussi en Tout lire
    intro_start, intro_end, credits_start = extract_markers(
        item.get("Chapters") or []
    )

    # add playurl and data to the monitor
    data = {}
    data["item_id"] = item_id
    data["source_id"] = source_id
    data["playback_type"] = playback_type_string
    data["play_session_id"] = play_session_id
    data["live_stream_id"] = live_stream_id
    data["play_action_type"] = "play_all"
    data["item_type"] = item.get("Type", None)
    data["intro_start"] = intro_start
    data["intro_end"] = intro_end
    data["credits_start"] = credits_start
    monitor.played_information[playurl] = data
    log.debug("Add to played_information: {0}", monitor.played_information)

    list_item.setPath(playurl)
    list_item = set_list_item_props(
        item_id,
        list_item,
        item,
        server,
        listitem_props,
        item_title,
        max_image_width,
    )
    return playurl, list_item


def _still_our_playlist(
    player: xbmc.Player, playlist: xbmc.PlayList, first_url: str, count: int
) -> bool:
    """Vrai si la playlist video est toujours la notre et que la lecture continue.

    v1.18.1 : on ne compare plus l'URL lue (getPlayingFile) a nos URL : en
    transcodage HLS ou avec des en-tetes, Kodi peut rapporter une autre URL,
    ce qui interrompait a tort l'ajout des films suivants (la collection
    s'arretait apres le premier film). On verifie la playlist elle-meme :
    meme premier element, meme taille (une autre lecture EmbyCon la vide).
    """
    try:
        if not player.isPlaying():
            return False
        if playlist.size() != count:
            return False
        return playlist[0].getPath() == first_url
    except Exception:
        return False


def _wait_for_playback(player: xbmc.Player, timeout_tenths: int) -> bool:
    xbmc_monitor = xbmc.Monitor()
    count = 0
    while (
        not player.isPlaying()
        and not xbmc_monitor.abortRequested()
        and count < timeout_tenths
    ):
        count = count + 1
        xbmc.sleep(100)
    return player.isPlaying() and not xbmc_monitor.abortRequested()


def _player_time(player: xbmc.Player) -> float:
    try:
        return player.getTime()
    except Exception:
        return 0.0


def _seek_and_wait(player: xbmc.Player, seek_to_time: float, target_seek: float) -> bool:
    """v1.22.4 : se placer au point de reprise sans harceler le serveur.

    Avant, la position etait redemandee toutes les 0,5 s : sur une lecture
    reduite (transcodage HLS), chaque demande fait repartir la preparation
    de la video sur le serveur, qui n'arrivait plus a suivre (demarrage tres
    long, voire echec). Une demande, puis on attend ; on ne redemande que
    toutes les 10 s (2 s en lecture directe). 2 minutes au plus.
    """
    xbmc_monitor = xbmc.Monitor()
    try:
        transcoding = ".m3u8" in player.getPlayingFile()
    except Exception:
        transcoding = False
    reseek_every = 20 if transcoding else 4  # en demi-secondes
    max_loops = 2 * 120
    count = 0
    while not xbmc_monitor.abortRequested() and player.isPlaying() and count < max_loops:
        if count % reseek_every == 0:
            log.info("PlaybackResumeAction : Seeking to : {0}", seek_to_time)
            player.seekTime(seek_to_time)
        current_position = _player_time(player)
        if current_position >= target_seek:
            return True
        if count % 4 == 0:
            log.info(
                "PlaybackResumeAction : target:{0} current:{1}",
                target_seek,
                current_position,
            )
        count = count + 1
        xbmc.sleep(500)
    return count < max_loops and player.isPlaying()


def _resume_first_item(player: xbmc.Player, seek_time: float) -> bool:
    """Reprise du premier element (auto_resume). False si la lecture a echoue."""
    player.pause()
    if not _wait_for_playback(player, 100):
        log.info(
            "PlaybackResumeAction : Playback item did not get to a play state in 10 seconds so exiting"
        )
        player.stop()
        return False

    log.info("PlaybackResumeAction : Playback is Running")
    seek_to_time = seek_time
    target_seek = seek_to_time - 10

    if not _seek_and_wait(player, seek_to_time, target_seek):
        log.info("PlaybackResumeAction : Playback could not seek to required position")
        player.stop()
        return False

    count = 0
    while bool(xbmc.getCondVisibility("Player.Paused")) and count < 10:
        log.info("PlaybackResumeAction : Unpausing playback")
        player.pause()
        xbmc.sleep(1000)
        count = count + 1

    if count == 10:
        log.info("PlaybackResumeAction : Could not unpause")
    else:
        log.info("PlaybackResumeAction : Playback resumed")
    return True


def play_all_files(
    items: list,
    auto_resume: str,
    monitor: PlaybackMonitorService,
    play_items: bool = True,
) -> xbmc.PlayList | None:
    """Lit (ou prepare, si play_items=False) une liste d'elements a la suite.

    v1.15 : preparation AU FIL DE L'EAU. Avant, chaque element etait prepare
    (une requete PlaybackInfo par element) avant de lancer le premier : 3 a 5 s
    d'attente pour une collection de 10 films. Desormais la lecture demarre
    des que le premier element est pret, les suivants sont ajoutes a la liste
    pendant qu'il joue. Un element illisible est saute au lieu de tout annuler.
    Si l'utilisateur arrete ou lance autre chose entre-temps, on s'arrete.
    """
    log.debug("playAllFiles called with {0} items", len(items))
    download_utils = DownloadUtils()
    server = download_utils.get_server()
    if server is None or server == "":
        log.debug("playAllFiles: No server found, cannot play files")
        return None

    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()

    settings = xbmcaddon.Addon()
    max_image_width = int(settings.getSetting("max_image_width"))

    player = xbmc.Player()
    first_url = ""
    added = 0
    started = False

    for index, item in enumerate(items):
        if started and not _still_our_playlist(player, playlist, first_url, added):
            log.info(
                "Tout lire : lecture arretee ou remplacee, preparation interrompue ({0}/{1})",
                index,
                len(items),
            )
            break

        prepared = _prepare_play_all_item(
            item, download_utils, server, settings, max_image_width, monitor
        )
        if prepared is None:
            if not play_items:
                # liste d'intros cinema : comportement d'origine (tout ou rien)
                return None
            log.info("Tout lire : element {0} illisible, ignore", item.get("Id"))
            continue

        playurl, list_item = prepared
        playlist.add(playurl, list_item)
        if added == 0:
            first_url = playurl
        added += 1

        if not play_items:
            continue

        if not started:
            started = True
            auto_resume_int: int = int(auto_resume)
            seek_time = 0
            if auto_resume_int != -1:
                seek_time = (auto_resume_int / 1000) / 10000
            log.debug(
                "play_all_files auto_resume : {0} seekto : {1}", auto_resume_int, seek_time
            )
            player.play(playlist)
            if seek_time != 0:
                if not _resume_first_item(player, seek_time):
                    return None
            elif not _wait_for_playback(player, 300):
                log.info("Tout lire : la lecture n'a pas demarre en 30 s, abandon")
                return None
        else:
            # laisse Kodi traiter les callbacks en attente (onPlayBackStarted,
            # onAVStarted...) entre deux preparations
            xbmc.sleep(50)

    if not play_items:
        return playlist
    if not started:
        log.info("Tout lire : aucun element lisible")
    else:
        log.info("Tout lire : {0} element(s) dans la liste de lecture", added)
    return None


def play_list_of_items(
    id_list: list[str], auto_resume: str, monitor: PlaybackMonitorService
) -> xbmc.PlayList | None:
    log.debug("Loading  all items in the list")
    data_manager = DataManager()
    items = []

    for item_id in id_list:
        url = "{server}/emby/Users/{userid}/Items/%s?format=json"
        url = url % (item_id,)
        result = data_manager.get_content(url)
        if result is None:
            log.debug("Playfile item was None, so can not play!")
            return None
        items.append(result)

    return play_all_files(items, auto_resume, monitor)


def add_to_playlist(play_info: dict[str, str], monitor: PlaybackMonitorService) -> None:
    log.debug("Adding item to playlist : {0}", play_info)

    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    download_utils = DownloadUtils()
    server = download_utils.get_server()
    if server is None or server == "":
        log.debug("No server found, cannot add to playlist")
        return

    item_id = play_info.get("item_id")
    if item_id is None:
        log.debug("No item_id in play_info, cannot add to playlist")
        return

    url = "{server}/emby/Users/{userid}/Items/%s?format=json"
    url = url % (item_id,)
    data_manager = DataManager()
    item = data_manager.get_content(url)
    if item is None:
        log.debug("Playfile item was None, so can not play!")
        return

    # get playback info
    playback_info = download_utils.get_item_playback_info(item_id, False)
    if playback_info is None:
        log.debug("playback_info was None, could not get MediaSources so can not play!")
        return
    if playback_info.get("ErrorCode") is not None:
        error_string = playback_info.get("ErrorCode", "code_unknown")
        xbmcgui.Dialog().notification(
            string_load(30316),
            error_string,
            icon="special://home/addons/plugin.video.embycon/icon-addon.png",
        )
        return

    # play_session_id = id_generator()
    play_session_id = playback_info.get("PlaySessionId", "")
    live_stream_id = playback_info.get("LiveStreamId", "")

    # select the media source to use
    # sources = item.get("MediaSources")
    sources = playback_info.get("MediaSources")
    if sources is None or len(sources) == 0:
        log.debug("Play Failed! There is no MediaSources data!")
        return

    selected_media_source = sources[0]
    source_id = selected_media_source.get("Id")

    play_result = PlayUtils().get_play_url(selected_media_source)
    playurl = play_result.playurl
    playback_type = play_result.playback_type
    listitem_props = play_result.listitem_props
    log.info(
        "Play URL: {0} PlaybackType: {1} ListItem Properties: {2}",
        _masque_donnees_sensibles(playurl or ""),
        playback_type,
        listitem_props,
    )

    if playurl is None:
        return

    playback_type_string = "DirectPlay"
    if playback_type == "2":
        playback_type_string = "Transcode"
    elif playback_type == "1":
        playback_type_string = "DirectStream"

    # add the playback type into the overview
    if item.get("Overview", None) is not None:
        item["Overview"] = playback_type_string + "\n" + item.get("Overview", "")
    else:
        item["Overview"] = playback_type_string

    # add title decoration is needed
    item_title = item.get("Name", string_load(30280))
    list_item = xbmcgui.ListItem(label=item_title)

    # v1.22.0 : video reduite -> pistes choisies automatiquement
    _log_decision(item.get("Name", ""), selected_media_source, playback_type_string, False)
    if playback_type == "2":
        playurl = audio_subs_pref(
            playurl, list_item, selected_media_source, item_id, "", "", allow_prompt=False
        )

    settings = xbmcaddon.Addon()
    max_image_width = int(settings.getSetting("max_image_width"))

    # add playurl and data to the monitor
    data = {}
    data["item_id"] = item_id
    data["source_id"] = source_id
    data["playback_type"] = playback_type_string
    data["play_session_id"] = play_session_id
    data["live_stream_id"] = live_stream_id
    data["play_action_type"] = "play_all"
    monitor.played_information[playurl] = data
    log.debug("Add to played_information: {0}", monitor.played_information)

    list_item.setPath(playurl)
    list_item = set_list_item_props(
        item_id,
        list_item,
        item,
        server,
        listitem_props,
        item_title,
        maxwidth=max_image_width,
    )

    playlist.add(playurl, list_item)


def get_playback_intros(item_id: str) -> list[dict] | None:
    log.debug("get_playback_intros")
    data_manager = DataManager()
    url = "{server}/emby/Users/{userid}/Items/%s/Intros" % item_id
    intro_items = data_manager.get_content(url)

    if intro_items is None:
        log.debug("get_playback_intros failed!")
        return None

    into_list = []
    intro_items = intro_items["Items"]
    for into in intro_items:
        into_list.append(into)

    return into_list


@timer
def play_file(
    play_info: dict[str, str], monitor: PlaybackMonitorService
) -> xbmc.PlayList | None:
    item_id = play_info.get("item_id")
    if item_id is None:
        log.debug("No item_id in play_info, cannot play file")
        return None

    home_window = HomeWindow()
    last_url = home_window.get_property("last_content_url")
    if last_url:
        home_window.set_property("skip_cache_for_" + last_url, "true")

    auto_resume = play_info.get("auto_resume", "-1")
    action = play_info.get("action", "play")
    if action == "add_to_playlist":
        add_to_playlist(play_info, monitor)
        return None

    # if this is a list of items add them all to the play list
    if isinstance(item_id, list):
        return play_list_of_items(item_id, auto_resume, monitor)

    force_transcode: bool = bool(play_info.get("force_transcode", False))
    media_source_id: str = play_info.get("media_source_id", "")
    subtitle_stream_index = play_info.get("subtitle_stream_index", None)
    audio_stream_index = play_info.get("audio_stream_index", None)

    log.debug(
        "playFile id({0}) resume({1}) force_transcode({2})",
        item_id,
        auto_resume,
        force_transcode,
    )

    settings = xbmcaddon.Addon()
    addon_path = settings.getAddonInfo("path")
    force_auto_resume = settings.getSetting("forceAutoResume") == "true"
    jump_back_amount = int(settings.getSetting("jump_back_amount"))
    play_cinema_intros = settings.getSetting("play_cinema_intros") == "true"
    auto_play_first_version = settings.getSetting("auto_play_first_version") == "true"

    download_utils = DownloadUtils()
    server = download_utils.get_server()
    if server is None or server == "":
        log.debug("No server found, cannot play file")
        return None

    url = "{server}/emby/Users/{userid}/Items/%s?fields=Chapters&format=json" % (
        item_id,
    )
    data_manager = DataManager()
    result = data_manager.get_content(url)

    if not result:
        log.debug("Playfile item was None, so can not play!")
        return None
    log.debug("Playfile item: {0}", dict(result))

    # if this is a season, playlist, album or collection then play all items
    # in that parent (v1.15 : collections + lecture aleatoire)
    if result.get("Type") in ["Season", "MusicAlbum", "Playlist", "BoxSet"]:
        log.debug("PlayAllFiles for parent item id: {0}", item_id)
        result_type = result.get("Type")
        shuffle = bool(play_info.get("shuffle", False))
        url = build_play_all_url(
            item_id,
            result.get("Type", ""),
            shuffle,
            settings.getSetting("collection_play_order"),
        )
        result = data_manager.get_content(url)
        log.debug("PlayAllFiles items: {0}", result)

        # process each item
        items = (result or {}).get("Items")
        if items is None:
            items = []
        # v1.18.2 : ordre garanti cote client pour une collection (Emby peut
        # renvoyer l'ordre d'affichage propre a la collection)
        if result_type == "BoxSet" and not shuffle:
            items = sort_emby_items(items, settings.getSetting("collection_play_order"))
        log.info(
            "Tout lire : {0} element(s), aleatoire={1}", len(items), shuffle
        )
        return play_all_files(items, "-1", monitor)

    # if this is a program from live tv epg then play the actual channel
    if result.get("Type") == "Program":
        channel_id = result.get("ChannelId")
        url = "{server}/emby/Users/{userid}/Items/%s?format=json" % (channel_id,)
        result = data_manager.get_content(url)
        item_id = result["Id"]

    if result.get("Type") == "Photo":
        play_url = "%s/emby/Items/%s/Images/Primary"
        play_url = play_url % (server, item_id)

        plugin_path = xbmcvfs.translatePath(
            os.path.join(xbmcaddon.Addon().getAddonInfo("path"))
        )
        action_menu = PictureViewer("PictureViewer.xml", plugin_path, "default", "720p")
        action_menu.setPicture(play_url)
        action_menu.doModal()
        return None

    # get playback info from the server using the device profile
    playback_info = download_utils.get_item_playback_info(item_id, force_transcode)
    if playback_info is None:
        log.debug("playback_info was None, could not get MediaSources so can not play!")
        return None
    if playback_info.get("ErrorCode") is not None:
        error_string = playback_info.get("ErrorCode", "code_unknown")
        xbmcgui.Dialog().notification(
            string_load(30316),
            error_string,
            icon="special://home/addons/plugin.video.embycon/icon-addon.png",
        )
        return None

    play_session_id = playback_info.get("PlaySessionId", "")

    # select the media source to use
    media_sources = playback_info.get("MediaSources")
    selected_media_source = None

    if media_sources is None or len(media_sources) == 0:
        log.debug("Play Failed! There is no MediaSources data!")
        return None

    if len(media_sources) == 1 or auto_play_first_version:
        selected_media_source = media_sources[0]

    elif media_source_id != "":
        for source in media_sources:
            if source.get("Id", "na") == media_source_id:
                selected_media_source = source
                break

    elif len(media_sources) > 1:
        items = []
        for source in media_sources:
            label = source.get("Name", {})
            label2 = __build_label2_from(source)
            items.append(xbmcgui.ListItem(label=label, label2=label2))
        dialog = xbmcgui.Dialog()
        resp = dialog.select(string_load(30309), items, useDetails=True)
        if resp > -1:
            selected_media_source = media_sources[resp]
        else:
            log.debug("Play Aborted, user did not select a MediaSource")
            return None

    if selected_media_source is None:
        log.debug("Play Aborted, MediaSource was None")
        return None

    source_id = selected_media_source.get("Id")
    live_stream_id = selected_media_source.get("LiveStreamId", "")
    seek_time = 0
    auto_resume = int(auto_resume)
    user_data = result.get("UserData", {})
    playback_pos = int(user_data.get("PlaybackPositionTicks", -1))

    # process user data for resume points
    if auto_resume != -1:
        seek_time = (auto_resume / 1000) / 10000

    elif force_auto_resume:
        if playback_pos > 0:
            reasonable_ticks = playback_pos / 1000
            seek_time = reasonable_ticks / 10000

    else:
        user_data = result.get("UserData")
        if playback_pos > 0:
            reasonable_ticks = playback_pos / 1000
            seek_time = int(reasonable_ticks / 10000)
            display_time = str(timedelta(seconds=seek_time))

            resume_dialog = ResumeDialog(
                "ResumeDialog.xml", addon_path, "default", "720p"
            )
            resume_dialog.setResumeTime("Resume from " + display_time)
            resume_dialog.doModal()
            resume_result = resume_dialog.getResumeAction()
            del resume_dialog
            log.debug("Resume Dialog Result: {0}", resume_result)

            # check system settings for play action
            # if prompt is set ask to set it to auto resume
            # remove for now as the context dialog is now handeled in the monitor thread
            # params = {"setting": "myvideos.selectaction"}
            # setting_result = json_rpc('Settings.getSettingValue').execute(params)
            # log.debug("Current Setting (myvideos.selectaction): {0}", setting_result)
            # current_value = setting_result.get("result", None)
            # if current_value is not None:
            #     current_value = current_value.get("value", -1)
            # if current_value not in (2,3):
            #     return_value = xbmcgui.Dialog().yesno(string_load(30276), string_load(30277))
            #     if return_value:
            #         params = {"setting": "myvideos.selectaction", "value": 2}
            #         json_rpc_result = json_rpc('Settings.setSettingValue').execute(params)
            #         log.debug("Save Setting (myvideos.selectaction): {0}", json_rpc_result)

            if resume_result == 1:
                seek_time = 0
            elif resume_result == -1:
                return None

    log.debug("play_session_id: {0}", play_session_id)
    log.debug("live_stream_id: {0}", live_stream_id)
    play_result = PlayUtils().get_play_url(selected_media_source)
    playurl = play_result.playurl
    playback_type = play_result.playback_type
    listitem_props = play_result.listitem_props
    log.info(
        "Play URL: {0} Playback Type: {1} ListItem Properties: {2}",
        _masque_donnees_sensibles(playurl or ""),
        playback_type,
        listitem_props,
    )

    if playurl is None:
        return None

    playback_type_string = "DirectPlay"
    if playback_type == "2":
        playback_type_string = "Transcode"
    elif playback_type == "1":
        playback_type_string = "DirectStream"

    # add the playback type into the overview
    if result.get("Overview", None) is not None:
        result["Overview"] = playback_type_string + "\n" + result.get("Overview", "")
    else:
        result["Overview"] = playback_type_string

    # add title decoration is needed
    item_title = result.get("Name", string_load(30280))

    # extract item info from result
    settings = xbmcaddon.Addon()
    max_image_width = int(settings.getSetting("max_image_width"))
    use_prem_date_for_added = settings.getSetting("use_prem_date_for_added") == "true"
    gui_options = GuiOptions(
        server=server,
        name_format=None,
        name_format_type="",
        max_image_width=max_image_width,
        use_prem_date_for_added=use_prem_date_for_added,
    )
    item_details = extract_item_info(result, gui_options, download_utils=download_utils)

    # create ListItem
    display_options = DisplayOptions()
    display_options.addCounts = False
    display_options.addResumePercent = False
    display_options.addSubtitleAvailable = False

    gui_item: GuiItem | None = add_gui_item("", item_details, display_options, False)
    if gui_item is None:
        log.debug("gui_item was None, cannot play item")
        return None

    list_item = gui_item.list_item

    _log_decision(result.get("Name", ""), selected_media_source, playback_type_string, force_transcode)
    if playback_type == "2":  # transcodage : pistes audio et sous-titres (v1.22.0 : auto)
        playurl = audio_subs_pref(
            playurl,
            list_item,
            selected_media_source,
            item_id,
            audio_stream_index or "",
            subtitle_stream_index or "",
        )
        log.debug(
            "New playurl for transcoding: {0}",
            _masque_donnees_sensibles(playurl or ""),
        )

    elif playback_type == "1":  # for direct stream add any streamable subtitles
        external_subs(selected_media_source, list_item, item_id)

    # get chapters for skip intro action
    intro_start, intro_end, credits_start = extract_markers(
        result.get("Chapters") or []
    )
    log_markers(result.get("Name", ""), intro_start, intro_end, credits_start)

    # add playurl and data to the monitor
    data = {}
    data["item_id"] = item_id
    data["source_id"] = source_id
    data["playback_type"] = playback_type_string
    data["play_session_id"] = play_session_id
    data["live_stream_id"] = live_stream_id
    data["play_action_type"] = "play"
    data["item_type"] = result.get("Type", None)
    data["can_delete"] = result.get("CanDelete", False)
    data["intro_start"] = intro_start
    data["intro_end"] = intro_end
    data["credits_start"] = credits_start
    data["subtitle_stream_index"] = subtitle_stream_index
    # v1.22.4 : point de reprise de cette lecture (0 = depuis le debut)
    data["resume_seconds"] = seek_time
    monitor.played_information[playurl] = data
    log.debug("Add to played_information: {0}", monitor.played_information)

    list_item.setPath(playurl)
    list_item = set_list_item_props(
        item_id,
        list_item,
        result,
        server,
        listitem_props,
        item_title,
        maxwidth=max_image_width,
    )

    player = xbmc.Player()

    intro_items = []
    if play_cinema_intros and seek_time == 0:
        intro_items = get_playback_intros(item_id)
    if intro_items is None:
        intro_items = []

    if len(intro_items) > 0:
        playlist = play_all_files(intro_items, "-1", monitor, play_items=False)
        if playlist is None:
            log.debug("Could not build intro playlist, playing main item only")
            playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            playlist.clear()
            playlist.add(playurl, list_item)
        playlist.add(playurl, list_item)
    else:
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playlist.clear()
        playlist.add(playurl, list_item)

    player.play(playlist)

    if seek_time != 0:
        player.pause()
        # v1.22.4 : un serveur qui transcode peut mettre 30 s a demarrer
        wait_tenths = 300 if playback_type == "2" else 100
        if not _wait_for_playback(player, wait_tenths):
            log.info(
                "PlaybackResumeAction : Playback item did not get to a play state in {0} seconds so exiting",
                wait_tenths // 10,
            )
            player.stop()
            return None

        log.info("PlaybackResumeAction : Playback is Running")

        seek_to_time = seek_time - jump_back_amount
        target_seek = seek_to_time - 10

        if not _seek_and_wait(player, seek_to_time, target_seek):
            log.info(
                "PlaybackResumeAction : Playback could not seek to required position"
            )
            player.stop()
        else:
            count = 0
            while bool(xbmc.getCondVisibility("Player.Paused")) and count < 10:
                log.info("PlaybackResumeAction : Unpausing playback")
                player.pause()
                xbmc.sleep(1000)
                count = count + 1

            if count == 10:
                log.info("PlaybackResumeAction : Could not unpause")
            else:
                log.info("PlaybackResumeAction : Playback resumed")

    # v1.22.4 : vitesse du serveur mesuree une fois la video lancee (et la
    # reprise faite), pas pendant le demarrage
    if playback_type == "2":
        check_transcode_later(item_id, selected_media_source, result.get("Name", ""))

    next_episode = get_next_episode(result)
    # v1.17 : film suivant d'une collection (meme mecanique que l'episode
    # suivant : dialogue en fin de film, ou enchainement automatique)
    # v1.21.0 : pas de « film suivant » de collection pour un film au hasard
    # (sa suite est geree par random_session)
    if (
        next_episode is None
        and result.get("Type") == "Movie"
        and not random_session.is_random(result.get("Id"))
    ):
        try:
            next_episode = find_next_movie(result)
        except Exception as err:
            log.error("Film suivant : recherche impossible ({0})", err)
            next_episode = None
        if next_episode is None:
            log.info("Film suivant : aucun pour {0}", result.get("Name"))

    if next_episode is not None:
        next_epp_art = get_art(
            next_episode,
            server,
            maxwidth=max_image_width,
            download_utils=download_utils,
        )
        next_episode["art"] = next_epp_art

    data["next_episode"] = next_episode
    if result.get("Type") == "Episode":
        send_next_episode_details(result, next_episode)
    return None


def __build_label2_from(source: dict) -> str:
    videos = [
        item for item in source.get("MediaStreams", {}) if item.get("Type") == "Video"
    ]
    audios = [
        item for item in source.get("MediaStreams", {}) if item.get("Type") == "Audio"
    ]
    subtitles = [
        item
        for item in source.get("MediaStreams", {})
        if item.get("Type") == "Subtitle"
    ]

    details = [str(convert_size(source.get("Size", 0)))]
    # details.append(source.get('Container', ''))
    for video in videos:
        details.append(
            "{} {} {}bit".format(
                video.get("DisplayTitle", ""),
                video.get("VideoRange", ""),
                video.get("BitDepth", ""),
            )
        )
    aud = []
    for audio in audios:
        aud.append(
            "{} {} {}".format(
                audio.get("Language", ""),
                audio.get("Codec", ""),
                audio.get("Channels", ""),
            )
        )
    if len(aud) > 0:
        details.append(", ".join(aud).upper())
    subs = []
    for subtitle in subtitles:
        subs.append(subtitle.get("Language", ""))
    if len(subs) > 0:
        details.append("S: {}".format(", ".join(subs)).upper())
    return " | ".join(details)


def get_next_episode(item: dict) -> dict | None:
    if item.get("Type", "na") != "Episode":
        log.debug("Not an episode, can not get next")
        return None

    parent_id = item.get("ParentId", "na")
    item_index = item.get("IndexNumber", -1)

    if parent_id == "na":
        log.debug("No parent id, can not get next")
        return None

    if item_index == -1:
        log.debug("No episode number, can not get next")
        return None

    url = "".join(
        [
            "{server}/emby/Users/{userid}/Items?",
            "?Recursive=true",
            "&ParentId=" + parent_id,
            "&IsVirtualUnaired=false",
            "&IsMissing=False",
            "&IncludeItemTypes=Episode",
            "&ImageTypeLimit=1",
            "&fields=CriticRating,OfficialRating,CommunityRating,Overview",
        ]
    )

    data_manager = DataManager()
    items_result = data_manager.get_content(url)
    log.debug("get_next_episode, sibling list: {0}", items_result)

    if items_result is None:
        log.debug("get_next_episode no results")
        return None

    item_list = items_result.get("Items", [])

    for item in item_list:
        index = item.get("IndexNumber", -1)
        # find the very next episode in the season
        if index == item_index + 1:
            log.debug("get_next_episode, found next episode: {0}", item)
            return item

    return None


def next_in_list(items: list, current_id: str | None) -> dict | None:
    """Element qui suit current_id dans items (None si absent ou dernier)."""
    for index, item in enumerate(items):
        if item.get("Id") == current_id:
            if index + 1 < len(items):
                return items[index + 1]
            return None
    return None


def _provider_id(item: dict, provider: str) -> str | None:
    for key, value in (item.get("ProviderIds") or {}).items():
        if str(key).lower() == provider.lower() and value:
            return str(value)
    return None


def _candidate_boxsets(movie: dict) -> list[tuple[str, str]]:
    """Collections susceptibles de contenir ce film, la plus probable d'abord.

    1. la derniere collection parcourue (le film a ete lance depuis son
       contenu) — memorisee par get_content ;
    2. la collection TMDb du film (ProviderIds.TmdbCollection), retrouvee
       parmi les collections du serveur (AnyProviderIdEquals).
    Les collections creees a la main ne sont trouvees que par le cas 1.
    """
    candidates: list[tuple[str, str]] = []
    home_window = HomeWindow()
    context_id = home_window.get_property("embycon_last_boxset_id")
    if context_id:
        candidates.append((context_id, ""))

    tmdb_collection = _provider_id(movie, "TmdbCollection")
    if tmdb_collection:
        url = (
            "{server}/emby/Users/{userid}/Items?IncludeItemTypes=BoxSet"
            "&Recursive=true&AnyProviderIdEquals=tmdb." + tmdb_collection + "&format=json"
        )
        result = DataManager().get_content(url)
        for boxset in (result or {}).get("Items") or []:
            boxset_id = boxset.get("Id")
            if boxset_id and boxset_id != context_id:
                candidates.append((boxset_id, boxset.get("Name") or ""))
    return candidates


def find_next_movie(movie: dict) -> dict | None:
    """v1.17 : film qui suit `movie` dans sa collection, ou None.

    Ordre = reglage « Ordre de lecture d'une collection » (date de sortie
    croissante par defaut, la saga dans l'ordre).
    """
    settings = xbmcaddon.Addon()
    if settings.getSetting("next_movie_mode") in ("", "0"):
        log.info("Film suivant : desactive dans les reglages")
        return None
    movie_id = movie.get("Id")
    order = settings.getSetting("collection_play_order")
    data_manager = DataManager()

    candidates = _candidate_boxsets(movie)
    log.info("Film suivant : collections candidates {0}", [c[0] for c in candidates])
    for boxset_id, boxset_name in candidates:
        url = build_play_all_url(boxset_id, "BoxSet", False, order)
        result = data_manager.get_content(url)
        items = sort_emby_items(
            [
                item
                for item in (result or {}).get("Items") or []
                if item.get("Type") == "Movie"
            ],
            order,
        )
        if not any(item.get("Id") == movie_id for item in items):
            continue
        next_movie = next_in_list(items, movie_id)
        if next_movie is None:
            log.info("Film suivant : dernier film de la collection {0}", boxset_id)
            return None
        if not boxset_name:
            boxset = data_manager.get_content(
                "{server}/emby/Users/{userid}/Items/%s?format=json" % boxset_id
            )
            boxset_name = (boxset or {}).get("Name") or ""
        next_movie["CollectionName"] = boxset_name
        log.info(
            "Film suivant : {0} (collection {1})", next_movie.get("Name"), boxset_name
        )
        return next_movie

    log.info("Film suivant : aucune collection trouvee pour {0}", movie_id)
    return None


def send_next_episode_details(item: dict, next_episode: dict | None) -> None:
    if next_episode is None:
        log.debug("No next episode")
        return

    settings = xbmcaddon.Addon()
    max_image_width = int(settings.getSetting("max_image_width"))
    download_utils = DownloadUtils()
    server = download_utils.get_server()
    if server is None or server == "":
        log.debug("No server found, cannot send next episode details")
        return

    use_prem_date_for_added = settings.getSetting("use_prem_date_for_added") == "true"

    gui_options = GuiOptions(
        server=server,
        name_format=None,
        name_format_type="",
        max_image_width=max_image_width,
        use_prem_date_for_added=use_prem_date_for_added,
    )

    item_details = extract_item_info(item, gui_options, download_utils=download_utils)
    next_item_details = extract_item_info(
        next_episode, gui_options, download_utils=download_utils
    )

    current_item = {}
    current_item["episodeid"] = item_details.id
    current_item["tvshowid"] = item_details.series_name
    current_item["title"] = item_details.name
    current_item["art"] = {}
    if item_details.art is not None:
        current_item["art"]["tvshow.poster"] = item_details.art.get("tvshow.poster", "")
        current_item["art"]["thumb"] = item_details.art.get("thumb", "")
        current_item["art"]["tvshow.fanart"] = item_details.art.get("tvshow.fanart", "")
        current_item["art"]["tvshow.landscape"] = item_details.art.get(
            "tvshow.landscape", ""
        )
        current_item["art"]["tvshow.clearart"] = item_details.art.get(
            "tvshow.clearart", ""
        )
        current_item["art"]["tvshow.clearlogo"] = item_details.art.get(
            "tvshow.clearlogo", ""
        )
    current_item["plot"] = item_details.plot
    current_item["showtitle"] = item_details.series_name
    current_item["playcount"] = item_details.play_count
    current_item["season"] = item_details.season_number
    current_item["episode"] = item_details.episode_number
    current_item["rating"] = item_details.critic_rating
    current_item["firstaired"] = item_details.year

    next_item = {}
    next_item["episodeid"] = next_item_details.id
    next_item["tvshowid"] = next_item_details.series_name
    next_item["title"] = next_item_details.name
    next_item["art"] = {}
    if next_item_details.art is not None:
        next_item["art"]["tvshow.poster"] = next_item_details.art.get(
            "tvshow.poster", ""
        )
        next_item["art"]["thumb"] = next_item_details.art.get("thumb", "")
        next_item["art"]["tvshow.fanart"] = next_item_details.art.get(
            "tvshow.fanart", ""
        )
        next_item["art"]["tvshow.landscape"] = next_item_details.art.get(
            "tvshow.landscape", ""
        )
        next_item["art"]["tvshow.clearart"] = next_item_details.art.get(
            "tvshow.clearart", ""
        )
        next_item["art"]["tvshow.clearlogo"] = next_item_details.art.get(
            "tvshow.clearlogo", ""
        )
    next_item["plot"] = next_item_details.plot
    next_item["showtitle"] = next_item_details.series_name
    next_item["playcount"] = next_item_details.play_count
    next_item["season"] = next_item_details.season_number
    next_item["episode"] = next_item_details.episode_number
    next_item["rating"] = next_item_details.critic_rating
    next_item["firstaired"] = next_item_details.year

    next_info = {
        "current_episode": current_item,
        "next_episode": next_item,
        "play_info": {
            "item_id": next_item_details.id,
            "auto_resume": False,
            "force_transcode": False,
        },
    }
    send_event_notification("upnext_data", next_info)


def set_list_item_props(
    _item_id: str,
    list_item: xbmcgui.ListItem,
    result: dict,
    server: str,
    extra_props: list,
    title: str,
    maxwidth: int = 0,
) -> xbmcgui.ListItem:
    # set up item and item info

    download_utils = DownloadUtils()
    art = get_art(
        result, server=server, maxwidth=maxwidth, download_utils=download_utils
    )
    list_item.setArt(
        {"icon": art["thumb"]}
    )  # changed to setArt due to setIconImage removed from v19
    list_item.setProperty("fanart_image", art["fanart"])  # back compat
    list_item.setProperty("discart", art["discart"])  # not avail to setArt
    list_item.setArt(art)

    list_item.setProperty("IsPlayable", "false")
    list_item.setProperty("IsFolder", "false")
    list_item.setProperty("id", result.get("Id", "unknown"))

    for prop in extra_props:
        list_item.setProperty(prop[0], prop[1])

    item_type = result.get("Type", "").lower()
    mediatype = "video"

    if item_type == "movie" or item_type == "boxset":
        mediatype = "movie"
    elif item_type == "series":
        mediatype = "tvshow"
    elif item_type == "season":
        mediatype = "season"
    elif item_type == "episode":
        mediatype = "episode"
    elif item_type == "audio":
        mediatype = "song"

    if item_type == "audio":
        info_tag_music = list_item.getMusicInfoTag()
        info_tag_music.setMediaType(mediatype)
        info_tag_music.setTitle(title)

    else:
        info_tag_video = list_item.getVideoInfoTag()
        info_tag_video.setMediaType(mediatype)
        info_tag_video.setTitle(title)
        info_tag_video.setPlot(result.get("Overview"))

        tv_show_name = result.get("SeriesName")
        if tv_show_name is not None:
            info_tag_video.setTvShowTitle(tv_show_name)

        if item_type == "episode":
            episode_number = result.get("IndexNumber", -1)
            if episode_number is not None:
                info_tag_video.setEpisode(episode_number)
            season_number = result.get("ParentIndexNumber", -1)
            if season_number is not None:
                info_tag_video.setSeason(season_number)
        elif item_type == "season":
            season_number = result.get("IndexNumber", -1)
            if season_number is not None:
                info_tag_video.setSeason(season_number)

    return list_item


# For transcoding only
# Present the list of audio and subtitles to select from
# for external streamable subtitles add the URL to the Kodi item and let Kodi handle it
# else ask for the subtitles to be burnt in when transcoding
def _log_decision(name: str, media_source: dict, playback_type_string: str, forced: bool) -> None:
    """v1.22.0 : une ligne de journal par lecture (video, limite, decision)."""
    try:
        settings = xbmcaddon.Addon()
        key = "force_max_stream_bitrate" if forced else "max_stream_bitrate"
        log.info(
            "{0}",
            decision_line(
                name,
                media_source,
                settings.getSetting(key),
                settings.getSetting("bitrate_mode") == "1" and not forced,
                playback_type_string,
            )
        )
    except Exception as err:
        log.debug("Journal de decision de lecture : {0}", err)


def _track_words() -> tuple[dict, dict]:
    """Noms de langues (ceux des reglages) et mots des listes de pistes."""
    names = {
        code: string_load(string_id)
        for code, string_id in (
            ("fre", 30481), ("eng", 30482), ("spa", 30483), ("ger", 30484),
            ("ita", 30485), ("por", 30486), ("jpn", 30487), ("dut", 30488),
        )
    }
    words = {
        "unknown": string_load(30901),
        "default": string_load(30902),
        "forced": string_load(30903),
        "external": string_load(30904),
        "none": string_load(30905),
    }
    return names, words


def _select_track(heading: str, labels: list, preselect: int) -> int:
    """v1.22.2 : menu au style du clic droit ; -1 = Retour (choix auto garde)."""
    return choose_track(heading, labels, preselect, string_load(30910), string_load(30911))


def _as_index(value):
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def audio_subs_pref(
    url: str,
    list_item: xbmcgui.ListItem,
    media_source: dict,
    item_id: str,
    audio_stream_index: str,
    subtitle_stream_index: str,
    allow_prompt: bool = True,
) -> str:
    """Pistes audio et sous-titres d'une lecture transcodee.

    v1.22.0 : choix automatique d'apres les langues preferees (reglage
    « Pistes d'une lecture réduite »), ou listes lisibles avec le choix
    automatique pre-selectionne. Un choix deja fait (menu contextuel) est
    toujours respecte.
    """
    settings = xbmcaddon.Addon()
    ask = allow_prompt and settings.getSetting("transcode_tracks_mode") == "1"
    streams = media_source.get("MediaStreams") or []
    source_id = media_source["Id"]
    pref_audio = settings.getSetting("pref_audio_lang")
    pref_sub = settings.getSetting("pref_subtitle_lang")
    subs_if_foreign = settings.getSetting("subtitle_auto_mode") == "1"
    forced_auto = settings.getSetting("subtitle_forced_auto") != "false"
    names, words = _track_words()
    playurlprefs = ""

    # --- audio
    audio = _as_index(audio_stream_index)
    if audio is None:
        audio = choose_audio(streams, pref_audio, media_source.get("DefaultAudioStreamIndex"))
        labels, indexes, pre = menu(streams, "Audio", names, words, audio)
        if ask and len(labels) > 1:
            resp = _select_track(string_load(30908), labels, pre)
            if resp > -1:
                audio = indexes[resp]
    if audio is not None:
        playurlprefs += "&AudioStreamIndex=%s" % audio

    # --- sous-titres
    sub = _as_index(subtitle_stream_index)
    if sub is None:
        sub = choose_subtitle(
            streams,
            stream_language(streams, audio),
            pref_audio,
            pref_sub,
            subs_if_foreign,
            forced_auto,
        )
        labels, indexes, pre = menu(streams, "Subtitle", names, words, sub, words["none"])
        if ask and len(labels) > 1:
            resp = _select_track(string_load(30909), labels, pre)
            if resp > -1:
                sub = indexes[resp]
    elif sub < 0:
        # -1 envoye par la telecommande Emby = aucun sous-titre, choix explicite
        sub = None

    if sub is not None:
        stream = next((s for s in streams if s.get("Index") == sub), {})
        downloadable = (
            stream.get("IsTextSubtitleStream")
            and stream.get("IsExternal")
            and stream.get("SupportsExternalStream")
        )
        if downloadable:
            subtitle_url = "%s/emby/Videos/%s/%s/Subtitles/%s/Stream.srt" % (
                DownloadUtils().get_server(),
                item_id,
                source_id,
                sub,
            )
            log.debug("Streaming subtitles url: {0} {1}", sub, subtitle_url)
            list_item.setSubtitles([subtitle_url])
        else:
            # sous-titres graves dans la video par le serveur
            playurlprefs += "&SubtitleStreamIndex=%s" % sub

    log.info(
        "Pistes de la lecture transcodee ({0}) : audio {1} ({2}), sous-titres {3}",
        "choix manuel" if ask else "automatique",
        audio,
        stream_language(streams, audio) or "?",
        sub if sub is not None else "aucun",
    )

    if url.find("|verifypeer=false") != -1:
        new_url = url.replace("|verifypeer=false", playurlprefs + "|verifypeer=false")
    else:
        new_url = url + playurlprefs

    return new_url


# direct stream, set any available subtitle streams
def external_subs(
    media_source: dict, list_item: xbmcgui.ListItem, item_id: str
) -> None:
    media_streams = media_source.get("MediaStreams")

    if media_streams is None:
        return

    externalsubs = []
    sub_names = []
    download_utils = DownloadUtils()
    names, words = _track_words()

    for stream in media_streams:
        if (
            stream["Type"] == "Subtitle"
            and stream["IsExternal"]
            and stream["IsTextSubtitleStream"]
            and stream["SupportsExternalStream"]
        ):
            index = stream["Index"]
            source_id = media_source["Id"]
            server = download_utils.get_server()
            token = download_utils.authenticate()

            if stream.get("DeliveryUrl", "").lower().startswith("/videos"):
                url = "%s/emby%s" % (server, stream.get("DeliveryUrl"))
            else:
                url = "%s/emby/Videos/%s/%s/Subtitles/%s/Stream.%s?api_key=%s" % (
                    server,
                    item_id,
                    source_id,
                    index,
                    stream["Codec"],
                    token,
                )

            sub_names.append(subtitle_label(stream, names, words))
            externalsubs.append(url)

    if len(externalsubs) == 0:
        return

    settings = xbmcaddon.Addon()
    direct_stream_sub_select = settings.getSetting("direct_stream_sub_select")

    if direct_stream_sub_select == "0" or (
        len(externalsubs) == 1 and not direct_stream_sub_select == "2"
    ):
        list_item.setSubtitles(externalsubs)
    else:
        # lecture directe : pas de choix automatique a marquer ici (Kodi
        # choisit ensuite parmi les sous-titres du fichier si on revient)
        resp = _select_track(string_load(30909), sub_names, -1)
        if resp > -1:
            selected_sub = externalsubs[resp]
            log.debug("External Subtitle Selected: {0}", selected_sub)
            list_item.setSubtitles([selected_sub])


def held_position(play_data: dict, play_time: float) -> float:
    """Position a envoyer au serveur : le point de reprise tant qu'il n'est
    pas atteint (moins une marge d'une minute), la vraie position ensuite."""
    try:
        resume = float(play_data.get("resume_seconds") or 0)
    except (TypeError, ValueError):
        resume = 0.0
    if resume <= 0 or play_data.get("resume_reached"):
        return play_time
    if play_time >= resume - 60:
        play_data["resume_reached"] = True
        return play_time
    return resume


def send_progress(monitor: PlaybackMonitorService) -> None:
    play_data = get_playing_data(monitor.played_information)

    if play_data is None:
        return

    log.debug("Sending Progress Update")

    player = xbmc.Player()
    try:
        play_time = player.getTime()
        total_play_time = player.getTotalTime()
    except Exception:
        # v1.14.1 (audit T2) : la lecture peut s'arreter entre le test
        # isPlaying() et la lecture de la position — ne pas propager
        # l'exception aux callbacks (onPlayBackSeek/Paused/Resumed)
        log.debug("send_progress : lecture arretee, progression non envoyee")
        return
    # v1.22.4 : tant que la reprise n'a pas eu lieu (demarrage lent, echec),
    # le serveur garde le point de reprise au lieu de recevoir 0
    play_time = held_position(play_data, play_time)
    play_data["currentPossition"] = play_time
    play_data["duration"] = total_play_time
    play_data["currently_playing"] = True

    item_id = play_data.get("item_id")
    if item_id is None:
        return

    source_id = play_data.get("source_id")

    ticks = int(play_time * 10000000)
    duration = int(total_play_time * 10000000)
    paused = play_data.get("paused", False)
    playback_type = play_data.get("playback_type")
    play_session_id = play_data.get("play_session_id", "")
    live_stream_id = play_data.get("live_stream_id", "")

    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist_position = playlist.getposition()
    playlist_size = playlist.size()

    volume, muted = get_volume()

    postdata = {
        "QueueableMediaTypes": "Video",
        "CanSeek": True,
        "ItemId": item_id,
        "MediaSourceId": source_id,
        "IsPaused": paused,
        "IsMuted": muted,
        "PlayMethod": playback_type,
        "PlaySessionId": play_session_id,
        "LiveStreamId": live_stream_id,
        "PlaylistIndex": playlist_position,
        "PlaylistLength": playlist_size,
        "VolumeLevel": volume,
    }

    if duration is not None and duration > 0:
        postdata["RunTimeTicks"] = duration
        postdata["PositionTicks"] = ticks

    log.debug("Sending POST progress started: {0}", postdata)
    url = "{server}/emby/Sessions/Playing/Progress"
    download_utils = DownloadUtils()
    download_utils.download_url(url, post_body=postdata, method="POST")


def get_volume() -> tuple[int | None, bool | None]:
    json_data = xbmc.executeJSONRPC(
        '{ "jsonrpc": "2.0", "method": "Application.GetProperties", "params": {"properties": ["volume", "muted"]}, "id": 1 }'
    )
    result = json.loads(json_data)
    result = result.get("result", {})
    volume = result.get("volume")
    muted = result.get("muted")

    return volume, muted


def prompt_for_stop_actions(item_id: str, data: dict) -> None:
    log.debug("prompt_for_stop_actions Called : {0}", data)

    settings = xbmcaddon.Addon()
    current_position = data.get("currentPossition", 0)
    duration = data.get("duration", 0)
    # media_source_id = data.get("source_id")
    next_episode = data.get("next_episode")
    item_type = data.get("item_type")
    can_delete = data.get("can_delete", False)

    prompt_delete_episode_percentage = int(
        settings.getSetting("promptDeleteEpisodePercentage")
    )
    prompt_delete_movie_percentage = int(
        settings.getSetting("promptDeleteMoviePercentage")
    )

    # v1.17 : enchainement automatique du film suivant d'une collection
    # v1.18.1 : aussi en mode « dialogue » (1) : le dialogue propose, et sans
    # refus de l'utilisateur le film suivant demarre a la fin. Pas
    # d'enchainement si « Play Now » a deja lance le suivant ou si le
    # dialogue a ete ferme (Retour).
    # v1.20.0 : meme logique pour les episodes (« À la fin d'un épisode »),
    # qui remplace « À l'arrêt après X %, lancer l'épisode suivant ».
    next_auto = next_episode is not None and not data.get("next_handled", False)
    if item_type == "Movie":
        next_auto = next_auto and settings.getSetting("next_movie_mode") in ("1", "2")
    elif item_type == "Episode":
        next_auto = next_auto and settings.getSetting("next_episode_mode") in ("1", "2")
    else:
        next_auto = False

    # everything is off so return
    if (
        prompt_delete_episode_percentage == 100
        and prompt_delete_movie_percentage == 100
        and not next_auto
        and not random_session.is_random(item_id)
    ):
        return

    prompt_to_delete = False

    # if no runtime we cant calculate perceantge so just return
    if duration == 0:
        log.debug("No duration so returing")
        random_session.handle_stop(item_id, 100 if data.get("playback_ended") else 0)
        return

    # item percentage complete
    # percenatge_complete = int(((current_position * 10000000) / runtime) * 100)
    percenatge_complete = int((current_position / duration) * 100)
    # v1.21.3 : la position n'est relevee que toutes les 10 s ; une fin
    # naturelle de lecture vaut 100 % (enchainements film / episode / hasard)
    if data.get("playback_ended"):
        percenatge_complete = 100
    log.debug("Episode Percentage Complete: {0}", percenatge_complete)

    if (
        can_delete
        and prompt_delete_episode_percentage < 100
        and item_type == "Episode"
        and percenatge_complete > prompt_delete_episode_percentage
    ):
        prompt_to_delete = True

    if (
        can_delete
        and prompt_delete_movie_percentage < 100
        and item_type == "Movie"
        and percenatge_complete > prompt_delete_movie_percentage
    ):
        prompt_to_delete = True

    if prompt_to_delete:
        log.debug("Prompting for delete")
        delete(item_id)

    # v1.21.0 : film au hasard -> accueil, ou film suivant tire au sort
    if random_session.handle_stop(item_id, percenatge_complete):
        return

    if item_type in ("Movie", "Episode") and next_episode is not None:
        log.info(
            "{0} suivant : fin a {1} %, enchainement={2} (deja traite={3})",
            item_type,
            percenatge_complete,
            next_auto and percenatge_complete >= NEXT_MOVIE_AUTO_PERCENT,
            data.get("next_handled", False),
        )
    if next_auto and percenatge_complete >= NEXT_MOVIE_AUTO_PERCENT:
        next_item_id = next_episode.get("Id")
        log.info("{0} suivant (automatique) : {1}", item_type, next_episode.get("Name"))
        xbmcgui.Dialog().notification(
            string_load(30572 if item_type == "Movie" else NEXT_EPISODE_STRING),
            next_episode.get("Name") or "",
            icon="special://home/addons/plugin.video.embycon/icon-addon.png",
        )
        play_info = {}
        play_info["item_id"] = next_item_id
        play_info["auto_resume"] = "-1"
        play_info["force_transcode"] = False
        send_event_notification("embycon_play_action", play_info)
        return


def stop_all_playback(played_information: dict[str, dict], ended: bool = False) -> None:
    log.debug("stop_all_playback : {0}", played_information)

    if len(played_information) == 0:
        return

    log.debug("played_information: {0}", played_information)

    home_screen = HomeWindow()
    home_screen.clear_property("currently_playing_id")
    download_utils = DownloadUtils()

    for item_url in played_information:
        data = played_information.get(item_url, {})
        if data.get("currently_playing", False) is True:
            log.debug("item_url: {0}", item_url)
            log.debug("item_data: {0}", data)

            current_position = data.get("currentPossition", 0)
            duration = data.get("duration", 0)
            emby_item_id = data.get("item_id")
            emby_source_id = data.get("source_id")
            play_session_id = data.get("play_session_id", "")
            live_stream_id = data.get("live_stream_id", "")

            if emby_item_id is not None and current_position >= 0:
                log.debug("Playback Stopped at: {0}", current_position)

                url = "{server}/emby/Sessions/Playing/Stopped"
                postdata = {
                    "ItemId": emby_item_id,
                    "MediaSourceId": emby_source_id,
                    "PositionTicks": int(current_position * 10000000),
                    "RunTimeTicks": int(duration * 10000000),
                    "PlaySessionId": play_session_id,
                    "LiveStreamId": live_stream_id,
                }
                download_utils.download_url(url, post_body=postdata, method="POST")
                data["currently_playing"] = False
                # v1.21.3 : fin naturelle (onPlayBackEnded) -> vu jusqu'au bout,
                # meme si la derniere position connue date de 10 s
                if ended:
                    data["playback_ended"] = True

                if data.get("play_action_type", "") == "play":
                    prompt_for_stop_actions(emby_item_id, data)

    device_id = ClientInformation().get_device_id()
    url = "{server}/emby/Videos/ActiveEncodings?DeviceId=%s" % device_id
    download_utils.download_url(url, method="DELETE")


def get_playing_data(play_data_map: dict[str, dict]) -> dict | None:
    try:
        playing_file = xbmc.Player().getPlayingFile()
    except Exception as e:
        log.error("get_playing_data : getPlayingFile() : {0}", e)
        return None
    log.debug("get_playing_data : getPlayingFile() : {0}", playing_file)
    if playing_file not in play_data_map:
        infolabel_path_and_file = xbmc.getInfoLabel("Player.Filenameandpath")
        log.debug("get_playing_data : Filenameandpath : {0}", infolabel_path_and_file)
        if infolabel_path_and_file not in play_data_map:
            log.debug("get_playing_data : play data not found")
            return None
        playing_file = infolabel_path_and_file

    return play_data_map.get(playing_file)


# v1.22.0 : helpers de langue deplaces dans track_choice (partages avec le
# choix des pistes d'une lecture transcodee)
_LANG_ALIASES = LANG_ALIASES
_lang_matches = lang_matches


def _kodi_subtitle_streams() -> list:
    """Pistes de sous-titres du lecteur avec langue + drapeau 'isforced'.

    L'API xbmc.Player n'expose PAS l'attribut forced ; on passe donc par
    JSON-RPC Player.GetProperties qui renvoie index/language/isforced/isdefault
    (disponible depuis Kodi 19 Matrix). L'index renvoye correspond a celui
    attendu par player.setSubtitleStream().
    """
    req = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "Player.GetProperties",
        "params": {"playerid": 1, "properties": ["subtitles"]},
    }
    try:
        resp = json.loads(xbmc.executeJSONRPC(json.dumps(req)))
        return resp.get("result", {}).get("subtitles", []) or []
    except Exception as e:
        log.error("_kodi_subtitle_streams failed: {0}", e)
        return []


def _pick_subtitle(
    streams: list,
    pref_sub: str,
    forced_only: bool = False,
    prefer_non_forced: bool = False,
):
    """Index Kodi d'un sous-titre de la langue preferee, ou None.

    forced_only=True      -> uniquement une piste forced (traduction des
                             passages etrangers / textes a l'ecran).
    prefer_non_forced=True -> privilegie une piste complete (non-forced),
                             et retombe sur une forced a defaut.
    """
    match_forced = None
    match_full = None
    for s in streams:
        if not _lang_matches(s.get("language", ""), pref_sub):
            continue
        if s.get("isforced"):
            if match_forced is None:
                match_forced = s.get("index")
        elif match_full is None:
            match_full = s.get("index")
    if forced_only:
        return match_forced
    if prefer_non_forced:
        return match_full if match_full is not None else match_forced
    return match_full if match_full is not None else match_forced


_canonical_lang = canonical_lang


def pick_forced_subtitle(streams: list, audio_lang: str, pref_sub: str):
    """v1.18 : index Kodi de la piste FORCEE a afficher, ou None.

    Une piste forcee traduit les passages en langue etrangere et les textes a
    l'ecran : elle doit etre dans la langue de l'audio. Ordre de preference :
    1. piste forcee dans la langue de l'audio ;
    2. piste forcee dans la langue de sous-titres preferee.
    Jamais une forcee d'une autre langue (elle ne servirait a rien).
    """
    audio_code = _canonical_lang(audio_lang)
    forced = [s for s in streams if s.get("isforced")]
    if audio_code:
        for s in forced:
            if _canonical_lang(s.get("language", "")) == audio_code:
                return s.get("index")
    if pref_sub:
        for s in forced:
            if _lang_matches(s.get("language", ""), pref_sub):
                return s.get("index")
    return None


def _wait_subtitle_streams() -> list:
    # Attendre l'enumeration des pistes : les sous-titres embarques
    # (notamment forced) apparaissent parfois un instant apres onAVStarted.
    streams = []
    for _ in range(20):  # ~2 s max
        streams = _kodi_subtitle_streams()
        if streams:
            break
        xbmc.sleep(100)
    return streams


def apply_forced_subtitle_only(play_data: dict, pref_sub: str) -> None:
    """v1.18 : mode sous-titres « Desactive » + reglage « sous-titres forces
    automatiques » : affiche la piste forcee adaptee si aucun sous-titre
    n'est deja affiche (choix de Kodi ou de l'utilisateur respecte).
    """
    if play_data and play_data.get("subtitle_stream_index"):
        return
    if xbmc.getCondVisibility("VideoPlayer.SubtitlesEnabled"):
        log.debug("Forced subs: sous-titres deja affiches, rien a faire")
        return
    streams = _wait_subtitle_streams()
    audio_lang = xbmc.getInfoLabel("VideoPlayer.AudioLanguage")
    idx = pick_forced_subtitle(streams, audio_lang, pref_sub)
    log.debug(
        "Forced subs: audio='{0}' pref_sub='{1}' streams={2} -> {3}",
        audio_lang, pref_sub, streams, idx,
    )
    if idx is not None:
        player = xbmc.Player()
        player.setSubtitleStream(idx)
        player.showSubtitles(True)
        log.info("Sous-titres forces actives (piste {0})", idx)


def apply_intelligent_subtitle(play_data: dict) -> None:
    """Mode sous-titres « Intelligent » (facon Emby).

    Au demarrage de la lecture : si l'audio n'est PAS dans la langue audio
    preferee, active automatiquement une piste de sous-titres dans la langue
    de sous-titres preferee. Si l'audio est deja dans la langue preferee, les
    sous-titres sont desactives. Un choix manuel de sous-titres est respecte.

    Applique via l'API du lecteur Kodi -> fonctionne pour la lecture directe,
    le direct stream et le transcodage, sans dupliquer le rendu (gere par Kodi).
    """
    try:
        # v1.22.0 : video reduite -> les pistes ont deja ete choisies et
        # envoyees au serveur (audio_subs_pref) ; Kodi ne voit au mieux que le
        # sous-titre externe choisi, ne pas le masquer ni en chercher un autre.
        if play_data and play_data.get("playback_type") == "Transcode":
            log.debug("Sous-titres : lecture transcodee, choix deja fait")
            return
        settings = xbmcaddon.Addon()
        # v1.18 : sous-titres forces automatiques (reglage independant du mode)
        forced_auto = settings.getSetting("subtitle_forced_auto") != "false"
        if settings.getSetting("subtitle_auto_mode") != "1":
            if forced_auto:
                apply_forced_subtitle_only(
                    play_data, settings.getSetting("pref_subtitle_lang")
                )
            return
        # Ne jamais ecraser un choix explicite de l'utilisateur.
        if play_data and play_data.get("subtitle_stream_index"):
            return
        pref_audio = settings.getSetting("pref_audio_lang")
        pref_sub = settings.getSetting("pref_subtitle_lang")
        if not pref_audio or not pref_sub:
            return

        player = xbmc.Player()
        audio_lang = xbmc.getInfoLabel("VideoPlayer.AudioLanguage")
        streams = _wait_subtitle_streams()

        log.debug(
            "Intelligent subs: audio='{0}' pref_audio='{1}' pref_sub='{2}' streams={3}",
            audio_lang, pref_audio, pref_sub, streams,
        )

        if _lang_matches(audio_lang, pref_audio):
            # L'audio est deja dans la langue preferee : pas de sous-titres
            # complets, MAIS on active une eventuelle piste FORCED de la langue
            # preferee (traduction des passages etrangers / textes a l'ecran),
            # qui doit toujours s'afficher.
            forced_idx = None
            if forced_auto:
                forced_idx = pick_forced_subtitle(streams, audio_lang, pref_sub)
            if forced_idx is not None:
                player.setSubtitleStream(forced_idx)
                player.showSubtitles(True)
                log.debug("Intelligent subs: forced sub actif (stream {0})", forced_idx)
            else:
                player.showSubtitles(False)
            return

        # Audio dans une langue etrangere : afficher des sous-titres COMPLETS
        # dans la langue preferee (on privilegie une piste non-forced).
        idx = _pick_subtitle(streams, pref_sub, prefer_non_forced=True)
        if idx is not None:
            player.setSubtitleStream(idx)
            player.showSubtitles(True)
            log.debug("Intelligent subs: sous-titres actifs (stream {0})", idx)
            return
        log.debug("Intelligent subs: aucun sous-titre correspondant a '{0}'", pref_sub)
    except Exception as e:
        log.error("apply_intelligent_subtitle failed: {0}", e)


class PlaybackMonitorService(xbmc.Player):
    def __init__(self) -> None:
        log.debug("Starting PlaybackMonitorService")
        self.played_information = {}
        self.currently_playing_id = None

    def onPlayBackStarted(self) -> None:
        # Will be called when xbmc starts playing a file
        log.debug("onPlayBackStarted")

        if not xbmc.Player().isPlaying():
            log.debug("onPlayBackStarted: not playing file!")
            return

        play_data = get_playing_data(self.played_information)

        if play_data is None:
            stop_all_playback(self.played_information)
            return

        play_data["paused"] = False
        play_data["currently_playing"] = True

        emby_item_id = play_data["item_id"]
        emby_source_id = play_data["source_id"]
        playback_type = play_data["playback_type"]
        play_session_id = play_data["play_session_id"]
        live_stream_id = play_data["live_stream_id"]

        # if we could not find the ID of the current item then return
        if emby_item_id is None:
            return

        # set currently play item id
        self.currently_playing_id = emby_item_id

        log.debug("Sending Playback Started")
        postdata = {
            "QueueableMediaTypes": "Video",
            "CanSeek": True,
            "ItemId": emby_item_id,
            "MediaSourceId": emby_source_id,
            "PlayMethod": playback_type,
            "PlaySessionId": play_session_id,
            "LiveStreamId": live_stream_id,
        }

        log.debug("Sending POST play started: {0}", postdata)

        url = "{server}/emby/Sessions/Playing"
        download_utils = DownloadUtils()
        download_utils.download_url(url, post_body=postdata, method="POST")

        home_screen = HomeWindow()
        home_screen.set_property("currently_playing_id", str(emby_item_id))

        # start the skip intro monitor
        settings = xbmcaddon.Addon()
        skip_intros = settings.getSetting("skip_intros")
        # v1.18.1 : une ligne claire par lecture pour diagnostiquer le saut
        if skip_intros in ("", "0"):
            log.info("Saut d'intro : desactive dans les reglages (Qualite & lecture)")
        if skip_intros not in ("", "0"):
            intro_start = play_data.get("intro_start", 0)
            intro_end = play_data.get("intro_end", 0)
            # Repli duree fixe : si le serveur n'a pas de marqueur d'intro,
            # sauter les X premieres secondes (0 = desactive)
            if not (intro_end > 0 and intro_end > intro_start):
                try:
                    fb_intro = int(settings.getSetting("skip_intro_fallback_seconds"))
                except (TypeError, ValueError):
                    fb_intro = 0
                if fb_intro > 0:
                    intro_start = 0
                    intro_end = fb_intro * 10000000
            if not (intro_end > 0 and intro_end > intro_start):
                log.info(
                    "Saut d'intro : pas de marqueur serveur et pas de repli (item {0})",
                    emby_item_id,
                )
            if intro_end > 0 and intro_end > intro_start:
                log.info(
                    "Saut d'intro : {0} de {1:.0f} s a {2:.0f} s",
                    "automatique" if skip_intros == "2" else "bouton",
                    intro_start / 10000000.0,
                    intro_end / 10000000.0,
                )
                skip_monitor = SkipIntroMonitor()
                skip_monitor.set_times(intro_start, intro_end)
                skip_monitor.set_auto_skip(skip_intros == "2")
                # v1.14.1 (audit T4) : la lecture peut s'arreter dans la
                # fenetre entre isPlaying() et getPlayingFile() — ne pas
                # laisser l'exception tuer le demarrage des moniteurs
                try:
                    skip_monitor.set_play_path(xbmc.Player().getPlayingFile())
                except Exception:
                    log.debug("moniteur saut d'intro : lecture deja arretee")
                skip_monitor.start()

        # start the skip credits (end of episode) monitor
        skip_credits = settings.getSetting("skip_credits")
        if skip_credits and skip_credits != "0":
            credits_start = play_data.get("credits_start", 0)
            # Repli duree fixe : si le serveur n'a pas de marqueur CreditsStart,
            # proposer/effectuer le saut X secondes avant la fin (0 = desactive)
            try:
                fb_credits = int(settings.getSetting("skip_credits_fallback_seconds"))
            except (TypeError, ValueError):
                fb_credits = 0
            if credits_start > 0 or fb_credits > 0:
                credits_monitor = SkipCreditsMonitor()
                credits_monitor.set_credits_start(credits_start)
                credits_monitor.set_before_end(fb_credits)
                credits_monitor.set_auto_skip(skip_credits == "2")
                # v1.14.1 (audit T4) : meme garde que le moniteur d'intro
                try:
                    credits_monitor.set_play_path(xbmc.Player().getPlayingFile())
                except Exception:
                    log.debug("moniteur saut de generique : lecture deja arretee")
                credits_monitor.start()

    def onAVStarted(self) -> None:
        if not xbmc.Player().isPlayingVideo():
            return
        play_data = get_playing_data(self.played_information)
        if play_data is None:
            return
        apply_intelligent_subtitle(play_data)
        log.debug("onAVStarted: ActivateWindow(fullscreenvideo)")
        xbmc.executebuiltin("ActivateWindow(fullscreenvideo)")

    def onPlayBackEnded(self) -> None:
        # Will be called when kodi stops playing a file
        log.info("onPlayBackEnded")
        stop_all_playback(self.played_information, ended=True)
        if self.currently_playing_id is not None:
            log.info("marking item watched : {0}", self.currently_playing_id)
            mark_item_watched(self.currently_playing_id, refresh=False)
        self.currently_playing_id = None
        self._flag_refresh_after_playback()

    def onPlayBackStopped(self) -> None:
        # Will be called when user stops kodi playing a file
        log.info("onPlayBackStopped")
        stop_all_playback(self.played_information)
        self.currently_playing_id = None
        self._flag_refresh_after_playback()

    def _flag_refresh_after_playback(self) -> None:
        # EmbyCon FR: signale TOUJOURS la fin de lecture au service. C'est le
        # service (thread principal, hors lecture) qui appelle
        # check_for_new_content() et decide du Container.Refresh selon le
        # reglage auto_refresh_after_playback. Aucun rechargement de widgets
        # n'est declenche depuis les callbacks du player : c'etait la source
        # des segfaults CGUIListItem pendant les transitions d'episodes.
        HomeWindow().set_property("embycon_refresh_pending", "true")

    def onPlayBackPaused(self) -> None:
        # Will be called when kodi pauses the video
        log.info("onPlayBackPaused")

        play_data = get_playing_data(self.played_information)

        if play_data is not None:
            play_data["paused"] = True
            send_progress(self)

    def onPlayBackResumed(self) -> None:
        # Will be called when kodi resumes the video
        log.info("onPlayBackResumed")

        play_data = get_playing_data(self.played_information)

        if play_data is not None:
            play_data["paused"] = False
            send_progress(self)

    def onPlayBackSeek(self, time: int, seekOffset: int) -> None:  # noqa: ARG002
        # Will be called when kodi seeks in video
        log.info("onPlayBackSeek")
        send_progress(self)


class MonitoringService(xbmc.Monitor):
    background_image_cache_thread = None
    play_monitor: PlaybackMonitorService

    def __init__(self, monitor: PlaybackMonitorService) -> None:
        self.play_monitor = monitor

    def onNotification(self, sender: str, method: str, data: str) -> None:
        log.debug("PlaybackService:onNotification:{0}:{1}:{2}", sender, method, data)

        if method == "GUI.OnScreensaverActivated":
            self.screensaver_activated()
            return

        if method == "GUI.OnScreensaverDeactivated":
            self.screensaver_deactivated()
            return

        if sender[-7:] != ".SIGNAL":
            return

        signal = method.split(".", 1)[-1]
        if signal not in (
            "embycon_play_action",
            "embycon_play_youtube_trailer_action",
            "set_view",
        ):
            return

        data_json = json.loads(data)
        message_data = data_json[0]
        log.debug("PlaybackService:onNotification:{0}", message_data)
        decoded_data = base64.b64decode(message_data)
        play_info = json.loads(decoded_data.decode("utf-8"))

        if signal == "embycon_play_action":
            log.info("Received embycon_play_action : {0}", play_info)
            play_file(play_info, self.play_monitor)
        elif signal == "embycon_play_youtube_trailer_action":
            log.info("Received embycon_play_trailer_action : {0}", play_info)
            trailer_link = play_info["url"]
            xbmc.executebuiltin(trailer_link)
        elif signal == "set_view":
            view_id = play_info["view_id"]
            log.debug("Setting view id: {0}", view_id)
            xbmc.executebuiltin("Container.SetViewMode(%s)" % int(view_id))

    def screensaver_activated(self) -> None:
        log.debug("Screen Saver Activated")

        home_screen = HomeWindow()
        home_screen.clear_property("skip_select_user")

        settings = xbmcaddon.Addon()
        stop_playback = settings.getSetting("stopPlaybackOnScreensaver") == "true"

        if stop_playback:
            player = xbmc.Player()
            if player.isPlayingVideo():
                log.debug("Screen Saver Activated : isPlayingVideo() = true")
                play_data = get_playing_data(self.play_monitor.played_information)
                if play_data:
                    log.debug(
                        "Screen Saver Activated : this is an EmbyCon item so stop it"
                    )
                    player.stop()

        # xbmc.executebuiltin("Dialog.Close(selectdialog, true)")

        clear_old_cache_data()

        cache_images = settings.getSetting("cacheImagesOnScreenSaver") == "true"
        if cache_images:
            self.background_image_cache_thread = CacheArtwork()
            self.background_image_cache_thread.start()

    def screensaver_deactivated(self) -> None:
        log.debug("Screen Saver Deactivated")

        if self.background_image_cache_thread:
            self.background_image_cache_thread.stop_activity()
            self.background_image_cache_thread = None

        # v1.20.0 : plus de dialogue de changement d'utilisateur a la sortie
        # de veille (reglage retire ; « Changer d'utilisateur » reste dans
        # Serveur et compte)
