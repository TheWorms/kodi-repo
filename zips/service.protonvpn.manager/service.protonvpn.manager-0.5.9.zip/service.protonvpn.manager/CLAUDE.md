# CLAUDE.md — kodi-addon-protonvpn

## Rôle
Gestion de connexions ProtonVPN (OpenVPN+WireGuard) depuis Kodi + widget d'état skin.

## Stack
Service Python (`xbmc.service`), WindowXML pour Arctic Zephyr, `release.sh` bash local
(différent du `release-addon.sh` racine).

## Build / test
`release.sh` : valide py/xml, tag, push, build zip via rsync+zip.

## Déploiement
GitHub + Forgejo, zip agrégé dans `kodi-repo`, install Cormoran.

## Accès hors-repo
- `../kodi-repo` (rsync `--delete` vers `service.protonvpn.manager/` AVANT régénération)
- `FORGEJO_TOKEN` / `~/.config/forgejo-token` (lecture interdite à Claude Code — deny explicite)
- SSH Cormoran

## Pièges
- **NE JAMAIS recréer/écraser le README** — destruction accidentelle du contenu
  multilingue déjà survenue par le passé. Règle permanente et non négociable.
- Remote `origin` (GitHub) doit rester HTTPS-only (`gh auth setup-git`) — ceci concerne
  UNIQUEMENT le protocole du remote git (push/pull vers GitHub), PAS l'accès SSH vers
  Cormoran listé plus haut dans "Accès hors-repo" (diagnostics de version installée).
  **PROTOCOLE GIT vs SSH DIAGNOSTIC : deux choses distinctes, ne pas confondre.**
  SSH vers Cormoran reste autorisé et nécessaire pour les diagnostics.
- Oubli du sync vers `kodi-repo` = republication silencieuse de l'ancien zip.

## Dépendances croisées
`kodi-repo`.
