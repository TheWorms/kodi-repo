#!/usr/bin/env bash
# Hook PreToolUse — blocage secrets (en plus des deny rules).
# exit 2 = blocage avec message renvoyé à Claude Code.

INPUT="$(cat)"

TARGET="$(printf '%s' "$INPUT" | python3 -c '
import json,sys
d=json.load(sys.stdin)
ti=d.get("tool_input",{})
print(ti.get("file_path") or ti.get("command") or "")
' 2>/dev/null)"

[ -z "$TARGET" ] && exit 0

BLOCK_PATTERNS='(^|[/ ])\.env([./ "]|$)|\.ssh/id_|_secure|_light|\.pr1v8te|\.aws/|\.gnupg/'

if printf '%s' "$TARGET" | grep -Eq "$BLOCK_PATTERNS"; then
  if printf '%s' "$TARGET" | grep -Eq '\.ssh/config$'; then
    exit 0
  fi
  echo "BLOQUE (CLAUDE.md) : acces a un secret interdit ($TARGET). Demander la valeur a Thib au lieu de lire le fichier." >&2
  exit 2
fi

exit 0
