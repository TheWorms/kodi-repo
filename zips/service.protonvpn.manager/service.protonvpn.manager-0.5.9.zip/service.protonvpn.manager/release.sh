#!/usr/bin/env bash
# =============================================================================
# release.sh — cycle de release complet pour service.protonvpn.manager
#
#   build zip installable  ->  commit + push (origin GitHub + forgejo)
#   ->  tag  ->  release GitHub (gh)  ->  release Forgejo (API)
#   ->  regeneration du repo Kodi (kodi-repo)  ->  verif de l'index
#
# Usage :
#   ./release.sh                 # release la version courante d'addon.xml
#   ./release.sh 0.6.0           # bump addon.xml -> 0.6.0 puis release
#   ./release.sh --retag         # re-pose le tag sur le HEAD s'il existe deja
#   DRY_RUN=1 ./release.sh        # montre les actions sans rien pousser
#
# Pre-requis : git, zip, python3, gh (connecte), curl.
# Token Forgejo : variable FORGEJO_TOKEN, ou fichier ~/.config/forgejo-token.
# =============================================================================
set -euo pipefail

# ----------------------------- Configuration ---------------------------------
ADDON_ID="service.protonvpn.manager"
ADDON_DIR="/run/media/theworms/Data/Git/kodi-addon-protonvpn"
KODI_REPO_DIR="/run/media/theworms/Data/Git/kodi-repo"
BRANCH="main"
GH_REMOTE="origin"          # GitHub (HTTPS)
FJ_REMOTE="forgejo"         # Forgejo (miroir)
FORGEJO_API="http://192.168.0.230:3000/api/v1/repos/theworms/kodi-addon-protonvpn"
ADDONS_XML_URL="https://raw.githubusercontent.com/TheWorms/kodi-repo/main/zips/addons.xml"
OUT_DIR="${ADDON_DIR}/dist"  # les zips y sont generes (ignore par git via *.zip)
# -----------------------------------------------------------------------------

RETAG=0
NEWVER=""
for a in "$@"; do
  case "$a" in
    --retag) RETAG=1 ;;
    [0-9]*.[0-9]*.[0-9]*) NEWVER="$a" ;;
    *) echo "argument inconnu: $a" >&2; exit 2 ;;
  esac
done

say()  { printf '\033[1;36m==>\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m/!\\\033[0m %s\n' "$*"; }
die()  { printf '\033[1;31mERREUR:\033[0m %s\n' "$*" >&2; exit 1; }
run()  { if [ "${DRY_RUN:-0}" = "1" ]; then echo "   [dry-run] $*"; else eval "$@"; fi; }

command -v git  >/dev/null || die "git manquant"
command -v zip  >/dev/null || die "zip manquant"
command -v gh   >/dev/null || warn "gh manquant : release GitHub sautee"
command -v curl >/dev/null || warn "curl manquant : release Forgejo + verif sautees"

cd "$ADDON_DIR" || die "repo addon introuvable : $ADDON_DIR"
[ -f addon.xml ] || die "addon.xml absent (mauvais dossier ?)"

# -------- 0) bump de version optionnel ---------------------------------------
if [ -n "$NEWVER" ]; then
  say "Bump addon.xml -> $NEWVER"
  run "sed -i 's/version=\"[0-9]\\+\\.[0-9]\\+\\.[0-9]\\+\"/version=\"$NEWVER\"/' addon.xml"
fi

VERSION="$(python3 - <<'PY'
import re,io
t=io.open('addon.xml',encoding='utf-8').read()
m=re.search(r'id="service\.protonvpn\.manager"\s+version="([^"]+)"',t) or re.search(r'version="([^"]+)"',t)
print(m.group(1))
PY
)"
[ -n "$VERSION" ] || die "impossible de lire la version dans addon.xml"
TAG="v${VERSION}"
ZIP="${OUT_DIR}/kodi-addon-protonvpn-${VERSION}.zip"
say "Version : $VERSION   (tag $TAG)"

# -------- 1) validations -----------------------------------------------------
say "Validation Python + XML"
run "python3 -m py_compile addon.py service.py lib/*.py"
run "python3 -c \"import xml.dom.minidom as m;[m.parse(f) for f in ['addon.xml','resources/settings.xml','resources/skin/Includes_ProtonVPNWidget.xml']]\""
# le changelog doit commencer par la version publiee
if ! head -1 changelog.txt | grep -q "v${VERSION}"; then
  warn "changelog.txt ne commence pas par v${VERSION} — pense a l'ajouter."
fi

# -------- 2) branche + commit source -----------------------------------------
CUR_BRANCH="$(git rev-parse --abbrev-ref HEAD)"
[ "$CUR_BRANCH" = "$BRANCH" ] || die "tu es sur '$CUR_BRANCH', attendu '$BRANCH'"

# les artefacts locaux ne doivent jamais etre commites ni finir dans le zip
for pat in 'dist/' 'release.sh'; do
  grep -qxF "$pat" .gitignore 2>/dev/null || { echo "$pat" >> .gitignore; say ".gitignore += $pat"; }
done

if [ -n "$(git status --porcelain)" ]; then
  say "Commit des sources"
  run "git add -A"
  run "git commit -m \"${TAG} — release\""
else
  say "Aucun changement a committer (sources deja commitees)"
fi

# -------- 3) tag -------------------------------------------------------------
if git rev-parse -q --verify "refs/tags/${TAG}" >/dev/null; then
  if [ "$RETAG" = "1" ]; then
    say "Re-pose du tag ${TAG} sur HEAD"
    run "git tag -f ${TAG} HEAD"
  else
    die "le tag ${TAG} existe deja (relance avec --retag pour le deplacer)"
  fi
else
  say "Creation du tag ${TAG}"
  run "git tag ${TAG} HEAD"
fi

# -------- 4) push branche + tag sur les deux remotes -------------------------
say "Push ${BRANCH} + ${TAG} -> ${GH_REMOTE} (GitHub) et ${FJ_REMOTE} (Forgejo)"
run "git push ${GH_REMOTE} ${BRANCH}"
run "git push ${FJ_REMOTE} ${BRANCH}"
run "git push ${GH_REMOTE} ${TAG} --force"
run "git push ${FJ_REMOTE} ${TAG} --force"

# -------- 5) build du zip installable (wrapper = ADDON_ID/) ------------------
say "Construction du zip installable : $ZIP"
run "mkdir -p '$OUT_DIR'"
if [ "${DRY_RUN:-0}" != "1" ]; then
  TMP="$(mktemp -d)"
  mkdir -p "$TMP/$ADDON_ID"
  # copie du working tree sans le superflu
  rsync -a --exclude '.git' --exclude 'dist' --exclude '__pycache__' \
        --exclude '*.pyc' --exclude '*.zip' --exclude '*.pvpnbak' \
        --exclude 'release.sh' ./ "$TMP/$ADDON_ID/"
  rm -f "$ZIP"
  ( cd "$TMP" && zip -rqX "$ZIP" "$ADDON_ID" )
  rm -rf "$TMP"
  say "Zip pret : $(du -h "$ZIP" | cut -f1)"
fi

# -------- 6) release GitHub (gh) ---------------------------------------------
if command -v gh >/dev/null; then
  NOTES="$(head -1 changelog.txt); voir changelog.txt"
  if gh release view "$TAG" >/dev/null 2>&1; then
    say "Release GitHub existante -> mise a jour de l'asset"
    run "gh release upload '$TAG' '$ZIP' --clobber"
  else
    say "Creation de la release GitHub $TAG"
    run "gh release create '$TAG' '$ZIP' --title '$TAG' --notes \"$NOTES\""
  fi
fi

# -------- 7) release Forgejo (API) ------------------------------------------
FJ_TOKEN="${FORGEJO_TOKEN:-}"
[ -z "$FJ_TOKEN" ] && [ -f "$HOME/.config/forgejo-token" ] && FJ_TOKEN="$(cat "$HOME/.config/forgejo-token")"
if [ -n "$FJ_TOKEN" ] && command -v curl >/dev/null; then
  say "Release Forgejo $TAG"
  if [ "${DRY_RUN:-0}" != "1" ]; then
    RID="$(curl -s -H "Authorization: token $FJ_TOKEN" -H 'Content-Type: application/json' \
      -d "{\"tag_name\":\"$TAG\",\"name\":\"$TAG\",\"body\":\"$(head -1 changelog.txt)\"}" \
      "$FORGEJO_API/releases" | python3 -c 'import sys,json
try:
  d=json.load(sys.stdin); print(d.get("id",""))
except Exception: print("")')"
    if [ -n "$RID" ]; then
      curl -s -H "Authorization: token $FJ_TOKEN" \
        -F "attachment=@${ZIP}" \
        "$FORGEJO_API/releases/$RID/assets?name=$(basename "$ZIP")" >/dev/null \
        && say "Asset Forgejo attache (release id $RID)" \
        || warn "upload asset Forgejo echoue"
    else
      warn "release Forgejo non creee (tag deja publie ? token invalide ?)"
    fi
  fi
else
  warn "Pas de token Forgejo (FORGEJO_TOKEN / ~/.config/forgejo-token) -> release Forgejo sautee"
fi

# -------- 8) regeneration du repo Kodi (OBLIGATOIRE) -------------------------
if [ -d "$KODI_REPO_DIR" ] && [ -f "$KODI_REPO_DIR/_repo_generator.py" ]; then
  say "Sync source -> kodi-repo/${ADDON_ID}/ puis regeneration de l'index"
  # kodi-repo contient l'addon comme dossier a sa racine ; le generateur zippe
  # ce dossier -> il faut y copier la nouvelle version AVANT de regenerer.
  run "rsync -a --delete \
       --exclude '.git' --exclude 'dist' --exclude '__pycache__' \
       --exclude '*.pyc' --exclude '*.zip' --exclude '*.pvpnbak' \
       --exclude 'release.sh' --exclude '.gitignore' \
       '${ADDON_DIR}/' '${KODI_REPO_DIR}/${ADDON_ID}/'"
  run "cd '$KODI_REPO_DIR' && python3 _repo_generator.py"
  if [ "${DRY_RUN:-0}" != "1" ]; then
    cd "$KODI_REPO_DIR"
    if [ -n "$(git status --porcelain)" ]; then
      git add -A
      git commit -m "protonvpn ${VERSION}"
      git push
      say "kodi-repo pousse"
    else
      warn "kodi-repo : rien a committer (index deja a jour ?)"
    fi
    cd "$ADDON_DIR"
  fi
else
  warn "kodi-repo introuvable ($KODI_REPO_DIR) -> etape sautee, A FAIRE MANUELLEMENT"
fi

# -------- 9) verif de l'index publie ----------------------------------------
if command -v curl >/dev/null && [ "${DRY_RUN:-0}" != "1" ]; then
  say "Verification de l'index publie (cache raw GitHub : patiente qq minutes si vieux)"
  sleep 2
  LINE="$(curl -s "$ADDONS_XML_URL" | grep "$ADDON_ID" || true)"
  echo "   $LINE"
  echo "$LINE" | grep -q "version=\"${VERSION}\"" \
    && say "Index a jour : ${VERSION}" \
    || warn "Index pas encore en ${VERSION} (cache ?). Cote box : Add-ons -> Rechercher les MAJ."
fi

say "Termine : ${ADDON_ID} ${VERSION} publie (GitHub + Forgejo + kodi-repo)."
